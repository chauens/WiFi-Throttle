/* WiFi Single/Multi Throttle for JMRI. Software Version Oct/02/2024.
   Christoph Hauenstein. 

   Can be configured during startup for up to 6 throttles.
   For 6 dedicated buttons. 4 top and 2 optional side buttons.
   The buttons can be programmed separately in function groups.
  
   Updates:
    08.16: show if selected address is already used in another throttle nbr
    08.17: changed function group to be throttle specific
    08.23: added option to go back in throttle startup config
    08.24: flipped last 2 lines in display, Functions above switch names.
    08.25: keypad buttons in sub routines
    09.08: handle server performance issues if consists exist and svr is set to update CV19. See JMRI doc.
    09.24: provide option to always select location during normal startup.
    10.23: things that worked before, suddenly no longer work...

   Hardware:
    ESP32 development board: EzSBC- or Adafruit- ESP32-Feather.
    Display: OLED, I2C, monochrome, 128x64 SH1106
    Rotary encoder with switch: quadrature, good choice for number of pulses per revolution: 15-25.
    
   Software Prerequisites:
    Install libraries: in Arduino IDE - select File, Preferences >
    after “Additional Boards Manager URLs:”  paste:
    https://dl.espressif.com/dl/package_esp32_index.json
    In the Board Manager, select esp32 - select "ESP Dev Module".
    Install Additional lib via zip file: https://github.com/geekfactory/TimeLib
    For more details please read "WiFiThrottle Documentation".
    If you need to see what JMRI receives and sends: add below line to file JMRI/default.icf:
    log4j.category.jmri.jmrit.withrottle=DEBUG
    This logs JMRI activities in file JMRI/log/messages.log and in the JMRI Console.
*************************************************************************************************
*** JMRI: if using Heart Beat set it to min 10 sec. Withrottle > Preferences > Use eStop.     ***
*** When using Serial Monitor: set its speed to 115200 Baud + No Line Ending.                 ***
*************************************************************************************************
*** Before loading this program for the first time the keypad has to be configured:           ***                                                              ***
*** upload sketch_Keypad_Config-V2 and run it with Serial Monitor.                            ***
*** Follow the messeages in SM.                                                               ***
*** More details in Documents "WiFi_Multi_Throttle_Documention[yymmdd].docx".                                        ***                                          ***
*************************************************************************************************
Copyright Notice for parts of this softare:
U8G2lib.h:
  Copyright (c) 2016, olikraus@gmail.com
  All rights reserved.

  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:

  * Redistributions in binary form must reproduce the above copyright notice, this 
    list of conditions and the following disclaimer in the documentation and/or other 
    materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
  CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 ****************************************************************** 
 Copyright notice for the other parts of this software:
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.
********************************************************************************
*/
//#include <PCD8544.h>
#include <TimeLib.h>
#include <EEPROM.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <WiFi.h>
// Initialize the OLED display:
#define I2C_Adr 0x3c  //OLED I2C address
#define SDA 21        //sda pin# on ESP32 board
//#define SDA 23        //sda pin# on ESP32 board
#define SCL 22            //scl pin# on ESP32 board
#define rotation U8G2_R0  // no rotation
//#define rotation U8G2_R2 // 180 degree rotation (U8G2_R1 = 90, U8G2_R3 = 270)
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(rotation, U8X8_PIN_NONE, SCL, SDA);
//U8G2_SH1107_PIMORONI_128X128_F_HW_I2C u8g2(rotation, U8X8_PIN_NONE, SCL, SDA);
//U8G2_SSD1309_128X64_NONAME2_F_HW_I2C u8g2(rotation, U8X8_PIN_NONE, SCL, SDA);
/////////////////////////////////////////////////////////////////////////////////
// compile options:
//#define LOG     // logging throttle actions in Serial Monitor
//#define DEBUG   // log server alerts & replies
#define SIDEBTNS  // Side buttons installed
#define LOCKED    // Bell is defined as 'locked' in JMRI-Roster
#define BATLEVEL  // enable Battery level sensing
#define CLOCK     // Display server clock, if not defined: display battery power in percent
//#define STARTUPLOC  //always display option to select location during normal startup
//#define DSPAREA // test display area at startup
//#define LOGTIME   // log server time stamp messages
//#define LOGHB     // log heart beat
//#define LOGNETKEY // log current netkey in startup-config
//#define DSPNETKEY // display current netkey in startup-config
//--------------------------------------------------------------------------------
WiFiClient client;
String vrs = "V2.3-4.10.2";  // -y.m.d [.t#]
//--------------------------------------------------------------------------------
// WiFi Server Definitions:
char* dftssid = "RPi-JMRI";     // default local wireless network id
char* dftpass = "rpI-jmri";     // default network key
char* dfthost = "192.168.6.1";  // default WiThrottle server IP Adr. (Device running JMRI-WiThrottle-server)
int dftport = 12090;            // default port of the server
//****************
//* Preferences: *
//****************
String tname = "MCab";                     // throttle name sent to WiThrottle server, should be unique (5 characters max)
char* locthrottle[] = { "Home", "Club" };  //select this or, one of the next 2 lines or, make up your own names
//char* locthrottle[] = { "Local", "Remote" };
//char* locthrottle[] = { "Default", "Alternate" };
float maxvolt = 4.2;  // battery voltage when fully charged. Used with BATLEVEL.
float offvolt = 3.0;  // board shut down voltage
#define numrose 100   // max number of JMRI roster entries processed (defines array size, increase if needed).
#define kpnone 100    // keypad analog value for no button pushed. If rogue readings appear increase to 50-100
//#define pfont u8g2_font_6x12_tf     //petit font
#define sfont u8g2_font_helvR08_tf  //small font
#define lfont u8g2_font_helvR10_tf  //large font
//#define lfont u8g2_font_helvR12_tf  //large font
//#define sfont u8g2_font_6x12_tf //small font
//#define lfont u8g2_font_7x14_tf //large font
char* dftsndfctst[] = { "F1", "F8" };
char ssid[26] = "N/A";  // length is 25 + 1 for null terminator
char pass[26] = "N/A";
char host[16] = "N/A";  //xxx.xxx.xxx.xxx\n
/***************************************************************************************/
// JMRI-Roster mapping for dedicated function switches >>
char* fctname[] = { "Whistle-short", "Whistle-long", "Bell", "Coupler", "Coupler-front",
                    "Shunting", "Drive-hold", "Fade", "Sound",
                    /*        custom:*/ "Cab-light", "Tail-lights", "S1Fg1", "S0Fg1", "S3Fg2", "Top-light", "S1Fg2", "S0Fg2", "S3Fg0", "S0Fg0", "S1Fg0" };
/////////////////// "S3Fg1",     "S2Fg1",       "S1Fg1", "S0Fg1", "S3Fg2", "S2Fg2",     "S1Fg2", "S0Fg2", "S3Fg0", "S0Fg0", "S1Fg0" };
//note: S0Fg0 works only with side buttons in single throttle mode!
//----------------------------------------------------------------------------------------
char* dspfnames[] = { "Whlsh", "Whllg", "Bell", "Cplr", "Cplrf", "Shtg", "Hold", "Fade", "Sound",
                      /*          custom:*/ "CabL", "TailL", "----", "----", "----", "TopL", "----", "----", "----", "----", "----" };  //short names
//--------------------"S3f1", "S2F1",  "S1F1"  "S0F1", "S3f2", "S2f2", "S1f2", "S0f2", "S3f0", "S0f0", "S1f0" };
//----------------------------------------------------------------------------------------
#define numswfcs 20     //nbr of switched fcts = nbr of fctname-array elements
#define numfcts 29      // number of functions (0-28) available in JMRI
#define maxnbrrts 64    // max number of routes (as defined by JMRI)
#define maxnbrtrns 128  // max number of turnouts (as defined by JMRI)
//----------------------------------------------------------------------------------------
#define dbcdly 150  // debounce delay
#define fdelay 10
#define ldelay 300
#define sdelay 650  // waiting for Server replies to arrive in throttle.
#define mdelay 200  // momentary fcts - delay off after on.
//----------------------------------------------------------------------------------------
#define shrtnidx 9                  //first name index in short names array
byte dspsos[] = { 0, 33, 66, 99 };  //positions where to display the short switch names
#define lw 128                      //127 or 128. display line width (some have 129 pixels instead of 128)
//#define lw 127
//----------------------------------------------------------------------------------------
// fctname-array elements dedicated switch assignments:
// element:  0   1   2   3   4   5   6    7     8     9    10    11    12    13    14    15    16    17    18    19
// switch:  SWs SWl SB  S2f S2r B12 Hold Fade Sound S3Fg1 S2Fg1 S1Fg1 S0Fg1 S3Fg2 S2Fg2 S1Fg2 S0Fg2 S3Fg0 S0Fg0 S1Fg0
// s=short,l=long,f=forward,r=reverse.  S0Fg0 works only for multithrottle.
// Hold=ESU Full Throttle Drive Hold Function - on center position of direction switch.
//*****************************************************************************************
// with side buttons: ---------------------------------------------------------------------
#ifdef SIDEBTNS
char* dspfname0[] = { "Snd", "Cplr", "<Th", "Th>" };       //short names Fg0
char* dspfname0f[] = { "Fade", "Cplr", "<Th", "Th>" };     //short names Fg0 for "fade"
char* dspfname0S[] = { "Snd", "Cplr", "----", "----" };    //short names Fg0, single throttle
char* dspfname0Sf[] = { "Fade", "Cplr", "----", "----" };  //short names Fg0, single throttle
#endif
// without side buttons: ------------------------------------------------------------------
#ifndef SIDEBTNS
char* dspfname0[] = { "Stop", "Cplr", "<Th>", "Whsl" };   //short names Fg0
char* dspfname0S[] = { "Stop", "Cplr", "----", "Whsl" };  //short names Fg0, single throttle
#endif
//-----------------------------------------------------------------------------------------
#define tl2 12  //top line 2
#define bl2 23  //bottom line 2
#define tl3 24  //top line 3
#define bl3 37  //bottom line 3
#define tl4 40  //top line 4
#define bl4 49  //bottom line 4
#define tl5 52  //top line 5
#define bl5 61  //bottom line 5
byte bl2x;      //bottom line 2 (+)
byte tl2x;      //top line 2 (dccadr)
byte tl3x;      //top line 3 (speaker)
//-----------------------------------------------------------------------------------------
// fctswtmapdft is for fctsbuffer commonly used in your locos and when the roster fails to download.
// Use Example in following line and change as needed (255=no function):
byte fctswtmapdftEU[]{ 2, 3, 5, 4, 255, 6, 255, 255, 1, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 };  // default mapping of switches (sound = F1).
byte fctswtmapdftUS[]{ 2, 3, 5, 4, 255, 6, 255, 255, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 };  // default mapping of switches (sound = F8).
byte dsndfct = 0;
byte sndfct[6];     // sound function of individual loco
byte sndfctst = 0;  //sound fct state
String ssndfct;
///////////////////////////////////////////////////////////////////////////////////////////
byte dspfos[] = { 30, 40, 50, 60, 70, 80, 90, 100, 110, 120 };  // display fctsbuffer offsets
char* dspfnum[] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
///////////////////////////////////////////////////////////////////////////////////////////
//with 2 side buttons: (switches 0-2 are free for mapping for Fg1 & Fg2, switch 3 is free for Fg0,Fg1,Fg2.
//
#ifdef SIDEBTNS
#define switchSpin 14  // Stop/Brake (left side button)
#define switchWpin 19  // whistle/Horn (right side button) Mapped to 2 fctsbuffer - short/long
#define switch1pin 4   // Fg0: Single Throttle = free map S1F0, Multi Throttle = back throttle#
#define switch3pin 32  // Fg0,1,2: free map S3f0, S3f1, S3f2
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#ifndef SIDEBTNS
//without side buttons: (switches 0-2 are free for mapping for Fg1 & Fg2)
#define switchWpin 5   // whistle/Horn Mapped to 2 fctsbuffer - short/long
#define switch1pin 4   // Fg0: Single Throttle = free map S1F0, Multi Throttle = long back, short next throttle#
#define switchSpin 32  // Stop/Brake
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#define switch0pin 5    // Fg0: Single Throttle = free map S0F0, Multi Throttle = next throttle#
#define switch2pin 25   // Fg0: 2 fctsbuffer - forward/reverse. default> Coupler (button)
#define switchBpin 18   // Bell Switch (SPST) Mapped to 1 function
#define switchFpin 15   // Forward Switch (SPDT pin1)
#define switchRpin 33   // Reverse Switch (SPDT pin3)
#define encoderA 27     // Encoder A-DT (ADC#1)
#define encoderB 12     // Encoder B-CLK (ADC#1)
#define switchEpin 13   // Emergency stop
#define switch01pin 4   // switch 1 for startup-config
#define switch02pin 25  // switch 2 for startup-config
#define switch03pin 32  // switch 3 for startup-config
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#define keypadin 34  // (A2) analog pin connecting keypad
#define L1 39        // LED (in order to use: bridging jumpers must be installed in appropriate places)
//---------------------------------------------------------------------------------
#define voltagepin 35  // voltage sensor (internal #35 = A13)
//---------------------------------------------------------------------------------
int keypadarray[32];  // work space holding keypad button values
//**********************************************************************************
const uint8_t transmit[] PROGMEM = {
  0b00100000, 0b00000100, 0b01000000, 0b00000010, 0b10001000, 0b00010001, 0b10010001, 0b10001001, 0b10010011,
  0b11001001, 0b10010011, 0b11001001, 0b10010001, 0b10001001, 0b10001000, 0b00010001, 0b01000000, 0b00000010,
  0b00100000, 0b00000100
};
const uint8_t forward[] PROGMEM = {
  0b00010000, 0b00010000, 0b00111000, 0b00111000, 0b00111000, 0b01111100, 0b01111100, 0b01111100, 0b11111110,
  0b11111110, 0b11111110
};
const uint8_t reverse[] PROGMEM = {
  0b11111110, 0b11111110, 0b11111110, 0b01111100, 0b01111100, 0b01111100, 0b00111000, 0b00111000, 0b00111000,
  0b00010000, 0b00010000
};
const uint8_t enter[] PROGMEM = {
  0b00000000, 0b00000011, 0b00001100, 0b00000011, 0b00110000, 0b00000011, 0b11111111, 0b11111111,
  0b11111111, 0b11111111, 0b00110000, 0b00000000, 0b00001100, 0b00000000
};
const uint8_t swap[] PROGMEM = {
  0b00011000, 0b00011000, 0b00110000, 0b00001100, 0b01111111, 0b11111110, 0b11111111, 0b11111111,
  0b01111111, 0b11111110, 0b00110000, 0b00001100, 0b00011000, 0b00011000
};
const uint8_t skip[] PROGMEM = {
  0b00000011, 0b00000011, 0b00000011, 0b11000011, 0b00000011, 0b11110011, 0b00000011, 0b11111111,
  0b00000011, 0b11111111, 0b00000011, 0b11110011, 0b00000011, 0b11000011, 0b00000011, 0b00000011
};
const uint8_t oops[] PROGMEM = {
  0b11000001, 0b10000000, 0b01100011, 0b00110000, 0b00110110, 0b01100000, 0b00011100, 0b11111111,
  0b00011100, 0b11111111, 0b00110110, 0b01100000, 0b01100011, 0b00110000, 0b11000001, 0b10000000
};
const uint8_t gear[] PROGMEM = {
  0b00000001, 0b10000000, 0b00011001, 0b10011000, 0b00001111, 0b11110000, 0b00001100, 0b00110000,
  0b00111000, 0b00011100, 0b00111000, 0b00011100, 0b00001100, 0b00110000, 0b00001111, 0b11110000,
  0b00011001, 0b10011000, 0b00000001, 0b10000000
};
const uint8_t speaker[] PROGMEM = {
  0b00000000, 0b00000100, 0b00000011, 0b00100010, 0b00000111, 0b10010001, 0b00001111, 0b10001001,
  0b00001111, 0b10001001, 0b00001111, 0b10001001, 0b00000111, 0b10001001, 0b00000111, 0b10010001,
  0b00000011, 0b00100010, 0b00000000, 0b00000100
};
const uint8_t siglvl0[] PROGMEM = {
  0b00000000, 0b00001110, 0b00000000, 0b11101010, 0b00001110, 0b10101010, 0b11101010, 0b10101010,
  0b10101010, 0b10101010, 0b10101010, 0b10101010, 0b11101110, 0b11101110
};
const uint8_t siglvl1[] PROGMEM = {
  0b00000000, 0b00001110, 0b00000000, 0b11101010, 0b00001110, 0b10101010, 0b11101010, 0b10101010,
  0b11101010, 0b10101010, 0b11101010, 0b10101010, 0b11101110, 0b11101110
};
const uint8_t siglvl2[] PROGMEM = {
  0b00000000, 0b00001110, 0b00000000, 0b11101010, 0b00001110, 0b10101010, 0b11101110, 0b10101010,
  0b11101110, 0b10101010, 0b11101110, 0b10101010, 0b11101110, 0b11101110
};
const uint8_t siglvl3[] PROGMEM = {
  0b00000000, 0b00001110, 0b00000000, 0b11101010, 0b00001110, 0b11101010, 0b11101110, 0b11101010,
  0b11101110, 0b11101010, 0b11101110, 0b11101010, 0b11101110, 0b11101110
};
const uint8_t siglvl4[] PROGMEM = {
  0b00000000, 0b00001110, 0b00000000, 0b11101110, 0b00001110, 0b11101110, 0b11101110, 0b11101110,
  0b11101110, 0b11101110, 0b11101110, 0b11101110, 0b11101110, 0b11101110
};
//-----------------------------------
const uint8_t batlvl0[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10000000, 0b00000100, 0b10000000, 0b00000111,
  0b10000000, 0b00000111, 0b10000000, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl1[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10100000, 0b00000100, 0b10100000, 0b00000111,
  0b10100000, 0b00000111, 0b10100000, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl2[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10110000, 0b00000100, 0b10110000, 0b00000111,
  0b10110000, 0b00000111, 0b10110000, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl3[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111000, 0b00000100, 0b10111000, 0b00000111,
  0b10111000, 0b00000111, 0b10111000, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl4[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111100, 0b00000100, 0b10111100, 0b00000111,
  0b10111100, 0b00000111, 0b10111100, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl5[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111110, 0b00000100, 0b10111110, 0b00000111,
  0b10111110, 0b00000111, 0b10111110, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl6[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111111, 0b00000100, 0b10111111, 0b00000111,
  0b10111111, 0b00000111, 0b10111111, 0b00000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl7[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111111, 0b10000100, 0b10111111, 0b10000111,
  0b10111111, 0b10000111, 0b10111111, 0b10000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl8[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111111, 0b11000100, 0b10111111, 0b11000111,
  0b10111111, 0b11000111, 0b10111111, 0b11000100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl9[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111111, 0b11100100, 0b10111111, 0b11100111,
  0b10111111, 0b11100111, 0b10111111, 0b11100100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
const uint8_t batlvl10[] PROGMEM = {
  0b01111111, 0b11111000, 0b10000000, 0b00000100, 0b10111111, 0b11110100, 0b10111111, 0b11110111,
  0b10111111, 0b11110111, 0b10111111, 0b11110100, 0b10000000, 0b00000100, 0b01111111, 0b11111000
};
//----------------------------------------------------------------------------------
byte numthrottles = 1;  //number of throttles. max 6, 1 means single throttle. Change at startup.
char* cfgthrottle[] = { "1 throttle", "2 throttles", "3 throttles", "4 throttles", "5 throttles", "6 throttles" };
bool MThr = false;
String svrmsg;
String ssidstr;
String passstr;
String hoststr;
bool async = false;
bool show_hidden = true;
int port = 12090;  // WiThrottle server Port work variable
int lastport;
int tmpport;
byte location = 0;            // for selecting "club or home" during setup
bool setuplocflag = false;    //##10.2
byte fctswtmap[6][numswfcs];  // mapping dedicated switches to fctsbuffer per throttle nbr
int MTn = 1;                  // multi throttle number
int MTx = 0;                  // pointer into arrays
int PrvMTn = 0;               // throttle number before switching throttle
byte actthrottles = 0;        // bit array for active throttles
//throttle assisted (simple) double header --->>
byte sdhswtmap[6][numswfcs];  // mapping switches to double header fctsbuffer
int sdhadr[6];                // simple double header address
byte sdhdct[6];               // sdh trailer direction.
byte setsdhadr = 0;           // boolean bit array
String sdhacts[6];            // hold actions for the trailer address
byte dblhdrfct;               // for a function that is also sent to the double header trailer address
//<<---dblhdr
bool inhmsglog = false;  // inhibit inbound message log.
bool fctfdbk = false;
byte fctfdbkbuf[6][numfcts];
byte t_fctfdbkbuf[6][numfcts];
byte blkdfks[6][numfcts];  // blocked function keys while using dedicated function switches.
byte fctnos[6][numfcts];   // function name start offsets for get fct by name
byte fctnoe[6][numfcts];   // function name end offsets for get fct by name
byte fctnox[6][numfcts];   // function numbers
byte numfcnt[6];           // number of fcts counted
String dspfctname;         // display function name
byte setfctbn = 0;         // boolean bit array
// routes --->>>
int rsosa[maxnbrrts];  // route sysname offsets array
int ruosa[maxnbrrts];  // route usrname offsets
int numrtos = 0;       // route offset in array
int numrts = 0;        // number of routes found
byte setroute = 0;     // setting route or accessory decoder address
bool sltroute = false;
String rsysname;         // route system name
String rusrname;         // route user name
bool rts_Avail = false;  // routes found in JMRI
// turnouts --->>>
int tsosa[maxnbrtrns];   // turnout sysname offsets array
int tuosa[maxnbrtrns];   // turnout usrname offsets array
int tstosa[maxnbrtrns];  // turnout state offsets array
int numtos = 0;          // turnout offset in array
int numts = 0;           // number of turnouts found
String tsysname;         // turnout system name
String tusrname;         // turnout user name
byte tostate;            // turnout state
String dsptostate;
char* tostarray[] = { "*", "Unknown", "Closed", "*", "Thrown", "*", "*", "*", "Inconsistent" };
//char* tostarray[] = {"*", "?", "C", "*", "T", "*", "*", "*", "!"};
bool trn_Avail = false;  // turnouts available in JMRI
//----------------------------------------------------------------------------------
String dsptname;         // display throttle name
String ctname;           // current throttle name
String dsptext;          // display some text
int cd = 60;             // timeout for the screen saver (in seconds)
int cb = 10;             // time in seconds between battery/signal monitoring
byte numspst[6];         // current max speed steps (from DCC)
byte spdstpm = 2;        // speed step mode
byte chgspstm = 0;       // change speed step mode
bool pushshort = false;  // button pressed short
bool pushlong = false;   // button pressed long
/////////////////////////////////////////////////////////////////////////////////////////////
bool noop = false;
bool thrconfig = false;   // config mode by pushing STP button within 5 sec after prompt
bool netconfig = false;   // config wifi by scanning networks
bool ssidconfig = false;  // config wifi by manually entering network ssid
bool passconfig = false;  // config network pass key
bool hostconfig = false;  // config ip address of host
bool portconfig = false;  // port of the host server
bool locconfig = false;   // config location (local/remote-home/club)
bool locselect = false;   // select location during startup ##09.24
bool sndconfig = false;   // set sound function key (US=F8, EU=F1)
bool sstoconfig = false;  // set screen saver timeout
bool strupcfg = false;    // startup-config mode
byte prvloc = 0;
byte prvdsndfct = 0;
byte ssto = 60;  // startup-config 'screen saver time out' in 30 seconds intervals up to 180.
byte prvssto = 0;
String ssidstrx[6];  //Wi-Fi network
String ssidx;
long signalx = 0;
long sigstrth[6];  //signal strength
bool thrchg;
bool ssidchg;
bool passchg;
bool hostchg;
bool portchg;
String newssidstr;
String prvssidstr;
String newpassstr;
String newchar;
String newhoststr;
String prvhoststr;
unsigned int len = 0;
int chcnt = 0;
//String characters = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789.!@#$%^&*()_-+"; //0-75 (76 characters)
String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.!@#$%^&*()_-+";  //0-75 (76 characters)
bool throff = false;
/////////////////////////////////////////////////////////////////////////////////////////////
String MacString;    // MAC Address
String unixtime;     //hold unix time stamp from jmri
String unixsub;      //holding time substring
String ratiosub;     //holding fast clock ratio substring
int cntc = 0;        // counter for connecting to WiFi
int cntt = 0;        // connection timeout counter
int cnth;            // counter for the heart beat timer
byte ch;             // for the heartbeat timer (received from jmri)
bool hben = true;    // en-/dis-able heart beat
int hbitv;           // heart beat interval from JMRI
String hbres;        // receive heart beat interval from server
bool hbuse = false;  // heart beat off (on)
float cntf;          // calc throttle heart beat interval
int cntd;            // counter for the screen saver
int cntb;            // counter for the battery/signal monitor timer
bool dsplon = true;  // screen saver tracking
/////////////////////////////////////////////////////////////////////
int btnmin = 0;      // for finding min value
int btnmax = 0;      // for finding max value
int btnprvl = 5000;  // previous low
int btnprvh = 0;     // previous high
int btnnum = 0;      // button number
/////////////////////////////////////////////////////////////////
IPAddress ip;  // the IP address of this device (negotiated automagically)
byte mac[6];   // MAC Address of the throttle sent to server for identification
//
unsigned long prvsMs = 0;
unsigned long crntMs;
unsigned long startTime;
unsigned long prvsMillis = 0;
unsigned long crntMillis;
byte drivehold[6];
bool driveholdON = false;
//
int kpread = 0;         // holding keypad button values
byte zthze[5];          // array saving digits entered, for ability to correct.
int btncnt = 0;         // button count for entering numbers in dccadr, portnbr.
int dccadr[6];          // DCC Address array per throttle
int lastdccadr[6];      // array to hold last dcc addresses
bool adrmatch = false;  // used in vfyadr (verify address for duplicate in other throttle#)
int vadr;               //verify address for duplicates in other throttles
bool strq = false;      // steel loco inquiry processing
bool steel = false;     // steel loco request
int dccadrrlsd[6];      // released DCC address
int dccadrtmp;
int dccstck[6];  // stack array;
byte stkx = 0;   // stack index
bool updstck;    // save or not to save to stack
int btnval = 0;  // value of the keypad button for manual address entry
char dspadr[6];  // for displaying DCCadr with leading zeros
String dccadrsnd;
int dspmin;   // for displaying fast clock minute with leading zero
int dsphour;  // for displaying fast clock hour with leading zero
String dsptime;
byte adrbtnstate = 0;
byte setdccadr = 0;  //boolean bit array
bool kpbtnstate = false;
bool estop = false;
bool pshadr = false;
bool pshnbr = false;
int rosbtncnt = 0;
//
byte accbtnst[6];
byte setaccadr = 0;  // boolean bit array
bool rlsfdbk = true;
int accadr[6];
char dspaccadr[6];
String setacc[6];
#define EEPROM_SIZE 192
// 0+1=dccadr, 2-13=stack, 19=numthrottles, 20-83=keypad-values, 84=scrn-sav, 85-94=free,
// 95=location(0=home/1=club), 96+97=dccadrT2, 98+99=dccadrT3, 100+101=dccadrT4,
// 102+103=dccadrT5, 104+105=dccadrT6, 108=ssid-length, 109-133=ssid, 135=pass-length, 136-160=pass,
// 162=host-length, 163-178=host, 180+181=port, 183=default sound function.
bool shortwhstl = false;
bool longwhstl = false;
bool swtWon = false;
bool swt1on = false;
bool swt2on = false;
bool swt3on = false;
bool swtBon = false;
bool swtCon = false;
bool swtEon = false;
bool swtFon = false;
bool swtRon = false;
bool swt0on = false;
bool swtSon = false;
//
int crntAState;
int prvsAState;
// functions:
bool swtfg0 = false;
bool fctbtnstate = false;  // function group button
byte fcgstate[6];          // function group state (0=0-9, 1=10-19, 2=20-28, 3=select by name)
byte dctstate = 0;         //direction. boolean byte - bit 'on' is forward
bool fc1btnstate = false;
bool fc2btnstate = false;
bool fc3btnstate = false;
bool fc4btnstate = false;
bool fc5btnstate = false;
bool fc6btnstate = false;
bool fc7btnstate = false;
bool fc8btnstate = false;
bool fc9btnstate = false;
bool fc0btnstate = false;
byte fnum;              // function number
bool chgfn = false;     // change flag for fct short name display
byte sfnum[6];          // fct nbr for sound fade
byte t_sfnum[6];        // trailer fct nbr for sound fade
byte fade_Avail = 0;    //boolean
byte t_fade_Avail = 0;  //boolean
bool fadeDsp = false;
bool fadebtn = false;  // use fade
bool t_fadebtn = false;
bool fadebtnoff = false;
byte faded = 0;    //boolean fade on/off
byte t_faded = 0;  //boolean trailer fade
byte fdfctst = 0;  //fade function state
byte t_fdfctst = 0;
byte fctrlsst = 0;           // for release: 1=fct1,2=fade-fct
byte fnumts;                 // function number for toggle switch which could be on while other fctsbuffer are handled
int fn;                      // fct nbr array pointer
int rosnamoffsets[numrose];  // array for loco names from roster
int rosadroffsets[numrose];  // array for loco addresses from roster
//
byte fctsavail = 0;  //boolean bits
byte fctbtnst;       // function state (1=on, 0=off)
byte fctstate;       // function state feedback from jmri
float vtemp = 0;
byte vspeed[6];
byte dspeed = 0;
byte vcnt[6];
byte rcnt[6];
byte rtcnt[6];
byte fcnt[6];
byte tcnt[6];
byte ccnt[6];
byte prvspeed[6];
bool encoder_moved = false;  //encoder moved flag
bool encoder_movedCW;        // true = encoder has moved clock wise
volatile int vcntv = 0;      // encoder step counter for speed
volatile int rcntv = 0;      // encoder step counter for roster
volatile int rtcntv = 0;     // encoder step counter for routes
volatile int fcntv = 0;      // encoder step counter for fctsbuffer
volatile int tcntv = 0;      // encoder step counter for turnouts
volatile int thcntv = 0;     // encoder step counter for throttle setup
byte savrcnt = 0;
byte savrtcnt = 0;
byte hcnt = 0;  // drive hold counter for locked speed
byte lastvcnt = 0;
int rxn, rxnn, numre, numos;
int fxi, fxn, fxm, fxs, fxe;
String xmits;          //send buffer loco actions-commands
String jmri_res;       //buffer to hold incoming response
String jmri_sub;       //buffer to hold substring of incoming response
String flushnull;      //get rid of '\n'
String fctsbuffer[6];  //buffer to hold function list, Server reply
String steelrq;
String roster;            //buffer to hold roster list
String routes;            //buffer to hold route list
String turnouts;          //buffer to hold turnout list
String rosne;             //to hold nbr of roster entries
bool ros_Avail = false;   // roster available ##09.12
bool ros_eAvail = false;  // roster entry available (loco)
String loconame[6];       // loco name from server. For display, should not exceed 10 char.
String locoadr[6];        // display dcc adr
String locoacts[6];       // to hold an action string
String lastlocoacts[6];
String lkf[6];  // to hold search argument for fctsbuffer
String lkr[6];  // to hold search argument for direction
String lks[6];  // hold search argument for speed step mode
bool wifi_ok = true;
bool svr = true;
bool ready = false;  //##09.08
bool recon = false;
int swtBstate = 0;
int lastswtBstate = 0;
int swtWstate = 0;
int lastswtWstate = 0;
int swt1state = 0;
int lastswt1state = 0;
int swt2state = 0;
int lastswt2state = 0;
int swt3state = 0;
int lastswt3state = 0;
int swtFstate = 0;
int lastswtFstate = 0;
int swtRstate = 0;
int lastswtRstate = 0;
int swtEstate = 0;
int lastswtEstate = 0;
int swtSstate = 0;
int lastswtSstate = 0;
//
int swt0state = 0;
int lastswt0state = 0;
// encoder interrupt subroutine:----------------------------
void IRAM_ATTR encisr() {
  crntAState = digitalRead(encoderA);
  if (crntAState != prvsAState) {
    if (digitalRead(encoderB) != crntAState) {  //rotating cw
      encoder_movedCW = true;
    } else {  // rotating ccw
      encoder_movedCW = false;
    }
  }
  prvsAState = crntAState;
  encoder_moved = true;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
void setup() {
  Serial.begin(115200);
#ifdef LOG
  delay(3000);  //give time for starting serial monitor
#endif
#ifndef LOG
  delay(1000);  //give time to release 'OFF button reboot' before entering startup-config
#endif
  int i2cAdr = (I2C_Adr * 2);  //per u8g2 reference manual address must be multiplied by 2
  u8g2.setI2CAddress(i2cAdr);
  u8g2.begin();
  u8g2.setPowerSave(0);
  u8g2.clearDisplay();
  u8g2.setFont(sfont);
  u8g2.setDrawColor(1);
#ifdef DSPAREA
  //test all pixels:
  u8g2.drawBox(0, 0, lw, 64);
  u8g2.sendBuffer();
  delay(2000);
  u8g2.clearDisplay();
  //test display area:
  u8g2.clearDisplay();
  u8g2.drawFrame(0, 0, lw, 64);
  u8g2.sendBuffer();
  delay(2000);
  u8g2.clearDisplay();
#endif
  //--------------------------------
  // start setup----
#ifdef SIDEBTNS
  pinMode(switch0pin, INPUT_PULLUP);
  pinMode(switch3pin, INPUT_PULLUP);
#endif
  pinMode(switch1pin, INPUT_PULLUP);
  pinMode(switch2pin, INPUT_PULLUP);
  pinMode(switchWpin, INPUT_PULLUP);
  pinMode(switchSpin, INPUT_PULLUP);
  pinMode(switchFpin, INPUT_PULLUP);
  pinMode(switchRpin, INPUT_PULLUP);
  pinMode(switchBpin, INPUT_PULLUP);
  pinMode(encoderA, INPUT_PULLUP);
  pinMode(encoderB, INPUT_PULLUP);
  pinMode(switchEpin, INPUT_PULLUP);
  pinMode(L1, INPUT_PULLUP);  //avoid floating pin. Not coded.
#ifdef BATLEVEL
  pinMode(2, OUTPUT);
  pinMode(voltagepin, INPUT);
  //--------------------------------
  bl2x = bl2 - 1;  //bottom line 2 (+)
  tl2x = tl2 - 3;  //top line 2 (dccadr)
  tl3x = tl3 + 4;  //top line 3 (speaker)

  //--------------------------------
  digitalWrite(2, HIGH);
  delay(50);
  int batin = analogRead(voltagepin);
  digitalWrite(2, LOW);
  float battmp = batin / 2047.5;
  float batvolt = battmp * 3.63;  // 3.3 refV * 1.1 ADC refV = 3.63
  if (batvolt <= offvolt) {
    u8g2.drawStr(0, 20, "Low Battery");
    u8g2.sendBuffer();
    //return;
  }
  //---------------------------------
#endif  // BATLEVEL
  kpread = analogRead(keypadin);
  if (kpread > kpnone) strupcfg = true;
#ifdef LOG
  Serial.println("Setup: >>>>>>>>>>>>>>>>>>>>>");
  Serial.println(vrs);
#endif
  //init arrays:
  for (byte n = 0; n < 6; n++) {         //for each throttle
    for (int i = 0; i < numfcts; i++) {  //for each fct in a throttle
      fctfdbkbuf[n][i] = 0;
      t_fctfdbkbuf[n][i] = 0;
      blkdfks[n][i] = 0;
    }
    fcgstate[n] = 0;
    vspeed[n] = 0;
    vcnt[n] = 0;
    prvspeed[n] = 0;
  }
  //init location
  EEPROM.begin(EEPROM_SIZE);
  location = EEPROM.read(95);
  if (location > 1) {
    location = 0;
    EEPROM.write(95, 0);
    EEPROM.commit();
  }
  //init default sound function key
  dsndfct = EEPROM.read(183);
  if (dsndfct > 1) {
    dsndfct = 0;
    EEPROM.write(183, 0);
    EEPROM.commit();
  }
  //init screen saver timeout
  cd = EEPROM.read(84);
  if ((cd < 30) || (cd > 180)) {
    cd = 60;
    EEPROM.write(84, 60);
    EEPROM.commit();
  }
  dccadr[0] = EEPROM.read(0);
  dccadr[0] = (dccadr[0] << 8) + EEPROM.read(1);
  if ((dccadr[0] < 0) || (dccadr[0] > 9999)) {  // 1-9999 as supported by most dcc systems (some allow above 9999).
    dccadr[0] = 3;
    EEPROM.write(0, 0);
    EEPROM.write(1, 3);
    EEPROM.commit();
  }
  //init # of throttles
  numthrottles = EEPROM.read(19);
  if ((numthrottles < 1) || (numthrottles > 6)) {
    numthrottles = 1;
    EEPROM.write(19, 1);
    EEPROM.commit();
  }
  if (numthrottles > 5) {
    dccadr[5] = EEPROM.read(104);
    dccadr[5] = (dccadr[5] << 8) + EEPROM.read(105);
  }
  if (numthrottles > 4) {
    dccadr[4] = EEPROM.read(102);
    dccadr[4] = (dccadr[4] << 8) + EEPROM.read(103);
  }
  if (numthrottles > 3) {
    dccadr[3] = EEPROM.read(100);
    dccadr[3] = (dccadr[3] << 8) + EEPROM.read(101);
  }
  if (numthrottles > 2) {
    dccadr[2] = EEPROM.read(98);
    dccadr[2] = (dccadr[2] << 8) + EEPROM.read(99);
  }
  if (numthrottles > 1) {
    dccadr[1] = EEPROM.read(96);
    dccadr[1] = (dccadr[1] << 8) + EEPROM.read(97);
    MThr = true;
  }
  if ((dccadr[1] <= 0) || (dccadr[1] > 9999)) {
    dccadr[1] = 3;
    EEPROM.write(96, 0);
    EEPROM.write(97, 3);
    EEPROM.commit();
  }
  if ((dccadr[2] <= 0) || (dccadr[2] > 9999)) {
    dccadr[2] = 3;
    EEPROM.write(98, 0);
    EEPROM.write(99, 3);
    EEPROM.commit();
  }
  if ((dccadr[3] <= 0) || (dccadr[3] > 9999)) {
    dccadr[3] = 3;
    EEPROM.write(100, 0);
    EEPROM.write(101, 3);
    EEPROM.commit();
  }
  if ((dccadr[4] <= 0) || (dccadr[4] > 9999)) {
    dccadr[4] = 3;
    EEPROM.write(102, 0);
    EEPROM.write(103, 3);
    EEPROM.commit();
  }
  if ((dccadr[5] <= 0) || (dccadr[5] > 9999)) {
    dccadr[5] = 3;
    EEPROM.write(104, 0);
    EEPROM.write(105, 3);
    EEPROM.commit();
  }
#ifdef LOG
  Serial.print("last dcc addresses of throttle(s): ");
  Serial.println(String(dccadr[0]) + ", " + String(dccadr[1]) + ", " + String(dccadr[2]) + ", " + String(dccadr[3]) + ", " + String(dccadr[4]) + ", " + String(dccadr[5]));
#endif
  // retrieve stack:
  retrievestack();
// -keypad config:-----------------------------------
#ifdef LOG
  Serial.println("Setup: keypad values in EEPROM:");
  byte k = 20;
  for (byte i = 0; i < 33; i++) {
    if (i > 0) Serial.print(",");
    int v = EEPROM.read(k);
    k++;
    v = (v << 8) + EEPROM.read(k);
    k++;
    Serial.print(v);
  }
  Serial.println();
#endif
  //Get keypad values from EEPROM:
  byte j = 20;
  for (byte i = 0; i < 32; i++) {
    keypadarray[i] = EEPROM.read(j);
    j++;
    keypadarray[i] = (keypadarray[i] << 8) + EEPROM.read(j);
    j++;
  }
#ifdef LOG
  Serial.println("Setup: Keypad values in array: ");
  for (byte i = 0; i < 32; i++) {
    if (i > 0) Serial.print(",");
    int val = keypadarray[i];
    Serial.print(val);
  }
  Serial.println();
#endif
  //................................................................................
  prvsAState = digitalRead(encoderA);  // Read the "initial" state of encoderA
  attachInterrupt(encoderA, encisr, CHANGE);
  //................................................................................
  if (MThr == true) ctname = tname + String(MTn);
  else ctname = tname;
#ifdef LOG
  dsptname = ctname + "d";
#endif
#ifndef LOG
  dsptname = ctname;
#endif
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);  //black
  u8g2.drawBox(0, 0, lw, 12);
  u8g2.setDrawColor(1);  //white
  u8g2.setCursor(0, 9);
  u8g2.print(dsptname);
  u8g2.setCursor(45, 9);
  u8g2.print(vrs);
  String nbrthr = String(numthrottles) + "Thr";
  u8g2.setCursor(106, 9);
  u8g2.print(nbrthr);
  String thrloc = String(locthrottle[location]);
  //-----looking for stored network credentials:
  if (location == 1) {
    rtvnetcreds();  //club/remote setting
  } else {
    rtvdftnetcreds();  //home/local setting
  }
  //---Startup-config:---------------------------------------------------------
  if (strupcfg == true) {
    // entering a config mode:
#ifdef LOG
    Serial.println("Entered throttle startup configuration.");
#endif
    u8g2.drawStr(0, 22, "For Setup press");
    u8g2.drawBitmap(85, 13, 2, 10, gear);
    u8g2.drawStr(0, 35, "Select location press");
    u8g2.drawBitmap(110, 28, 2, 7, swap);
    u8g2.drawStr(0, 48, "Crnt loc: ");
    u8g2.setCursor(50, 48);
    u8g2.print(thrloc);
    u8g2.drawBitmap(dspsos[0], 53, 2, 10, gear);
    u8g2.drawBitmap(dspsos[1], 56, 2, 7, swap);
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.sendBuffer();
    unsigned long pushtime = millis();
    while (millis() < pushtime + 12000) {    //wait up to 12 sec
      swt3state = digitalRead(switch03pin);  //config throttle
      if (swt3state == LOW) {
        thrconfig = true;
        break;
      }
      swt2state = digitalRead(switch02pin);  //change location,dft sound key
      if (swt2state == LOW) {
        swt2on = true;
        locselect = true;  //##10.1
        break;
      }
      swt1state = digitalRead(switch01pin);  // skip
      if (swt1state == LOW) {
        break;
      }
    }
    //##09.24 strupcfg = false;
  }  //end of strupcfg = true
// -------begin throttle setup > ----------
locsetup:
  //##09.24 if (locconfig == true) {
  if ((locconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Configure Location ***");
#endif
    prvloc = location;
    setuplocflag = true;  //##10.1 ##10.2
    location = EEPROM.read(95);
    u8g2.clearDisplay();
    u8g2.setDrawColor(1);  //white
    u8g2.drawStr(40, 9, "Set location");
    u8g2.drawStr(0, 24, "Current: ");
    u8g2.setFont(lfont);
    u8g2.setCursor(60, 24);
    u8g2.print(thrloc);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 38, "To chg location press");
    u8g2.drawBitmap(110, 32, 2, 7, swap);
    u8g2.drawStr(0, 50, "To save/exit press");
    u8g2.drawBitmap(90, 43, 2, 7, enter);
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[1], 56, 2, 7, swap);
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.drawBitmap(dspsos[3], 53, 2, 10, gear);
    u8g2.sendBuffer();
    if (location == 1) rtvnetcreds();
    else rtvdftnetcreds();
#ifdef LOG
    Serial.println("Current location: " + String(location));
#endif
  }
  while (locconfig == true) {
    swt2state = digitalRead(switch02pin);  // swap location
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      location = (location == 0) ? 1 : 0;
#ifdef LOG
      Serial.println("Location change: " + String(location));
#endif
      //>>--------------------------------------------------------
      if (location == 0) {
        newssidstr = dftssid;
        len = newssidstr.length();
        len++;
        newssidstr.toCharArray(ssid, len);
      }
      if (location == 1) {
        ssidstr = "";
        len = EEPROM.read(108);
        if ((len > 0) && (len < 26)) {  //making sure length is valid
          len++;                        //include null terminator
          byte j = 109;
          for (byte i = 0; i < len; i++) {
            ssidstr = ssidstr + char(EEPROM.read(j));
            j++;
          }
          ssidstr.toCharArray(ssid, len);
#ifdef LOG
          Serial.println("***Location-Setup***");
          Serial.print("SSID - length: " + String(len));
          Serial.print(", SSID: " + String(ssid));
          Serial.println(" retrieved from eeprom.");
#endif
        }
      }
      //<<--------------------------------------------------------
      u8g2.setDrawColor(0);
      u8g2.drawBox(60, 10, 68, 16);  //clear line 24 large "local/remote-Home/Club"
      u8g2.drawBox(0, 28, lw, 12);   //clear line 38 "To switch loc...."
      u8g2.setDrawColor(1);
      u8g2.setFont(lfont);
      String thrloc = String(locthrottle[location]);
      u8g2.setCursor(60, 24);
      u8g2.print(thrloc);  // display remote or local - Club or Home
      u8g2.setFont(sfont);
      u8g2.setCursor(0, 38);
      u8g2.print(String(ssid));
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locconfig = false;
    }
    swt3state = digitalRead(switch03pin);  // save/exit
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      if (location != prvloc) {
#ifdef LOG
        Serial.println("Saving new location: " + String(locthrottle[location]));
#endif
        EEPROM.write(95, location);
        EEPROM.commit();
        prvloc = location;
      }
      if (location == 1) rtvnetcreds();
      else rtvdftnetcreds();
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locconfig = false;
    }
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {  //skip to netconfig
      delay(dbcdly);
      swt0on = true;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      sndconfig = false;
      sstoconfig = false;
      netconfig = true;
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
      locconfig = false;
    }
  }
  //Default sound function key (EU=F1,US=F8):------------------------------------------------------
  //##09.24 if (sndconfig == true) {
  if ((sndconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config default Sound F-Key ***");
#endif
    prvdsndfct = dsndfct;
    dsndfct = EEPROM.read(183);
    u8g2.clearDisplay();
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 9, "Set default sound function");
    u8g2.drawStr(0, 24, "current: ");
    u8g2.setFont(sfont);
    String dsndfctstr = String(dftsndfctst[prvdsndfct]);
    u8g2.setCursor(40, 24);
    u8g2.print(dsndfctstr);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 38, "To change press");
    u8g2.drawBitmap(110, 32, 2, 7, swap);
    u8g2.drawStr(0, 50, "To save/exit press");
    u8g2.drawBitmap(90, 43, 2, 7, enter);
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[1], 56, 2, 7, swap);
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.drawBitmap(dspsos[3], 53, 2, 10, gear);
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Current default sound fct: " + String(dftsndfctst[prvdsndfct]));
#endif
  }
  while (sndconfig == true) {
    swt2state = digitalRead(switch02pin);  // swap fct-key
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      dsndfct = (dsndfct == 0) ? 1 : 0;
#ifdef LOG
      Serial.println("Default sound function changed: " + String(dsndfct));
#endif
      //--------------------------------------------------------
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 28, lw, 12);  //clear line 38
      u8g2.setDrawColor(1);
      u8g2.setFont(sfont);
      u8g2.drawStr(0, 38, "new: ");
      String dsndfctstr = String(dftsndfctst[dsndfct]);
      u8g2.setCursor(40, 38);
      u8g2.print(dsndfctstr);
      u8g2.setFont(sfont);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      sndconfig = false;
    }
    swt3state = digitalRead(switch03pin);  // save/exit
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      if (dsndfct != prvdsndfct) {
#ifdef LOG
        Serial.println("Saving new default sound function key: " + String(dftsndfctst[dsndfct]));
#endif
        EEPROM.write(183, dsndfct);
        EEPROM.commit();
        prvdsndfct = dsndfct;
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      sndconfig = false;
      sstoconfig = true;
    }
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {  //skip to netconfig
      delay(dbcdly);
      swt0on = true;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locconfig = false;
      sstoconfig = false;
      netconfig = true;
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
      sndconfig = false;
    }
  }  //end of default sound function key setting
  //Screen saver time out:------------------------------------------------------
  //##09.24 if (sstoconfig == true) {
  if ((sstoconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config Screen Saver time out ***");
#endif
    ssto = cd;  //get current value
    prvssto = ssto;
    ssto = EEPROM.read(84);
    u8g2.clearDisplay();
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 9, "Set Screen Saver timeout");
    u8g2.drawStr(0, 24, "current: ");
    u8g2.setFont(sfont);
    String sstostr = String(ssto);
    u8g2.setCursor(40, 24);
    u8g2.print(sstostr);
    u8g2.drawStr(60, 24, "seconds");
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 38, "To change press");
    u8g2.drawBitmap(110, 32, 2, 7, swap);
    u8g2.drawStr(0, 50, "To save/exit press");
    u8g2.drawBitmap(90, 43, 2, 7, enter);
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[1], 56, 2, 7, swap);
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.drawBitmap(dspsos[3], 53, 2, 10, gear);
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Current Screen Saver timeout: " + String(ssto));
#endif
  }
  while (sstoconfig == true) {
    swt2state = digitalRead(switch02pin);  // swap fct-key
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      ssto = ssto + 30;
      if (ssto > 180) ssto = 30;
#ifdef LOG
      Serial.println("Default sound function changed: " + String(dsndfct));
#endif
      //--------------------------------------------------------
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 28, lw, 12);  //clear line 38
      u8g2.setDrawColor(1);
      u8g2.setFont(sfont);
      u8g2.drawStr(0, 38, "new: ");
      String sstostr = String(ssto);
      u8g2.setCursor(40, 38);
      u8g2.print(sstostr);
      u8g2.drawStr(60, 38, "seconds");
      u8g2.setFont(sfont);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      sstoconfig = false;
    }
    swt3state = digitalRead(switch03pin);  // save/exit
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      if (ssto != prvssto) {
#ifdef LOG
        Serial.println("Saving new Screen Saver timeout: " + String(ssto));
#endif
        EEPROM.write(84, ssto);
        EEPROM.commit();
        prvssto = ssto;
        cd = ssto;
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      sstoconfig = false;
    }
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {  //skip to netconfig
      delay(dbcdly);
      swt0on = true;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locconfig = false;
      sndconfig = false;
      netconfig = true;
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
      sstoconfig = false;
    }
  }  //end of screen saver timeout
  //---throttle setup>-------------------------------------------------------------------------
  //##09.24 if (thrconfig == true) {
  if ((thrconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Configure Throttle ***");
#endif
    thrchg = false;
    thcntv = numthrottles - 1;  //set counter to current setting (array starts at 0)
    u8g2.clearDisplay();
    u8g2.drawStr(30, 10, "Set nbr throttles");
    u8g2.drawStr(0, 22, "Current setting:");
    u8g2.setFont(lfont);
    String numthrs = String(cfgthrottle[thcntv]);
    u8g2.setCursor(10, 36);
    u8g2.print(numthrs);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 50, "Turn knob to select");
    u8g2.drawStr(0, bl5, "Push knob to enter.");
    u8g2.sendBuffer();
  }
  while (thrconfig == true) {
    if (encoder_moved == true) {
      delay(50);  //##09.10a
      if (encoder_movedCW == true) {
        thcntv++;
        if (thcntv > 5) thcntv = 0;  // end of throttle entries
      } else {
        thcntv--;
        if (thcntv < 0) thcntv = 5;  // start of throttle entries
      }
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 12, lw, 14);    //clear line 22
      u8g2.drawBox(10, 20, 118, 16);  //clear line 36
      u8g2.setDrawColor(1);
      u8g2.drawStr(0, 22, "New setting:");
      u8g2.setFont(lfont);
      String numthrs = String(cfgthrottle[thcntv]);
      u8g2.setCursor(10, 36);
      u8g2.print(numthrs);
      u8g2.setFont(sfont);
      u8g2.sendBuffer();
      encoder_moved = false;
      thrchg = true;
    }
    swtEstate = digitalRead(switchEpin);  //save
    if ((swtEstate == LOW) && (swtEon == false)) {
      delay(dbcdly);
      swtEon = true;
      if (thrchg == true) {
        numthrottles = thcntv + 1;  // (array starts at 0, numthrottles starts at 1)
#ifdef LOG
        Serial.println("New number of throttles: " + String(numthrottles));
#endif
        EEPROM.write(19, numthrottles);
        EEPROM.commit();
        thrchg = false;
      }
    }
    if ((swtEstate == HIGH) && (swtEon == true)) {
      delay(dbcdly);
      swtEon = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      thrconfig = false;
      netconfig = true;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      thrconfig = false;
      netconfig = true;
    }
  }
  //---------------network config>
  // storage: 108=ssid-length 109-133=ssid
  //##09.24 if (netconfig == true) {
  if ((netconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config Network ***");
#endif
    rtvnetcreds();
#ifdef LOG
    Serial.println("SSID in storage: " + String(ssid));
#endif
    prvssidstr = ssid;
    u8g2.setFont(sfont);
    String thrloc = String(locthrottle[1]);
    u8g2.drawStr(0, 10, "Set SSID for loc: ");
    u8g2.setCursor(80, 10);
    u8g2.print(thrloc);
    u8g2.drawStr(0, 24, "Current ssid:");
    u8g2.setCursor(10, 36);
    u8g2.print(String(ssid));
    u8g2.drawStr(0, 48, "Scanning nearby networks");
    u8g2.drawStr(0, 60, "Please wait...");
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Current ssid: " + String(ssid));
    Serial.println("scanning nearby networks...");
#endif
    //scanNetworks() returns networks found
    int net = WiFi.scanNetworks(async, show_hidden);  //returns networks found, including hidden networks
#ifdef LOG
    Serial.println("scan done ---");
#endif
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 38, lw, 26);  //clear 2 lines 48 "scanning..."
    u8g2.setDrawColor(1);
    u8g2.sendBuffer();
    if (net < 1) {
      u8g2.drawStr(0, 48, "No network found.");
      u8g2.sendBuffer();
#ifdef LOG
      Serial.println("no network found");
#endif
    } else {
#ifdef LOG
      Serial.print(net);
      Serial.println(" network(s) found.");
#endif
      // show SSID for each network found (limit of 6)
      if (net > 6) net = 6;
      for (int i = 0; i < net; i++) {
#ifdef LOG
        Serial.print(i + 1);
        Serial.print(": ");
        Serial.print(WiFi.SSID(i));
        Serial.print(" | Signal: ");
        Serial.print(WiFi.RSSI(i));
        Serial.println(" dBm");
#endif
        delay(10);
        ssidstrx[i] = WiFi.SSID(i);
        sigstrth[i] = WiFi.RSSI(i);
      }
    }
    thcntv = 0;
    //display ssids >
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 10, "Network(s) found:");
    String str1 = String("1 " + ssidstrx[0] + " " + sigstrth[0]);
    String str2 = String("2 " + ssidstrx[1] + " " + sigstrth[1]);
    String str3 = String("3 " + ssidstrx[2] + " " + sigstrth[2]);
    u8g2.setCursor(0, 23);
    u8g2.print(str1);
    u8g2.setCursor(0, 36);
    u8g2.print(str2);
    u8g2.setCursor(0, 49);
    u8g2.print(str3);
    u8g2.drawStr(0, bl5, "Select: ");
    u8g2.drawStr(60, bl5, "no change");
    u8g2.sendBuffer();
  }
  while (netconfig == true) {
    if (encoder_moved == true) {
      delay(50);  //##09.10a
      if (encoder_movedCW == true) {
        thcntv++;
        if (thcntv > 7) thcntv = 0;
      } else {
        thcntv--;
        if (thcntv < 0) thcntv = 7;
      }
      ssidx = "";
      u8g2.setDrawColor(0);
      u8g2.drawBox(40, 52, 88, 12);  //clear line 62 thcnt
      u8g2.setDrawColor(1);
      String numssid = String(thcntv);
      u8g2.setCursor(40, bl5);
      u8g2.print(numssid);
      if (thcntv == 0) u8g2.drawStr(60, bl5, "No change");
      if (thcntv == 7) u8g2.drawStr(60, bl5, "Enter SSID");
      if ((thcntv > 0) && (thcntv < 7)) {
        byte idx = thcntv - 1;
        ssidx = String(ssidstrx[idx]);
        signalx = sigstrth[idx];
      }
      u8g2.setCursor(60, bl5);
      u8g2.print(ssidx);
      u8g2.sendBuffer();
#ifdef LOG
      Serial.print("momentary selection: " + String(thcntv));
      if ((thcntv != 0) && (thcntv != 7)) {
        Serial.print(": ssid " + ssidx);
        Serial.println(", signal: " + String(signalx));
      }
      if (thcntv == 0) Serial.println(": no change");
      if (thcntv == 7) Serial.println(": Enter SSID");
#endif
      String str1 = String("1 " + ssidstrx[0] + " " + sigstrth[0]);
      String str2 = String("2 " + ssidstrx[1] + " " + sigstrth[1]);
      String str3 = String("3 " + ssidstrx[2] + " " + sigstrth[2]);
      String str4 = String("4 " + ssidstrx[3] + " " + sigstrth[3]);
      String str5 = String("5 " + ssidstrx[4] + " " + sigstrth[4]);
      String str6 = String("6 " + ssidstrx[5] + " " + sigstrth[5]);
      if (thcntv > 3) {
        u8g2.setDrawColor(0);
        u8g2.drawBox(0, 13, lw, 36);  //clear the 3 lines
        u8g2.setDrawColor(1);
        u8g2.setCursor(0, 23);
        u8g2.print(str4);
        u8g2.setCursor(0, 36);
        u8g2.print(str5);
        u8g2.setCursor(0, 49);
        u8g2.print(str6);
        u8g2.sendBuffer();
      }
      if (thcntv < 4) {
        u8g2.setDrawColor(0);
        u8g2.drawBox(0, 13, lw, 36);  //clear the 3 lines
        u8g2.setDrawColor(1);
        u8g2.setCursor(0, 23);
        u8g2.print(str1);
        u8g2.setCursor(0, 36);
        u8g2.print(str2);
        u8g2.setCursor(0, 49);
        u8g2.print(str3);
        u8g2.sendBuffer();
      }
      encoder_moved = false;
    }
    swtEstate = digitalRead(switchEpin);
    if ((swtEstate == LOW) && (swtEon == false)) {
      delay(dbcdly);
      swtEon = true;
      if ((thcntv > 0) && (thcntv < 7) && (signalx != 0)) {
        byte idx = thcntv - 1;
        ssidstr = String(ssidstrx[idx]);
        signalx = sigstrth[idx];
#ifdef LOG
        Serial.println("*netconfig*");
        Serial.println("SSID selected: " + String(ssidstr));
        Serial.println("thcntv: " + String(thcntv));
#endif
        if ((prvssidstr != ssidstr) && (thcntv != 0) && (thcntv != 7)) {
          //save to eeprom:
          len = ssidstr.length();
#ifdef LOG
          Serial.println("ssid length: " + String(len));
#endif
          if ((len > 0) && (len < 26)) {
            len++;  // include null terminator
            EEPROM.write(108, len & 0xff);
            byte j = 109;
            for (byte i = 0; i < len; i++) {
              EEPROM.write(j, ssidstr[i]);
              j++;
            }
            EEPROM.commit();
            //read back what was saved:
            ssidstr = "";
            j = 109;
            for (byte i = 0; i <= len; i++) {
              ssidstr = ssidstr + char(EEPROM.read(j));
              j++;
            }
            ssidstr.toCharArray(ssid, len);
#ifdef LOG
            Serial.print("SSID - length: " + String(len));
            Serial.print(", SSID: " + String(ssid));
            Serial.println(", saved to eeprom.");
#endif
          }
#ifdef LOG
          if (len < 1) Serial.println("Network may be hidden. Returned SSID length: " + len);
#endif
        }
        passconfig = true;
      } else if ((thcntv > 0) && (thcntv < 7) && (signalx == 0)) {
        u8g2.setDrawColor(0);
        u8g2.drawBox(40, 52, 88, 12);  //clear line 62 thcntv
        u8g2.setDrawColor(1);
        String text = "Invalid selection";
        u8g2.setCursor(40, bl5);
        u8g2.print(text);
        u8g2.sendBuffer();
#ifdef LOG
        Serial.println("Invalid selection");
#endif
      }
    }
    if ((swtEstate == HIGH) && (swtEon == true)) {
      delay(dbcdly);
      swtEon = false;
      if ((thcntv == 7) || (len <= 0)) ssidconfig = true;
      else passconfig = true;
      netconfig = false;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      netconfig = false;
      passconfig = true;
    }
  }
  //---------------enter network SSID manually---------->
  //##09.24 if (ssidconfig == true) {
  if ((ssidconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config SSID manually ***");
#endif
    swtEon = false;
    ssidchg = false;
    thcntv = 76;
    chcnt = 0;
    ssidstr = ssid;
    newssidstr = "";
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 9, "Set SSID; current:");
    u8g2.setCursor(0, 20);
    u8g2.print(ssid);
#ifdef LOG
    Serial.println("Current SSID: " + String(ssid));
#endif
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 0, lw, 20);  //clear lines 9 & 20
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 9, "Set Network SSID");
    u8g2.drawStr(0, 32, "To select char turn knob");
    u8g2.drawStr(0, 42, "To enter char push knob");
    u8g2.drawStr(0, 52, "default SSID press Dft");
    u8g2.drawStr(dspsos[1], bl5, "Dft");
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.sendBuffer();
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 0, lw, 11);   //clear line 9
    u8g2.drawBox(0, 10, lw, 12);  //clear line 20 "current ssid"
    u8g2.drawBox(0, 22, lw, 12);  //clear line 32
    u8g2.drawBox(0, 32, lw, 12);  //clear line 42
    u8g2.drawBox(0, 42, lw, 12);  //clear line 52
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 9, "Enter new SSID");
    u8g2.drawStr(0, 24, "Enter characters>");
    u8g2.drawStr(0, 52, "To add char push knob");
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);

    u8g2.setDrawColor(0);
    u8g2.drawBox(99, 10, 19, 18);  //clear large character
    u8g2.setDrawColor(1);
  }
  while (ssidconfig == true) {
    if (encoder_moved == true) {
      delay(50);  //##09.10a
      characterwheel();
      ssidchg = true;
      encoder_moved = false;
    }
    swtEstate = digitalRead(switchEpin);
    if ((swtEstate == LOW) && (swtEon == false)) {
      delay(dbcdly);
      swtEon = true;
      if (ssidchg == true) {
        newssidstr = newssidstr + newchar;
        u8g2.setDrawColor(0);
        u8g2.setDrawColor(1);
        u8g2.setFont(sfont);
        u8g2.setCursor(0, 38);
        u8g2.print(newssidstr);
        u8g2.sendBuffer();
        chcnt++;
#ifdef LOG
        Serial.println("SSID string so far: " + newssidstr);
#endif
      }
    }
    if ((swtEstate == HIGH) && (swtEon == true)) {
      delay(dbcdly);
      swtEon = false;
    }
    //set default SSID:
    swt2state = digitalRead(switch02pin);
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      newssidstr = dftssid;
      ssidchg = true;
      u8g2.clearDisplay();
      u8g2.setFont(sfont);
      u8g2.drawStr(0, 9, "Default SSID:");
      u8g2.setCursor(0, 24);
      u8g2.print(newssidstr);
      u8g2.drawStr(0, 50, "To save/exit press");
      u8g2.drawBitmap(90, 43, 2, 7, enter);
      u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
      u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
      u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    // erase:
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {
      delay(dbcdly);
      swt0on = true;
      if (chcnt > 0) chcnt--;
      newssidstr.remove(chcnt, 1);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 28, lw, 12);  //clear line 38
      u8g2.setDrawColor(1);
      u8g2.setFont(sfont);
      u8g2.setCursor(0, 38);
      u8g2.print(newssidstr);
      u8g2.sendBuffer();
#ifdef LOG
      Serial.println("SSID string corrected: " + newssidstr);
#endif
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
    }
    //cancel/exit:
    swt1state = digitalRead(switch01pin);
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      delay(dbcdly);
      swt1on = false;
      ssidconfig = false;
      passconfig = true;
    }
    // exit:
    swt3state = digitalRead(switch03pin);
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      if ((ssidchg == true) && (ssidstr != newssidstr)) {
        len = newssidstr.length();
#ifdef LOG
        Serial.println("SSID length " + String(len));
#endif
        if ((len > 0) && (len < 26)) {
          len++;  // include null terminator
          // save SSID:
          // 108=ssid-length, 109-133=ssid
          EEPROM.write(108, len & 0xff);
          byte j = 109;
          for (byte i = 0; i < len; i++) {
            EEPROM.write(j, newssidstr[i]);
            j++;
          }
          EEPROM.commit();
          // read back:
          newssidstr = "";
          j = 109;
          //len++;
          for (byte i = 0; i <= len; i++) {
            newssidstr = newssidstr + char(EEPROM.read(j));
            j++;
          }
          newssidstr.toCharArray(ssid, len);
#ifdef LOG
          Serial.println("*ssidconfig*");
          Serial.print("SSID length: " + String(len));
          Serial.print(", SSID: " + newssidstr);
          Serial.println(", saved to eeprom.");
#endif
        }
      }
#ifdef LOG
      else
        Serial.println("Entered Network SSID same as old.");
#endif
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      ssidconfig = false;
      passconfig = true;
    }
  }
  // network pass key config: --------------------------------
  //##09.24 if (passconfig == true) {
  if ((passconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config Pass-Key ***");
#endif
    swtEon = false;
    passchg = false;
    thcntv = 76;  //on 1st encoder move ccw it goes to 75=end , cw it goes to 0=start
    chcnt = 0;
    passstr = pass;
    newpassstr = "";
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    //------------------
    //display pass key:
#ifdef DSPNETKEY
    u8g2.drawStr(0, 9, "Set Pass key, current:");
    u8g2.setCursor(0, 20);
    u8g2.print(pass);
#endif
#ifdef LOG LOGNETKEY
    Serial.println("Current pass key: " + String(pass));
#endif
    //------------------
#ifndef DSPNETKEY
    u8g2.drawStr(35, 9, "Set Pass key");
#endif
    u8g2.drawStr(0, 32, "To select char turn knob");
    u8g2.drawStr(0, 42, "To enter char push knob");
    u8g2.drawStr(0, 52, "For default pwd press Dft");
    u8g2.drawStr(dspsos[1], bl5, "Dft");
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.sendBuffer();
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 0, lw, 11);   //clear line 9
    u8g2.drawBox(0, 10, lw, 12);  //clear line 20 "current pwd"
    u8g2.drawBox(0, 22, lw, 12);  //clear line 32
    u8g2.drawBox(0, 32, lw, 12);  //clear line 42
    u8g2.drawBox(0, 42, lw, 12);  //clear line 52
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, 9, "Enter new pass key");
    u8g2.drawStr(0, 24, "Enter characters>");
    u8g2.drawStr(0, 52, "To add char push knob");
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);

    u8g2.setDrawColor(0);
    u8g2.drawBox(99, 10, 19, 18);  //clear large character
    u8g2.setDrawColor(1);
  }
  while (passconfig == true) {
    if (encoder_moved == true) {
      delay(50);  //##09.10a
      characterwheel();
      passchg = true;
      encoder_moved = false;
    }
    swtEstate = digitalRead(switchEpin);
    if ((swtEstate == LOW) && (swtEon == false)) {
      delay(dbcdly);
      swtEon = true;
      if (passchg == true) {
        newpassstr = newpassstr + newchar;
        u8g2.setDrawColor(0);
        u8g2.setDrawColor(1);
        u8g2.setFont(sfont);
        u8g2.setCursor(0, 38);
        u8g2.print(newpassstr);
        u8g2.sendBuffer();
        chcnt++;
#ifdef LOG
        Serial.println("pass key string so far: " + newpassstr);
#endif
      }
    }
    if ((swtEstate == HIGH) && (swtEon == true)) {
      delay(dbcdly);
      swtEon = false;
    }
    //set default pass key:
    swt2state = digitalRead(switch02pin);
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      newpassstr = dftpass;
      passchg = true;
      u8g2.clearDisplay();
      u8g2.setFont(sfont);
      u8g2.drawStr(0, 9, "Default pass key:");
      u8g2.setCursor(0, 24);
      u8g2.print(newpassstr);
      u8g2.drawStr(0, 50, "To save/exit press");
      u8g2.drawBitmap(90, 43, 2, 7, enter);
      u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
      u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
      u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    // erase:
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {
      delay(dbcdly);
      swt0on = true;
      if (chcnt > 0) chcnt--;
      newpassstr.remove(chcnt, 1);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 28, lw, 12);  //clear line 38
      u8g2.setDrawColor(1);
      u8g2.setFont(sfont);
      u8g2.setCursor(0, 38);
      u8g2.print(newpassstr);
      u8g2.sendBuffer();
#ifdef LOG
      Serial.println("pass key string corrected: " + newpassstr);
#endif
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
    }
    //cancel/exit:
    swt1state = digitalRead(switch01pin);
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      delay(dbcdly);
      swt1on = false;
      passconfig = false;
      hostconfig = true;
    }
    // exit:
    swt3state = digitalRead(switch03pin);
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      //if (passchg == true) {
      if ((passchg == true) && (passstr != newpassstr)) {
        len = newpassstr.length();
#ifdef LOG
        Serial.println("pass length " + String(len));
#endif
        if ((len > 0) && (len < 26)) {
          len++;  // include null terminator
          // save pass key:
          EEPROM.write(135, len & 0xff);
          byte j = 136;
          for (byte i = 0; i < len; i++) {
            EEPROM.write(j, newpassstr[i]);
            j++;
          }
          EEPROM.commit();
          // read back:
          newpassstr = "";
          j = 136;
          //len++;
          for (byte i = 0; i <= len; i++) {
            newpassstr = newpassstr + char(EEPROM.read(j));
            j++;
          }
          newpassstr.toCharArray(pass, len);
#ifdef LOG
          Serial.println("pass key saved to eeprom: " + newpassstr);
          Serial.println("pass key for sending: " + String(pass));
#endif
        }
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      passconfig = false;
      hostconfig = true;
    }
  }
  // host ip address config: -------------------------
  //##09.24 if (hostconfig == true) {
  if ((hostconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config Host IP Address ***");
#endif
    hostchg = false;
    hoststr = host;
    newhoststr = "";
#ifdef LOG
    Serial.println("Host IP address in storage: " + String(host));
#endif
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 9, "Set Host @; current:");
    u8g2.setCursor(0, 22);
    u8g2.print(host);
    u8g2.drawStr(0, 42, "Enter IP @ via keypad");
    u8g2.drawStr(0, 52, "For default IP @ press Dft");
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawStr(dspsos[1], bl5, "Dft");
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
    u8g2.sendBuffer();
    btncnt = 0;
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 32, lw, 12);  //clear line 42
    u8g2.drawBox(0, 42, lw, 12);  //clear line 52
    u8g2.setDrawColor(1);
  }
  while (hostconfig == true) {
    kpread = analogRead(keypadin);
    //end if (kpread > keypadarray[32]) {
    if (kpread > kpnone) {
      delay(dbcdly);
      if (kpbtnstate == false) kparrReadN();
    }
    // All keypad buttons released:
    else if ((kpread == 0) && (kpbtnstate == true)) {
      kpbtnstate = false;
    }
    if (pshnbr == true) {
      dspchghost();
      hostchg = true;
      pshnbr = false;
#ifdef LOG
      Serial.println("variable host contains: " + String(host));
#endif
    }
    //store default host @:
    swt2state = digitalRead(switch02pin);
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      newhoststr = dfthost;
      hostchg = true;
      u8g2.clearDisplay();
      u8g2.setFont(sfont);
      u8g2.drawStr(0, 9, "Default Host IP@:");
      u8g2.setCursor(0, 22);
      u8g2.print(newhoststr);
      u8g2.drawStr(0, 50, "To save/exit press");
      u8g2.drawBitmap(90, 43, 2, 7, enter);
      u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
      u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
      u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    // erase:
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {
      delay(dbcdly);
      swt0on = true;
      if (btncnt > 0) btncnt--;
      newhoststr.remove(btncnt, 1);
      dspchghost();
#ifdef LOG
      Serial.println("character erased, variable host now contains: " + String(host));
#endif
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
    }
    //cancel/exit:
    swt1state = digitalRead(switch01pin);
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      delay(dbcdly);
      swt1on = false;
      hostconfig = false;
      portconfig = true;
    }
    // save/exit:
    swt3state = digitalRead(switch03pin);
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      //if (hostchg == true) {
      if ((hostchg == true) && (newhoststr != hoststr)) {
        len = newhoststr.length();
#ifdef LOG
        Serial.println("ip length " + String(len));
#endif
        if ((len > 0) && (len < 16)) {
          len++;  // include null terminator
          // save host ip:
          EEPROM.write(162, len & 0xff);
          byte j = 163;
          for (byte i = 0; i < len; i++) {
            EEPROM.write(j, newhoststr[i]);
            j++;
          }
          EEPROM.commit();
          // read back:
          newhoststr = "";
          j = 163;
          //len++;
          for (byte i = 0; i <= len; i++) {
            newhoststr = newhoststr + char(EEPROM.read(j));
            j++;
          }
          newhoststr.toCharArray(host, len);
#ifdef LOG
          Serial.println("host written to eeprom: " + newhoststr);
          Serial.println("host ip for sending: " + String(host));
#endif
        }
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      hostconfig = false;
      portconfig = true;
    }
  }
  // port number config: -------------------------
  //##09.24 if (portconfig == true) {
  if ((portconfig == true) && (strupcfg == true)) {  //##09.24
#ifdef LOG
    Serial.println("*** Config Port# ***");
#endif
    portchg = false;
    lastport = port;
#ifdef LOG
    Serial.println("Port nbr in storage: " + String(port));
#endif
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 9, "Set Port; current:");
    u8g2.setCursor(10, 22);
    u8g2.print(port);
    u8g2.drawStr(0, 40, "Enter Port # via keypad");
    u8g2.drawStr(0, 52, "For default port press Dft");
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawStr(dspsos[1], bl5, "Dft");
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
    u8g2.sendBuffer();
    btncnt = 0;
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, 30, lw, 12);  //clear line 40
    u8g2.setDrawColor(1);
  }
  while (portconfig == true) {
    kpread = analogRead(keypadin);
    if (kpread > kpnone) {
      delay(dbcdly);
      if (kpbtnstate == false) kparrReadN();
    }
    // All keypad buttons released:
    else if ((kpread == 0) && (kpbtnstate == true)) {
      kpbtnstate = false;
    }
    if (pshnbr == true) {
      dspchgport();
      portchg = true;
      pshnbr = false;
#ifdef LOG
      Serial.println("port number so far: " + String(port));
#endif
    }
    //store default port nbr:
    swt2state = digitalRead(switch02pin);
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      port = dftport;
      portchg = true;
      u8g2.clearDisplay();
      u8g2.drawStr(0, 9, "Default Port nbr:");
      u8g2.setCursor(10, 22);
      u8g2.print(port);
      //u8g2.drawStr(0, 52, "Press Stop to save/cont.");
      u8g2.drawStr(0, 50, "To save/exit press");
      u8g2.drawBitmap(90, 43, 2, 7, enter);
      u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
      u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
      u8g2.drawBitmap(dspsos[3], 55, 2, 8, oops);
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      swt2on = false;
      // step back/retry:
    }
    swt0state = digitalRead(switch0pin);
    if ((swt0state == LOW) && (swt0on == false)) {
      delay(dbcdly);
      swt0on = true;
      rmvportdgt();
      dspchgport();
#ifdef LOG
      Serial.println("character erased, port number: " + String(port));
#endif
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      delay(dbcdly);
      swt0on = false;
    }
    //cancel/exit:
    swt1state = digitalRead(switch01pin);
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      delay(dbcdly);
      swt1on = false;
      portconfig = false;
      locconfig = true;
      sndconfig = true;
      sstoconfig = true;
      goto locsetup;  // local or remote - home or club?
    }
    // exit:
    swt3state = digitalRead(switch03pin);
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
#ifdef LOG
      Serial.println("Save/exit: port nbr in variable: " + String(port));
#endif
      if ((portchg == true) && (port != lastport)) {
        if ((port > 1023) && (port <= 65535)) {  //valid port numbers
          // save port#:
          EEPROM.write(180, (port >> 8) & 0xff);
          EEPROM.write(181, port & 0xff);
          EEPROM.commit();
          // read back:
          int port = EEPROM.read(180);
          port = (port << 8) + EEPROM.read(181);
#ifdef LOG
          Serial.println("Save/exit: port number saved to storage: " + String(port));
#endif
        }
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      portconfig = false;
      locconfig = true;
      sndconfig = true;
      sstoconfig = true;
      goto locsetup;  // local or remote - home or club?
    }
    if (btncnt > 5) btncnt = 0;
  }  // while... closed
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#ifdef STARTUPLOC
  if (setuplocflag == false) locselect = true;  //##10.1 ##10.2
#endif                                          //##10.1
  //##10.1 if (strupcfg == false) { //##09.24 display location selection in normal startup:
  //##10.1 locselect = true;
  if (locselect == true) {  //##10.1
#ifdef LOG
    Serial.println("*** Select Location ***");
#endif
    prvloc = location;
    location = EEPROM.read(95);
    u8g2.clearDisplay();
    u8g2.setDrawColor(1);  //white
    u8g2.drawStr(36, 9, "Select location");
    //u8g2.drawStr(0, 24, "Location: ");
    u8g2.setFont(lfont);
    //u8g2.setCursor(60, 24);
    u8g2.setCursor(0, 24);
    u8g2.print(thrloc);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, 38, "To chg location press");
    u8g2.drawBitmap(110, 32, 2, 7, swap);
    u8g2.drawStr(0, 50, "To save/exit press");
    u8g2.drawBitmap(90, 43, 2, 7, enter);
    u8g2.drawBitmap(dspsos[0], 55, 2, 7, enter);
    u8g2.drawBitmap(dspsos[1], 56, 2, 7, swap);
    u8g2.drawBitmap(dspsos[2], 55, 2, 8, skip);
    u8g2.sendBuffer();
    if (location == 1) rtvnetcreds();
    else rtvdftnetcreds();
#ifdef LOG
    Serial.println("Current location: " + String(location));
#endif
  }
  unsigned long pushtime = millis();
  while (locselect == true) {
    if (millis() > pushtime + 12000) {  //after 12 sec - skip
      locselect = false;
      if (location == 1) rtvnetcreds();  //##10.2
      else rtvdftnetcreds();             //##10.2
      break;
    }
    swt2state = digitalRead(switch02pin);  // swap location
    if ((swt2state == LOW) && (swt2on == false)) {
      delay(dbcdly);
      swt2on = true;
      location = (location == 0) ? 1 : 0;
      pushtime = millis();  //##09.24a reset timeout
#ifdef LOG
      Serial.println("Location change: " + String(location));
#endif
      if (location == 1) rtvnetcreds();
      else rtvdftnetcreds();
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, 10, lw, 16);  //clear line 24 large "local/remote-Home/Club"
      u8g2.drawBox(0, 28, lw, 12);  //clear line 38 "To switch loc...."
      u8g2.setDrawColor(1);
      u8g2.setFont(lfont);
      String thrloc = String(locthrottle[location]);
      u8g2.setCursor(0, 24);
      u8g2.print(thrloc);  // display remote or local - Club or Home
      u8g2.setFont(sfont);
      u8g2.setCursor(0, 38);
      u8g2.print(String(ssid));
      u8g2.sendBuffer();
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      delay(dbcdly);
      swt2on = false;
    }
    swt1state = digitalRead(switch01pin);  // skip
    if ((swt1state == LOW) && (swt1on == false)) {
      delay(dbcdly);
      swt1on = true;
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locselect = false;
    }
    swt3state = digitalRead(switch03pin);  // save/exit
    if ((swt3state == LOW) && (swt3on == false)) {
      delay(dbcdly);
      swt3on = true;
      if (location != prvloc) {
#ifdef LOG
        Serial.println("Saving new location: " + String(locthrottle[location]));
#endif
        EEPROM.write(95, location);
        EEPROM.commit();
        prvloc = location;
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      delay(dbcdly);
      swt3on = false;
      u8g2.clearDisplay();
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      locselect = false;
    }
  }  //##09.24
     //##10.1 #endif //STARTUPLOC
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  strupcfg = false;  //##09.24
#ifdef LOG
  Serial.println("Using Network ID, IP-Address: ");
  Serial.print(String(ssid) + ", ");
#ifdef LOGNETKEY
  Serial.print(String(pass) + ", ");
#endif
  Serial.print(String(host) + ":");
  Serial.println(String(port));
  Serial.println("*** End of Throttle Startup-Configuration ***");
#endif
  //--------------  end of throttle setup ---------------------------------------
  u8g2.clearDisplay();
  u8g2.setFont(sfont);
  u8g2.setDrawColor(1);
  u8g2.setCursor(0, 9);
  u8g2.print(dsptname);
  //----------------------------
  /* connecting to a WiFi network **************************************************/
  u8g2.drawStr(45, 9, "connecting WiFi");
  u8g2.setCursor(0, 24);
  u8g2.print(ssid);
  u8g2.sendBuffer();
#ifdef LOG
  Serial.print("Starting WiFi");
#endif
  bool wifiretry = false;
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
#ifdef LOG
    Serial.print('.');
#endif
    delay(1000);
    cntt++;
    if ((cntt > 10) && (wifiretry == false)) {
      WiFi.disconnect();
      wifiretry = true;
      delay(1000);
#ifdef LOG
      Serial.println();
      Serial.println("Setup: disconnecting/reconnecting WiFi.");
#endif
      WiFi.begin(ssid, pass);
    }
    swtSstate = digitalRead(switchSpin);
    if ((cntt > 60) || (swtSstate == LOW)) {
      swtSstate = HIGH;
#ifdef LOG
      Serial.println();
      if (cntt > 60) Serial.println("Setup: WiFi connection failed");
      else Serial.println("Setup: WiFi connection cancelled");
#endif
      u8g2.setDrawColor(0);
      u8g2.drawBox(43, 0, 85, 12);  //clear line 9
      u8g2.setDrawColor(1);
      u8g2.setCursor(0, 9);
      u8g2.print(dsptname);
      u8g2.drawStr(45, 9, "offline");
      u8g2.sendBuffer();
      WiFi.disconnect();
      wifi_ok = false;
#ifdef LOG
      Serial.println("Setup: " + String(ssid) + " disconnected");
#endif
      goto bailout;
    }
  }
  //--------------
  if (wifi_ok == true) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(43, 0, 85, 12);  //clear line 9
    u8g2.setDrawColor(1);
    u8g2.setCursor(0, 9);
    u8g2.print(dsptname);
    u8g2.drawStr(45, 9, "WiFi connected");
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Setup: " + String(ssid) + " connected ");
    ip = WiFi.localIP();
    Serial.print("Client IP address: ");
    Serial.println(ip);
#endif
    MacString = WiFi.macAddress();
    delay(2000);
    u8g2.clearDisplay();
    u8g2.setCursor(0, 9);
    u8g2.print(dsptname);
    u8g2.drawStr(45, 9, "Connecting svr");
    String dsptext = String(host) + ":" + String(port);
    u8g2.setCursor(0, bl2);
    u8g2.print(dsptext);
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Setup: starting connection to WiThrottle server");
    Serial.print("Server IP: ");
    Serial.print(host);
    Serial.println(":" + String(port));
    Serial.print("connecting");
#endif
    cntc = 6;
    cntt = 0;
    client.connect(host, port);
    while (!client.connected()) {
      delay(1000);
#ifdef LOG
      Serial.print(cntc);
      Serial.print('.');
#endif
      cntc--;
      cntt++;
      if (cntc <= 0) {
        cntc = 6;
#ifdef LOG
        Serial.println("retrying");
#endif
        client.connect(host, port);  //retrying
      }
      swtSstate = digitalRead(switchSpin);
      if ((cntt > 60) || (swtSstate == LOW)) {
        swtSstate = HIGH;
#ifdef LOG
        Serial.println();
        Serial.println("Setup: server not responding, closing.");
#endif
        client.stop();
        u8g2.setDrawColor(0);
        u8g2.drawBox(43, 0, 85, 12);  //clear line 9
        u8g2.setDrawColor(1);
        u8g2.setCursor(0, 9);
        u8g2.print(dsptname);
        u8g2.drawStr(43, 9, "svr offline");
        u8g2.sendBuffer();
        WiFi.disconnect();
#ifdef LOG
        Serial.println("Setup: " + String(ssid) + " disconnected");
#endif
        svr = false;
        wifi_ok = false;
        //return;
        goto bailout;  // continue without connection for testing
      }
    }
  }
  //connected >>>
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(43, 0, 85, 12);  //clear line 9 after tname
  u8g2.setDrawColor(1);
  u8g2.setCursor(0, 9);
  u8g2.print(dsptname);
  u8g2.drawStr(45, 9, "online");
  u8g2.sendBuffer();
  getsiglvl();
#ifdef BATLEVEL
  getbatlvl();
#endif
#ifdef LOG
  Serial.println();
  Serial.println("Setup: Sending throttle name: N" + tname);
#endif
  dsptr(1);
  client.print("N" + tname + "\r\n");  // send throttle name
  delay(sdelay);
  while (client.available()) {
    jmri_res = client.readStringUntil('\n');
#ifdef LOG
    Serial.print("Setup: from WiThrottle server: ");
    Serial.println(jmri_res);
#endif
    if (jmri_res.startsWith("RL")) {
      roster = jmri_res;  // save roster
      ros_Avail = true;   //##09.12
    }
    if (jmri_res.startsWith("PRL")) {
      routes = jmri_res;  // save route list
      rts_Avail = true;
    }
    if (jmri_res.startsWith("PTL")) {
      turnouts = jmri_res;  // save turnout list
      trn_Avail = true;
    }
    if (jmri_res.startsWith("Ht")) {
      svrmsg = jmri_res.substring(2, 35);  // save server TYPE message
    }
#ifdef LOG
    if (jmri_res.startsWith("PPA")) {  //track power
      String p = jmri_res.substring(3, 4);
      int pwr = p.toInt();
      Serial.println("Track power: " + String(pwr));
      if (pwr == 0) Serial.println("Track power is OFF");
      if (pwr == 1) Serial.println("Track power is ON");
      if (pwr == 2) Serial.println("Not sure if Track has power");
    }
#endif
    //-------------------------------------------------------------
    if (jmri_res.startsWith("*")) {  //heartbeat
#ifdef LOG
      Serial.print("received heart beat setting from server: ");
      Serial.println(jmri_res);
#endif
      hbres = jmri_res;                    // save heartbeat value
      String hbs = hbres.substring(1, 3);  // get heart beat interval
      hbitv = hbs.toInt();
      if (hbitv > 5) {
        cntf = hbitv / 1.5;
        ch = (int)cntf;
        hbuse = true;
#ifdef LOG
        Serial.print("Setup: throttle will send heart beat in intervals of: ");
        Serial.print(hbitv);
        Serial.println(" seconds.");
#endif
      }
    }
  }
  if (hbuse == false) {
    ch = 12;  //value needed for checking connection status if heart beat is not used.
#ifdef LOG
    Serial.print("Setup: heart beat interval = ");
    Serial.println(ch);
#endif
  }
  cnth = ch;
#ifdef LOG
  Serial.print("Setup: detected WiThrottle server type: ");
  Serial.println(svrmsg);
  Serial.print("Sending MAC: HU");
  Serial.println(MacString);
#endif
  client.print("HU" + MacString + "\r\n");  // set identifier
  dsptr(0);
/**end of WiFi connection startup ***********************************************/
#ifdef LOG
  if (ros_Avail == true) Serial.print("roster list: " + roster);  //##09.12
  if (rts_Avail == true) Serial.println("route list: " + routes);
  if (trn_Avail == true) Serial.println("turnout list: " + turnouts);
#endif
  //----build index of roster entries----:
  if (ros_Avail == true) {      //##09.12
    rxn = roster.indexOf('L');  // find first roster entry for nbr of entries RLnn]
    rxn = rxn + 1;
    rxnn = roster.indexOf(']');
    rosne = roster.substring(rxn, rxnn);     // get nbr of roster entries
    numre = rosne.toInt();                   // convert to integer
    if (numre > 0) {                         // making sure we got a working value
      if (numre > numrose) numre = numrose;  // limit number of roster entries
      numos = numre - 1;                     // offsets start with 0
      for (int i = 0; i <= numos; i++) {
        rxn = roster.indexOf('[', rxnn);
        rxn++;
        rosnamoffsets[i] = rxn;
        rxnn = rxn + 1;
        int rxa = roster.indexOf('{', rxnn);
        rxa++;
        rosadroffsets[i] = rxa;
        rxnn = rxa + 1;
      }
#ifdef LOG
      Serial.print("nbr of roster entries: ");
      Serial.println(numre);
      Serial.print("roster name offsets: ");
      for (int i = 0; i <= numos; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(rosnamoffsets[i]);
      }
      Serial.println();
      Serial.print("roster address offsets: ");
      for (int i = 0; i <= numos; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(rosadroffsets[i]);
      }
      Serial.println();
#endif
    }
  }
  //----build index of route entries---->>>:
  if (rts_Avail == true) {
    rxnn = 0;
    rxn = 0;
    // PRL]\[IO...}|{usrname}|{
    for (byte i = 0; i < maxnbrrts; i++) {
      rxn = routes.indexOf("IO", rxnn);  // count sysname entries
      if (rxn < 1) break;
      numrts++;
      rxn = rxn + 2;
      rxnn = rxn + 1;
    }
#ifdef LOG
    Serial.print("Setup: Routes counted: ");
    Serial.println(numrts);
#endif
    if (numrts > 0) {
      rxnn = 0;
      numrtos = numrts - 1;
      for (byte i = 0; i < numrts; i++) {
        rxn = routes.indexOf("IO", rxnn);
        rsosa[i] = rxn;  // store index of sysname
        rxnn = rxn + 1;
        int rxa = routes.indexOf('{', rxnn);
        rxa++;
        ruosa[i] = rxa;  // store index of usrname
        rxnn = rxa + 1;
      }
#ifdef LOG
      Serial.println("route sysname offsets");
      for (int i = 0; i < numrts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(rsosa[i]);
      }
      Serial.println();
      Serial.println("route usrname offsets");
      for (int i = 0; i < numrts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(ruosa[i]);
      }
      Serial.println();
#endif
    }  //else rts_Avail = false;
  }
  //----build index of turnout entries----->>>:
  if (trn_Avail == true) {
    rxnn = 0;
    rxn = 0;
    // PTL]\[XT201}|{usrname}|{1]  (X=Xpressnet, 201=accessory address, 1=state)
    // "XT201" = system name of turnout. Instead of X could be an L for (I beleave) Loconet?
    // T = turnout (?), 201 = assessory address.
    for (byte i = 0; i < maxnbrtrns; i++) {
      rxn = turnouts.indexOf("[", rxnn);  // count sysname entries
      if (rxn < 1) break;
      numts++;
      rxn++;
      rxnn = rxn + 1;
    }
#ifdef LOG
    Serial.print("Setup: Turnouts counted: ");
    Serial.println(numts);
#endif
    if (numts > 0) {
      rxnn = 0;
      numtos = numts - 1;
      for (byte i = 0; i < numts; i++) {
        rxn = turnouts.indexOf('[', rxnn);
        rxnn = rxn + 3;   // point to address
        tsosa[i] = rxnn;  // store index of accessory address
        int rxa = turnouts.indexOf('{', rxnn);
        rxa++;
        tuosa[i] = rxa;  // store index of usrname
        rxnn = rxa + 1;
        int rxb = turnouts.indexOf('{', rxnn);
        rxb++;
        tstosa[i] = rxb;  // store index of state
        rxnn = rxb + 1;
      }
#ifdef LOG
      Serial.println("turnout sysname (address) offsets");
      for (int i = 0; i < numts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(tsosa[i]);
      }
      Serial.println();
      Serial.println("turnout usrname offsets");
      for (int i = 0; i < numts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(tuosa[i]);
      }
      Serial.println();
      Serial.println("turnout state offsets");
      for (int i = 0; i < numts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(tstosa[i]);
      }
      Serial.println();
#endif
    }  //else trn_Avail = false;
  }
  /*--------------------------------------------------------*/
  rtvrosnam();
  if (ros_eAvail == true) getrosnamen();
bailout:
  sprintf(dspadr, "%04d", dccadr[MTx]);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl2, lw, 13);  //clear host:port (line 25)
  u8g2.drawBox(0, tl3, lw, 16);  //clear loco address from loco name area
  u8g2.setDrawColor(1);
  u8g2.setFont(lfont);
  u8g2.setCursor(85, bl2);
  u8g2.print(dspadr);  // dccadr with leading zero's
  u8g2.drawStr(120, bl2, "?");
  u8g2.sendBuffer();
#ifdef LOG
  Serial.print("Setup: last dcc addr: ");
  Serial.println(dspadr);
#endif
  rtvrosnam();
  dsprosnam();
  if (bitRead(dctstate, MTx) == 1) {
    //u8g2.drawStr(0, 25, "F");
    u8g2.drawBitmap(0, tl2, 1, 11, forward);
  } else {
    //u8g2.drawStr(0, 25, "R");
    u8g2.drawBitmap(0, tl2, 1, 11, reverse);
  }
  u8g2.setCursor(15, bl2);
  u8g2.print(dspeed);
  u8g2.setFont(sfont);
  u8g2.drawStr(0, bl4, "Fg");
  u8g2.setCursor(15, bl4);
  u8g2.print(String(fcgstate[MTx]));
  u8g2.sendBuffer();
  delay(1000);
  // simulate first address button push, so next push takes address from stack
  bitWrite(setdccadr, MTx, 1);
  adrbtnstate = 1;
  if (hbuse == true) {
#ifdef LOG
    Serial.println("Setup: Sending *+ 'start heart beat'.");
#endif
    client.print("*+\r\n");  // starting heartbeat
  }
  cntd = cd;
  cntb = cb;
#ifdef BATLEVEL
  getbatlvl();
#endif
#ifdef LOG
  if (MThr == true) {
    Serial.println("This device is set as Multi Throttle.");
    Serial.print("Number of Throttles : ");
    Serial.println(numthrottles);
  }
  if (numthrottles == 1) {
    Serial.println("This device is set as Single Throttle.");
  }
  //Serial.println("Location: " + String(locthrottle[location]));
  Serial.print("Location: ");
  Serial.println(locthrottle[location]);
  //Serial.println("Default sound function key: " + String(dftsndfctst[dsndfct]));
  Serial.print("Default sound function key: ");
  Serial.println(dftsndfctst[dsndfct]);
  Serial.println();
  Serial.println("*******Setup complete*******");
  Serial.println();
#endif
}
/*************************************************************************************/
void loop() {
  if (Serial.available() > 0) {
    int indata = Serial.read();
    if ((indata == 'V') || (indata == 'v')) {
      Serial.println(vrs);
      if (svr == true) Serial.println("Server: " + svrmsg);
    }
    if ((indata == 'C') || (indata == 'c')) {
      Serial.println(vrs);
      Serial.println("4x4 keypad configurator.");
      Serial.println("Serial monitor should be in 'No Line Ending' mode.");
      keypad_check();
      keypad_config();
    }
  }
  if (svr == true) {  //look for incoming message
    if (client.available()) {
      dsptr(1);
      jmri_res = client.readStringUntil('\n');
      flushnull = client.readString();  // flush input buffer, rid of '\n'
      // look for fast clock time stamp from jmri:
      bool nolog = false;
#ifdef CLOCK
      if (jmri_res.startsWith("PFT")) {
        nolog = true;  // PFT is handled in logtime
#ifdef LOGTIME
        Serial.println("Received time stamp: ");
        Serial.println(jmri_res);
#endif  //LOGTIME
        getjmritime();
        cnth--;  //loosing 1 sec count down during inbound message
      }
      if (jmri_res.startsWith("RCC")) {  //##09.08
                                         //the server is slow for getting ready if consists exist and svr is set to update CV19
#ifdef LOG
        nolog = true;
        ready = true;
        Serial.println(jmri_res);
        Serial.println("Server ready to process throttle commands");
        u8g2.setDrawColor(0);
        u8g2.drawBox(43, 0, 47, 12);  //clear line 9 after tname before 91 (signal)
        u8g2.setDrawColor(1);
        u8g2.setFont(sfont);
        u8g2.drawStr(45, 9, "Ready");  //##09.08
        u8g2.sendBuffer();
#endif
      }
#endif           //ifdef CLOCK
      dsptr(2);  //turn ind off w/o hb timer reset
#ifdef DEBUG
      if ((nolog == false) && (inhmsglog == false)) {
        Serial.print("Received message: ");
        Serial.println(jmri_res);  // look for any msg
      }
#endif
    }
  }
  // timers:
  crntMs = millis();
  if (crntMs - prvsMs >= 1000) {  // 1 second interval timer
    prvsMs = crntMs;
    cnth--;  // heart beat
    cntd--;  // screen saver
    cntb--;  // battery monitor
  }
  if (cnth <= 0) {  // heartbeat time
    if ((svr == true) && (hbuse == true)) {
      if (hben = true) {
#ifdef LOGHB
        Serial.println("Sending heartbeat");
#endif
        client.print("*\r\n");  // send heart beat
      }
    }
    cnth = ch;
    // still connected?:
    if ((!client.connected()) && (svr == true) && (wifi_ok == true)) {
      signalx = WiFi.RSSI();
#ifdef LOG
      Serial.println("Main: Throttle offline.");
      Serial.print("Signal: ");
      Serial.print(signalx);
      Serial.println(" dBm");
#endif
      if (dsplon == false) display_on();
      getsiglvl();
      u8g2.setFont(sfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(43, 0, 47, 12);
      u8g2.drawBox(0, tl3, lw, 16);  //clear loconame
      u8g2.setDrawColor(1);
      u8g2.setCursor(0, 9);
      u8g2.print(dsptname);
      u8g2.drawStr(45, 9, "No WiFi");
      u8g2.sendBuffer();
      svr = false;
      wifi_ok = false;
      WiFi.disconnect();
      delay(1000);
      if (recon == false) {
#ifdef LOG
        Serial.print("Main: Attempting to reconnect WiFi.");
#endif
        cntt = 0;
        cntb = cb;
        recon = true;
        WiFi.begin(ssid, pass);
        while (WiFi.status() != WL_CONNECTED) {
#ifdef LOG
          Serial.print('.');
#endif
          delay(1000);
          cntt++;
          swtSstate = digitalRead(switchSpin);
          if ((cntt > 60) || (swtSstate == LOW)) {
            swtSstate = HIGH;
#ifdef LOG
            Serial.println();
            Serial.println("Main: WiFi connection failed");
#endif
            cntd = cd;
            cntt = 60;
            return;
          }
        }
        wifi_ok = true;
        getsiglvl();
#ifdef LOG
        Serial.println();
        Serial.println("Main: Reconnecting server");
#endif
        u8g2.setDrawColor(0);
        u8g2.drawBox(43, 0, 85, 12);
        u8g2.setDrawColor(1);
        u8g2.drawStr(45, 9, "Reconnect");
        u8g2.sendBuffer();
        cntc = 6;
        cntt = 0;
        svr = true;
        client.connect(host, port);
        while (!client.connected()) {
          delay(1000);
#ifdef LOG
          Serial.print(cntc);
          Serial.print('.');
#endif
          cntc--;
          cntt++;
          if (cntc <= 0) {
            cntc = 6;
#ifdef LOG
            Serial.println("retrying the reconnect");
#endif
            client.connect(host, port);
          }
          swtSstate = digitalRead(switchSpin);
          if ((cntt > 90) || (swtSstate == LOW)) {
            swtSstate = HIGH;
#ifdef LOG
            Serial.println();
            Serial.println("Main: server reconnect failed");
#endif
            client.stop();
            u8g2.setDrawColor(0);
            u8g2.drawBox(43, 0, 85, 12);
            u8g2.setDrawColor(1);
            u8g2.drawStr(45, 9, "reconnect failed");
            u8g2.sendBuffer();
            WiFi.disconnect();
#ifdef LOG
            Serial.println("Throttle offline");
            Serial.println("WiFi disconnected");
#endif
            svr = false;
            cntd = cd;
            break;
          }
        }
        if (svr == true) {
          u8g2.setDrawColor(0);
          u8g2.drawBox(43, 0, 85, 12);
          u8g2.setDrawColor(1);
          if (ready == true) u8g2.drawStr(45, 9, "svr ready");  //##09.08
          else u8g2.drawStr(45, 9, "svr online");
          u8g2.sendBuffer();
          for (byte x = 0; x < numthrottles; x++) {
            vspeed[x] = 0;  //reset speed
          }
          dspeed = 0;
#ifdef LOG
          Serial.println();
          Serial.println("Connect: Sending MAC HU" + MacString);
#endif
          dsptr(1);
          client.print("N" + tname + "\r\n");  // send Name of Throttle
          delay(fdelay);
          client.print("HU" + MacString + "\r\n");  // send MAC identifier
          delay(fdelay);
          dsptr(0);
          recon = false;
        }
      }
      if ((hbuse == true) && (svr == true)) {
        client.print("*+\r\n");  // starting heartbeat
      }
      rtvrosnam();
      dsprosnam();
      u8g2.setFont(lfont);
      u8g2.drawStr(120, bl2, "?");
      u8g2.sendBuffer();
    }
  }
  if ((cntd <= 0) && (dsplon == true)) {  // time for turning display dark
    u8g2.setPowerSave(1);
    dsplon = false;
  }
  if (cntb <= 0) {
#ifdef BATLEVEL
    getbatlvl();
#endif
    getsiglvl();
    cntb = cb;
  }
  //-------Encoder moved for selection of...------------------------------------
  if (encoder_moved == true) {  // encoder has moved
    delay(50);                  //##09.10a
    if (dsplon == false) {      // turn Display back on
      display_on();
      encoder_moved = false;
      return;
    } else {
      cntd = cd;  //reset ssto
    }
    // reset estop in case it was -----------------------
    if (estop == true) {
      estop = false;
      u8g2.setDrawColor(0);
      u8g2.drawBox(90, tl3, 38, 16); //##10.23 clear stop
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
    }
    //speed:----------------------------
    if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 0) && (bitRead(setfctbn, MTx) == 0)
        && (sltroute == false)) {
      if (encoder_movedCW == true) {
        if (vcntv < numspst[MTx]) vcntv++;  // count up speed steps
      } else {
        if (vcntv > 0) vcntv--;  // count down speed steps
      }
      vcnt[MTx] = vcntv;
      set_speed();
    }
    //roster:--------------------------------------------
    //##09.12if ((bitRead(setdccadr, MTx) == 1) && (bitRead(setaccadr, MTx) == 0)) {
    if ((bitRead(setdccadr, MTx) == 1) && (bitRead(setaccadr, MTx) == 0) && (ros_Avail == true)) {  //##09.12
      if (encoder_movedCW == true) {
        rcntv++;                       // count up roster entries
        if (rcntv > numos) rcntv = 0;  // end of roster, back to beginning
      } else {
        rcntv--;                       // count down roster entries
        if (rcntv < 0) rcntv = numos;  // start of roster, return to end
      }
      rcnt[MTx] = rcntv;
      getrosnam(rcnt[MTx]);
      dsprosnam();
      getrosadr(rcnt[MTx]);
      dsprosadr();
      dspcnt(rcnt[MTx]);
      if (MThr == true) vfyadr(vadr);  // int vadr submitted by dsprosadr()
#ifdef LOG
      Serial.println("Encoder moved:");
      Serial.print("roster offset: ");
      Serial.println(rcnt[MTx]);
      Serial.print("name from roster: ");
      Serial.println(loconame[MTx]);
      Serial.print("address from roster: ");
      Serial.println(locoadr[MTx]);
#endif
    }
    //routes:--------------------------
    if ((bitRead(setdccadr, MTx) == 0) && (sltroute == true) && (rts_Avail == true)) {
      if (encoder_movedCW == true) {
        rtcntv++;                          // count up route entries
        if (rtcntv > numrtos) rtcntv = 0;  // end of route entries
      } else {
        rtcntv--;                          // count down route entries
        if (rtcntv < 0) rtcntv = numrtos;  // start of route entries
      }
      rtcnt[MTx] = rtcntv;
      bitWrite(setroute, MTx, 1);
      clrrosnam();
      getroute(rtcnt[MTx]);
      dspcnt(rtcnt[MTx]);
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl3, lw, 16);
      u8g2.setDrawColor(1);
      u8g2.setCursor(0, bl3);
      u8g2.print(rusrname);
      u8g2.sendBuffer();
    }
    //
    //turnout names:----------------------------
    if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 1) && (trn_Avail == true)) {
      if (encoder_movedCW == true) {
        tcntv++;
        if (tcntv > numtos) tcntv = 0;
      } else {
        tcntv--;
        if (tcntv < 0) tcntv = numtos;
      }
      tcnt[MTx] = tcntv;
      clrrosnam();
      gettoname(tcnt[MTx]);
      dspcnt(tcnt[MTx]);
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl3, lw, 16);
      u8g2.setDrawColor(1);
      u8g2.setCursor(0, bl3);
      u8g2.print(tusrname);
      u8g2.sendBuffer();
    }
    //function names:-----------------------------
    if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setfctbn, MTx) == 1) && (bitRead(fctsavail, MTx) == 1)) {
      if (encoder_movedCW == true) {
        fcntv++;
        if (fcntv > numfcnt[MTx]) fcntv = 0;  // end
      } else {
        fcntv--;
        if (fcntv < 0) fcntv = numfcnt[MTx];  // start
      }
      fcnt[MTx] = fcntv;
      clrrosnam();
      dspcnt(fcntv);
      getfctbn(fcntv);
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl3, lw, 16);
      u8g2.setDrawColor(1);
      u8g2.setCursor(0, bl3);
      u8g2.print(dspfctname);
      u8g2.sendBuffer();
    }
    encoder_moved = false;
  }  // end of encoder_moved
  //+++++++++++++++ dedicated switches: ++++++++++++++++++++++++++++++++++++++++++
  swtWstate = digitalRead(switchWpin);  // whistle
  if (swtWstate != lastswtWstate) {
    delay(dbcdly);
    if (dsplon == false) {
      display_on();
      delay(500);
      return;
    } else {
      cntd = cd;
    }
    lastswtWstate = swtWstate;
  }
  if ((swtWstate == LOW) && (longwhstl == false)) {
    if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][12] == 255)) swtfg0 = true;
    else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][16] == 255)) swtfg0 = true;
    else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
    if (swtfg0 == true) {
      if (swtWon == false) startTime = millis();
      swtWon = true;
      shortwhstl = true;
      if (((millis() - startTime) >= 500) && (longwhstl == false)) {
        longwhstl = true;
        shortwhstl = false;
        fnum = fctswtmap[MTx][1];                    // element 1 points to function "long whistle"
        if (fnum < numfcts) blkdfks[MTx][fnum] = 1;  // disable Function key
        fctbtnst = 1;
        sendfct(fnum);
      }
    }  //end fcgstate 0
    if (swtfg0 == false) {
      if ((fcgstate[MTx] == 1) || (fcgstate[MTx] == 2)) {
        if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][12];
        if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][16];
        if (fnum != 255) {
          fctbtnst = 1;
          sendfct(fnum);
        }
      }
    }
  }
  if ((swtWstate == HIGH) && (swtWon == true)) {  // turn short whistle on & off, or long whistle off.
    swtWon = false;
    if (swtfg0 == true) {
      if (shortwhstl == true) {
        fnum = fctswtmap[MTx][0];                    // element 0 points to function "short whistle"
        if (fnum < numfcts) blkdfks[MTx][fnum] = 1;  // disable Function key
        fctbtnst = 1;
        shortwhstl = false;
        sendfct(fnum);
        delay(mdelay);
        fctbtnst = 0;
        sendfct(fnum);
        if (fnum < numfcts) blkdfks[MTx][fnum] = 0;
      }
      if (longwhstl == true) {
        fnum = fctswtmap[MTx][1];                    // element 1 points to function "long whistle"
        if (fnum < numfcts) blkdfks[MTx][fnum] = 1;  // disable Function key
        fctbtnst = 0;
        sendfct(fnum);
        if (fnum < numfcts) blkdfks[MTx][fnum] = 0;
        longwhstl = false;
      }
    }  //end fcgstate 0
    if ((fnum != 255) && (swtfg0 == false)) {
      fctbtnst = 0;
      sendfct(fnum);
    }
    swtfg0 = false;
  }
  //-------------------------------------------------------
  swtBstate = digitalRead(switchBpin);
  if (swtBstate != lastswtBstate) {
    if (dsplon == false) {
      lastswtBstate = swtBstate;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    if ((swtBstate == LOW) && (swtBon == false)) {
      swtBon = true;
      fnumts = fctswtmap[MTx][2];  // element 2 points to function "Bell"
      if (fctfdbkbuf[MTx][fnumts] == 1) {
#ifdef LOG
        Serial.println("Switch blocked, function is on");
#endif
        return;
      }
      if (fnumts < numfcts) blkdfks[MTx][fnumts] = 1;  // disable Function key
      fctbtnst = 1;
      sendfct(fnumts);
#ifdef LOCKED
      delay(mdelay);
      fctbtnst = 0;  // simulate momentary
      sendfct(fnumts);
#endif
    }
    if ((swtBstate == HIGH) && (swtBon == true)) {
      swtBon = false;
      fctbtnst = 1;
      sendfct(fnumts);
#ifdef LOCKED
      delay(mdelay);
      fctbtnst = 0;  // simulate momentary
      sendfct(fnumts);
#endif
      if (fnumts < numfcts) blkdfks[MTx][fnumts] = 0;
    }
    lastswtBstate = swtBstate;
  }
  //----------------------------------------------------------------------
  swt2state = digitalRead(switch2pin);
  if (swt2state != lastswt2state) {
    delay(dbcdly);
    if (dsplon == false) {
      lastswt2state = swt2state;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    if ((swt2state == LOW) && (swt2on == false)) {
      swt2on = true;
      if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][10] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][14] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
      if (swtfg0 == true) {
        if ((bitRead(dctstate, MTx) == 0) && (fctswtmap[MTx][4] != 255)) fnum = fctswtmap[MTx][4];  // map 4 = front coupler
        if ((bitRead(dctstate, MTx) == 0) && (fctswtmap[MTx][4] == 255)) fnum = fctswtmap[MTx][3];  // map 3 = rear coupler (rear)
        if (bitRead(dctstate, MTx) == 1) fnum = fctswtmap[MTx][3];
        if (fnum < numfcts) blkdfks[MTx][fnum] = 1;  // disable Function key
        fctbtnst = 1;
        sendfct(fnum);
        if (bitRead(setsdhadr, MTx) == 1) {
          if ((sdhdct[MTx] == 0) && (sdhswtmap[MTx][4] != 255)) dblhdrfct = sdhswtmap[MTx][4];
          if ((sdhdct[MTx] == 0) && (sdhswtmap[MTx][4] == 255)) dblhdrfct = sdhswtmap[MTx][3];
          if (sdhdct[MTx] == 1) dblhdrfct = sdhswtmap[MTx][3];
          sendsdhfct(dblhdrfct);
        }
      }  // end fcgstate 0
      if (swtfg0 == false) {
        if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][10];
        if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][14];
        if (fnum != 255) {
          fctbtnst = 1;
          sendfct(fnum);
        }
      }
    }
    if ((swt2state == HIGH) && (swt2on == true)) {
      swt2on = false;
      swtfg0 = false;
      if (fnum != 255) {
        fctbtnst = 0;
        sendfct(fnum);
      }
      if (bitRead(setsdhadr, MTx) == 1) sendsdhfct(dblhdrfct);
      if (fnum < numfcts) blkdfks[MTx][fnum] = 0;
    }
    lastswt2state = swt2state;
  }
  //----Switch 1 ---->>----------------------------------------------------------
  swt1state = digitalRead(switch1pin);
#ifndef SIDEBTNS
  if (swt1state != lastswt1state) {
    delay(dbcdly);
    if (dsplon == false) {
      display_on();
      delay(500);
      return;
    } else {
      cntd = cd;
    }
    lastswt1state = swt1state;
  }
  //--------------------------------------
  if ((swt1state == LOW) && (pushlong == false)) {
    if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][11] == 255)) swtfg0 = true;
    else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][15] == 255)) swtfg0 = true;
    else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
    if (swtfg0 == true) {
      if (numthrottles == 1) {  // (single throttle)
        swt1on = true;
        fnum = fctswtmap[MTx][19];
      }
      if (MThr == true) {  // (multi throttle)
        if (swt1on == false) startTime = millis();
        swt1on = true;
        pushshort = true;
        if (((millis() - startTime) >= 500) && (pushlong == false)) {
          pushlong = true;
          pushshort = false;
          PrvMTn = MTn;
          MTn--;  // select previous throttle number
          if (MTn < 1) MTn = numthrottles;
          MTx = MTn - 1;
          swtthrottle();
        }
      }
    }  //end fcgstate 0
    if (swtfg0 == false) {
      if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][11];
      if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][15];
      if (fnum != 255) {
        fctbtnst = 1;
        sendfct(fnum);
      }
    }
  }
  if ((swt1state == HIGH) && (swt1on == true)) {
    swt1on = false;
    if (swtfg0 == false) {
      fctbtnst = 0;
      sendfct(fnum);
    }
    swtfg0 = false;
    pushlong = false;
    if (pushshort == true) {
      PrvMTn = MTn;
      MTn++;  // short push = throttle number +1
      if (MTn > numthrottles) MTn = 1;
      MTx = MTn - 1;
      swtthrottle();
      pushshort = false;
    }
  }
#endif  //ifndef SIDEBTNS
#ifdef SIDEBTNS
  if (swt1state != lastswt1state) {
    delay(dbcdly);
    if (dsplon == false) {
      lastswt1state = swt1state;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    //--------------------------------------
    if ((swt1state == LOW) && (swt1on == false)) {
      swt1on = true;
      if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][11] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][15] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
      if (swtfg0 == true) {
        if (numthrottles == 1) {  // (single throttle)
          swt1on = true;
          fnum = fctswtmap[MTx][19];
        }
        if (MThr == true) {  // (multi throttle)
          PrvMTn = MTn;
          MTn--;  // current throttle number
          if (MTn < 1) MTn = numthrottles;
          MTx = MTn - 1;
          swtthrottle();
        }
      }  //end fcgstate 0
      if (swtfg0 == false) {
        if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][11];
        if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][15];
        if (fnum != 255) {
          fctbtnst = 1;
          sendfct(fnum);
        }
      }
    }
    if ((swt1state == HIGH) && (swt1on == true)) {
      swt1on = false;
      if (swtfg0 == false) {
        fctbtnst = 0;
        sendfct(fnum);
      }
      swtfg0 = false;
    }
    lastswt1state = swt1state;
  }
#endif  //ifdef SIDEBTNS
  //---Switch S: Brake/Stop (not Estop) --------------------------------------------
  swtSstate = digitalRead(switchSpin);
  if (swtSstate != lastswtSstate) {
    delay(dbcdly);
    if (dsplon == false) {
      display_on();
      return;
    } else {
      cntd = cd;
    }
    lastswtSstate = swtSstate;
  }
  if ((swtSstate == LOW) && (pushlong == false)) {
    if (swtSon == false) startTime = millis();
    swtSon = true;
    pushshort = true;
    if (((millis() - startTime) >= 1000) && (pushlong == false)) {
      pushlong = true;
      pushshort = false;
#ifdef LOG
      if (vspeed[MTx] != 0) Serial.println("Switch S: long push ignored, speed is not 0)");
#endif
      if ((svr == true) && (vspeed[MTx] == 0)) {
#ifdef LOG
        Serial.println("Switch S: long push - change speed step mode");
#endif
        set_spstm();
      }
    }
  }
  if ((swtSstate == HIGH) && (swtSon == true)) {
    swtSon = false;
    pushlong = false;
    if (pushshort == true) {
      vspeed[MTx] = 0;
      vtemp = 0;
      vcnt[MTx] = 0;
      dspeed = vcnt[MTx];
      lastvcnt = 0;
      vcntv = 0;
      set_speed();
      pushshort = false;
#ifdef LOG
      Serial.println("Switch S: short push - brake");
#endif
    }
  }
#ifdef SIDEBTNS
  // Switch 0: ----------------------------------------------------------------------
  swt0state = digitalRead(switch0pin);
  if (swt0state != lastswt0state) {
    delay(dbcdly);
    if (dsplon == false) {
      lastswt0state = swt0state;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    //--------------------------------------
    if ((swt0state == LOW) && (swt0on == false)) {
      swt0on = true;
      if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][12] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][16] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
      if (swtfg0 == true) {
        if (numthrottles == 1) {
          fnum = fctswtmap[MTx][18];
        } else if (MThr == true) {
          PrvMTn = MTn;
          MTn++;  // select next throttle number
          if (MTn > numthrottles) MTn = 1;
          MTx = MTn - 1;
          swtthrottle();
        }
      }
      if (swtfg0 == false) {
        if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][12];
        if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][16];
        if (fnum != 255) {
          fctbtnst = 1;
          sendfct(fnum);
        }
      }
    }
    if ((swt0state == HIGH) && (swt0on == true)) {
      swt0on = false;
      if ((swtfg0 == false) || (numthrottles == 1)) {
        fctbtnst = 0;
        sendfct(fnum);
      }
      swtfg0 = false;
    }
    lastswt0state = swt0state;
  }
#endif  //ifdef SIDEBTNS
#ifdef SIDEBTNS
  // Switch 3: ----------------------------------------------------------------------
  swt3state = digitalRead(switch3pin);
  if (swt3state != lastswt3state) {
    delay(dbcdly);
    if (dsplon == false) {
      lastswt3state = swt3state;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    //--------------------------------------
    if ((swt3state == LOW) && (swt3on == false)) {
      swt3on = true;
      // mapped function:
      if ((fcgstate[MTx] == 1) && (fctswtmap[MTx][9] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 2) && (fctswtmap[MTx][13] == 255)) swtfg0 = true;
      else if ((fcgstate[MTx] == 0) || (fcgstate[MTx] == 3)) swtfg0 = true;
      if (swtfg0 == true) {
        //sound & fade:
        fnum = fctswtmap[MTx][8];  //sound function
        if (vspeed[MTx] == 0) {
          if (bitRead(fade_Avail, MTx) == 1) fadebtn = false;  // normal use of button - speed = 0
          fctbtnst = 1;                                        // send F1xx
          if (bitRead(faded, MTx) == 1) {
            fctrlsst = 2;  // for release: 1=fct1,2=fade-fct
            sendfct(sfnum[MTx]);
            getfadefbk();
            if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(t_sfnum[MTx]);
          } else {
            fctrlsst = 1;
            sendfct(fnum);
          }
        }
        if ((bitRead(fade_Avail, MTx) == 1) && (vspeed[MTx] > 0)) {
          fadebtn = true;  // button used for fade
          fctbtnst = 1;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //button pressed > send F1xx for fade function
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(t_sfnum[MTx]);
        }
        if ((fadebtn == true) && (vspeed[MTx] == 0)) {
          fadebtn = false;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //send 'fade btn on' (F1xx)
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(t_sfnum[MTx]);
        }
      }
      if (swtfg0 == false) {
        if (fcgstate[MTx] == 1) fnum = fctswtmap[MTx][9];
        if (fcgstate[MTx] == 2) fnum = fctswtmap[MTx][13];
        if (fnum != 255) {
          fctbtnst = 1;
          sendfct(fnum);
        }
      }
    }
    if ((swt3state == HIGH) && (swt3on == true)) {
      swt3on = false;
      fctbtnst = 0;
      if (fcgstate[MTx] == 0) {
        if (fctrlsst == 2) {
          sendfct(sfnum[MTx]);  // send 'fade btn off'
          fctrlsst = 0;
          if (bitRead(setsdhadr, MTx) == 1) sendsdhfct(sfnum[MTx]);  // send 'fade btn off' for trailer
        }
        if (fctrlsst == 1) {
          sendfct(fnum);
          fctrlsst = 0;
        }
      }
      if (swtfg0 == false) {
        fctbtnst = 0;
        sendfct(fnum);
      }
      swtfg0 = false;
    }
    lastswt3state = swt3state;
  }
#endif  //ifdef SIDEBTNS
  //////////////////////////////////////////////////////////////////////////////-
  swtFstate = digitalRead(switchFpin);
  swtRstate = digitalRead(switchRpin);
  if (swtFstate != lastswtFstate) {
    if (dsplon == false) {
      lastswtFstate = swtFstate;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    if ((swtFstate == LOW) && (swtRstate == HIGH) && (bitRead(setdccadr, MTx) == 0) && (swtFon == false)) {
      swtFon = true;
#ifdef LOG
      Serial.println("Direction switch forward");
      Serial.println("Drive hold: " + String(driveholdON));
#endif
      if ((driveholdON == false) && (bitRead(dctstate, MTx) == 0)) {
        vcnt[MTx] = 0;
        vcntv = 0;
      }
      set_speed();
      if ((driveholdON == false) && (bitRead(dctstate, MTx) == 0)) set_forward();
      fnum = fctswtmap[MTx][6];
      if (fctfdbkbuf[MTx][fnum] == 1) {  //drive hold is on
        fctbtnst = 1;
        sendfct(fnum);  //simulate button for locked function
        delay(mdelay);
        fctbtnst = 0;
        sendfct(fnum);
        if (fnum < numfcts) blkdfks[MTx][fnum] = 0;
        if (fctfdbkbuf[MTx][fnum] == 1) {  //drive hold state?
          driveholdON = true;
        } else {
          driveholdON = false;
        }
        if (bitRead(setsdhadr, MTx) == 1) {
          dblhdrfct = sdhswtmap[MTx][6];
          fctbtnst = 1;
          sendsdhfct(dblhdrfct);
          delay(mdelay);
          fctbtnst = 0;
          sendsdhfct(dblhdrfct);
        }
#ifdef LOG
        Serial.println("Set fwd drive hold OFF: " + String(driveholdON));
#endif
        u8g2.setFont(sfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 11);
        u8g2.setDrawColor(1);
        u8g2.setCursor(46, bl2);
        u8g2.print(String(numspst[MTx]));
        u8g2.sendBuffer();
      }
      swtCon = false;
    }
    lastswtFstate = swtFstate;
    swtFon = false;
  }
  if ((swtRstate != lastswtRstate)) {
    if (dsplon == false) {
      lastswtRstate = swtRstate;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    if ((swtRstate == LOW) && (swtFstate == HIGH) && (bitRead(setdccadr, MTx) == 0) && (swtRon == false)) {
      swtRon = true;
#ifdef LOG
      Serial.println("Direction switch reverse");
      Serial.println("Drive hold: " + String(driveholdON));
#endif
      if ((driveholdON == false) && (bitRead(dctstate, MTx) == 1)) {
        vcnt[MTx] = 0;
        vcntv = 0;
      }
      set_speed();
      if ((driveholdON == false) && (bitRead(dctstate, MTx) == 1)) set_reverse();
      fnum = fctswtmap[MTx][6];
      if (fctfdbkbuf[MTx][fnum] == 1) {  //drive hold is on
        fctbtnst = 1;
        sendfct(fnum);  //simulate momentary button push for locked function
        delay(mdelay);
        fctbtnst = 0;
        sendfct(fnum);
        if (fnum < numfcts) blkdfks[MTx][fnum] = 0;
        if (fctfdbkbuf[MTx][fnum] == 1) {  // drive hold state?
          driveholdON = true;
        } else {
          driveholdON = false;
        }
        if (bitRead(setsdhadr, MTx) == 1) {
          dblhdrfct = sdhswtmap[MTx][6];
          fctbtnst = 1;
          sendsdhfct(dblhdrfct);
          delay(mdelay);
          fctbtnst = 0;
          sendsdhfct(dblhdrfct);
        }
#ifdef LOG
        Serial.println("Set rvs drive hold OFF: " + String(driveholdON));
#endif
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 11);  // clear hold speed
        u8g2.setDrawColor(1);
        u8g2.setFont(sfont);
        u8g2.setCursor(46, bl2);
        u8g2.print(String(numspst[MTx]));
        u8g2.sendBuffer();
      }
      swtCon = false;
    }
    lastswtRstate = swtRstate;
    swtRon = false;
  }
  // Function for Drive Hold >
  if (drivehold[MTx] == 1) {
    if ((swtFstate == HIGH) && (swtRstate == HIGH) && (bitRead(setdccadr, MTx) == 0) && (driveholdON == false)) {
      if (swtCon == false) {
        startTime = millis();
        swtCon = true;
      }
      if ((millis() - startTime) > 1000) {
        hcnt = vcnt[MTx];
        fnum = fctswtmap[MTx][6];
        if (fnum < numfcts) blkdfks[MTx][fnum] = 1;  // disable Function key
        fctbtnst = 1;
        sendfct(fnum);
        delay(mdelay);
        fctbtnst = 0;
        sendfct(fnum);  //simulate button for locked function
        if (fctfdbkbuf[MTx][fnum] == 1) {
          driveholdON = true;
        } else {
          driveholdON = false;
        }
        if (bitRead(setsdhadr, MTx) == 1) {
          dblhdrfct = sdhswtmap[MTx][6];
          fctbtnst = 1;
          sendsdhfct(dblhdrfct);
          delay(mdelay);
          fctbtnst = 0;
          sendsdhfct(dblhdrfct);
        }
#ifdef LOG
        Serial.println("Set drive hold ON: " + String(driveholdON));
#endif
        sprintf(dspadr, "%3d", hcnt);  //drive hold speed?
        u8g2.setFont(sfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 11);
        u8g2.setDrawColor(1);
        u8g2.setCursor(50, bl2);
        u8g2.print(dspadr);
        u8g2.sendBuffer();
#ifdef LOG
        Serial.println("Set drive hold ON at speed: " + String(dspadr));
#endif
      }
    }
  }
  //----Switch E: E-Stop----------------------------------------------
  swtEstate = digitalRead(switchEpin);
  if ((swtEstate != lastswtEstate)) {
    delay(dbcdly);
    if (dsplon == false) {  //turn Display back on if off
      display_on();
      return;
    } else {
      cntd = cd;
    }
    lastswtEstate = swtEstate;
  }
  if ((swtEstate == LOW) && (bitRead(setdccadr, MTx) == 0) && (bitRead(setfctbn, MTx) == 0) && (swtEon == false)) {
    swtEon = true;
    vspeed[MTx] = 0;
    vcnt[MTx] = 0;
    vcntv = 0;
    lastvcnt = 0;
    dspeed = vcnt[MTx];
    prvspeed[MTx] = 0;
    vtemp = 0;
    if (svr == true) {
      xmits = locoacts[MTx] + "X\r\n";
#ifdef LOG
      Serial.println("sending " + xmits);
#endif
      dsptr(1);
      client.print(xmits);
      delay(fdelay);
      if (bitRead(setsdhadr, MTx) == 1) {
        xmits = sdhacts[MTx] + "X\r\n";
#ifdef LOG
        Serial.println("sending " + xmits);
#endif
        client.print(xmits);
        delay(fdelay);
      }
      dsptr(0);
    }
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(90, tl3, 38, 16);  //where stop goes
    u8g2.drawBox(15, tl2, 27, 14);  //clear speed
    u8g2.setDrawColor(1);
    u8g2.setCursor(15, bl2);
    u8g2.print(String(dspeed));
    u8g2.drawStr(90, bl3, "STOP");
    u8g2.sendBuffer();
    estop = true;
  }
  if ((swtEstate == LOW) && (bitRead(setdccadr, MTx) == 1) && (swtEon == false)) {
    swtEon = true;
#ifdef LOG
    Serial.println("Switch E calling actdccadr(). dccadr: " + String(dccadr[MTx]));
#endif
    actdccadr();
    adrbtnstate = 0;
  }
  // set function:
  if ((swtEstate == LOW) && (bitRead(setfctbn, MTx) == 1) && (swtEon == false)) {
    swtEon = true;
    fctbtnst = 1;
    sendfct(fnum);
    dspsfnum(fnum);
  }
  if ((swtEstate == HIGH) && (swtEon == true)) {
    swtEon = false;
    if (bitRead(setfctbn, MTx) == 1) {
      fctbtnst = 0;
      sendfct(fnum);
      dspsfnum(fnum);
    }
  }
  //---------------------------------------------------------------------
  // read keypad:
  kpread = analogRead(keypadin);
  if (kpread > kpnone) {
    delay(dbcdly);
    kparrRead();  // a button is pressed - find the button
  }
  /////////////////////////////////////////////////////////////
  // All keypad buttons released & none pushed:
  else if ((kpread <= kpnone) && (kpbtnstate == true)) {
    kpbtnstate = false;
    noop = false;
    //  keypad buttons off:
    kpRelease();
  } else if ((kpread == 0) && (noop == true)) {
    kpbtnstate = false;
    noop = false;
    kpRelease();
  }
}
//-------------------------------------------------------
void kparrReadN() {  // called in setup for config of ip address or port
  kpread = analogRead(keypadin);
  if ((kpread >= keypadarray[0]) && (kpread <= keypadarray[1])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 1;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[2]) && (kpread <= keypadarray[3])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 2;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[4]) && (kpread <= keypadarray[5])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 3;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[6]) && (kpread <= keypadarray[7])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 4;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[8]) && (kpread <= keypadarray[9])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 5;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[10]) && (kpread <= keypadarray[11])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 6;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[12]) && (kpread <= keypadarray[13])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 7;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[14]) && (kpread <= keypadarray[15])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 8;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[16]) && (kpread <= keypadarray[17])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 9;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[18]) && (kpread <= keypadarray[19])) {
    if (kpbtnstate == false) {
      btncnt++;
      if ((hostconfig == true) && (btncnt < 16)) puthostdot();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[20]) && (kpread <= keypadarray[21])) {
    if (kpbtnstate == false) {
      btncnt++;
      btnval = 0;
      if ((portconfig == true) && (btncnt < 6)) putportdgt();
      if ((hostconfig == true) && (btncnt < 16)) puthostdgt();
      kpbtnstate = true;
    }
  }
  if ((kpread >= keypadarray[22]) && (kpread <= keypadarray[23])) {
    if (kpbtnstate == false) {
      btncnt++;
      if ((hostconfig == true) && (btncnt < 16)) puthostdot();
      kpbtnstate = true;
    }
  }
}
//-------------------------------------------------------
void kparrRead() {
  kpread = analogRead(keypadin);
#ifdef LOG
  if (kpbtnstate == false) Serial.println("kparrRead() read keypadin: " + String(kpread));
#endif
  // Button 1: ***********************************
  if ((kpread >= keypadarray[0]) && (kpread <= keypadarray[1])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton01();
  }
  // Button 2: ***************************************
  else if ((kpread >= keypadarray[2]) && (kpread <= keypadarray[3])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton02();
  }
  // Button 3: ***************************************
  else if ((kpread >= keypadarray[4]) && (kpread <= keypadarray[5])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton03();
  }
  // Button 4: ***************************************
  else if ((kpread >= keypadarray[6]) && (kpread <= keypadarray[7])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton04();
  }
  // Button 5: ***************************************
  else if ((kpread >= keypadarray[8]) && (kpread <= keypadarray[9])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton05();
  }
  // Button 6: ***************************************
  else if ((kpread >= keypadarray[10]) && (kpread <= keypadarray[11])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton06();
  }
  // Button 7: ***************************************
  else if ((kpread >= keypadarray[12]) && (kpread <= keypadarray[13])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton07();
  }
  // Button 8: ***************************************
  else if ((kpread >= keypadarray[14]) && (kpread <= keypadarray[15])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton08();
  }
  // Button 9: ***************************************
  else if ((kpread >= keypadarray[16]) && (kpread <= keypadarray[17])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton09();
  }
  // Button 10 (function group/Acc dec close): *******
  else if ((kpread >= keypadarray[18]) && (kpread <= keypadarray[19])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton10();
  }
  // Button 11 (zero/acc dec toggle): ****************
  else if ((kpread >= keypadarray[20]) && (kpread <= keypadarray[21])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    // send "toggle" to accessory decoder >------------------------
    kpButton11();
  }
  // Button 12 (shunting/switch direction of trailer/acc dec throw): *****
  else if ((kpread >= keypadarray[22]) && (kpread < keypadarray[23])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    // send "thrown" to accessory decoder >------------------------
    kpButton12();
  }
  // Button 13 (enter address): **********************
  else if ((kpread >= keypadarray[24]) && (kpread <= keypadarray[25])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton13();
  }
  // Button 14 (accessory address): ******************
  else if ((kpread >= keypadarray[26]) && (kpread <= keypadarray[27])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    kpButton14();
  }
  // Button 15 (set/release trailer adr/retrieve stack): ****************
  else if ((kpread >= keypadarray[28]) && (kpread <= keypadarray[29])) {
    if (dsplon == false) {
      kpbtnstate = true;
      display_on();
      return;
    } else {
      cntd = cd;
    }
    //---Simple double header:
    kpButton15();
  }
  // Button 16 (throttle-off/restart): ****************
  else if ((kpread >= keypadarray[30]) && (kpread <= keypadarray[31])) {
    if (dsplon == false) {
      display_on();
      noop = true;
      return;
    } else {
      cntd = cd;
    }
    kpButton16();
  }
}  //end of kparrRead ('button pressed')
//**************************************************************
void kpButton01() {
#ifdef LOG
  Serial.println("kpButton01()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(1);
    }
  }
  // function 1
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    kpbtnstate = true;
    if (fctswtmap[MTx][8] != 1) {  // sound not this button
      if ((blkdfks[MTx][1] == 1) || (blkdfks[MTx][11] == 1) || (blkdfks[MTx][21] == 1)) return;
      if (fc1btnstate == false) {
        fc1btnstate = true;
        fctbtnst = 1;
        fctrlsst = 1;  // for release: 1=fct1,2=fade-fct
        if (fcgstate[MTx] == 0) {
          fnum = 1;
          sendfct(fnum);
        }
        if (fcgstate[MTx] == 1) {
          fnum = 11;
          sendfct(fnum);
        }
        if (fcgstate[MTx] == 2) {
          fnum = 21;
          sendfct(fnum);
        }
      }
    }  // sound = F8
    //-----------------------------------------------
    if (fctswtmap[MTx][8] == 1) {  // sound = F1 (this button)
      if (fc1btnstate == false) {
        fc1btnstate = true;
        if (vspeed[MTx] == 0) {
          if (bitRead(fade_Avail, MTx) == 1) fadebtn = false;  // normal use of button
          fctbtnst = 1;                                        // button pressed > send F1xx
          if (fcgstate[MTx] == 0) {
            if (bitRead(faded, MTx) == 1) {
              fctrlsst = 2;  // for release: 1=fct1,2=fade-fct
              sendfct(sfnum[MTx]);
              getfadefbk();
              if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(t_sfnum[MTx]);
            } else {
              fctrlsst = 1;
              fnum = 1;
              sendfct(fnum);
            }
          }
          if (fcgstate[MTx] == 1) {
            fnum = 11;
            sendfct(fnum);
          }
          if (fcgstate[MTx] == 2) {
            fnum = 21;
            sendfct(fnum);
          }
        }
        if ((bitRead(fade_Avail, MTx) == 1) && (vspeed[MTx] > 0)) {
          fadebtn = true;  // button used for fade
          fctbtnst = 1;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //button pressed > send F1xx for fade function
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(sfnum[MTx]);
        }
        if ((fadebtn == true) && (vspeed[MTx] == 0)) {
          fadebtn = false;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //send 'fade btn on' (F1xx)
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(sfnum[MTx]);
        }
        //-----------------------------------------------------
      }
    }  //sound = F1
  }    // end function 1
}
//-----------------------------------------------------------------
void kpButton02() {
#ifdef LOG
  Serial.println("kpButton02()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(2);
    }
  }
  // function 2
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][2] == 1) || (blkdfks[MTx][12] == 1) || (blkdfks[MTx][22] == 1)) return;
    if (fc2btnstate == false) {
      fc2btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 2;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 12;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 22;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 2
}
//-----------------------------------------------------------------
void kpButton03() {
#ifdef LOG
  Serial.println("kpButton03()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(3);
    }
  }
  // function 3
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][3] == 1) || (blkdfks[MTx][13] == 1) || (blkdfks[MTx][23] == 1)) return;
    if (fc3btnstate == false) {
      fc3btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 3;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 13;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 23;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 3
}
//-----------------------------------------------------------------
void kpButton04() {
#ifdef LOG
  Serial.println("kpButton04()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(4);
    }
  }
  // function 4
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][4] == 1) || (blkdfks[MTx][14] == 1) || (blkdfks[MTx][24] == 1)) return;
    if (fc4btnstate == false) {
      fc4btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 4;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 14;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 24;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 4
}
//-----------------------------------------------------------------
void kpButton05() {
#ifdef LOG
  Serial.println("kpButton05()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(5);
    }
  }
  // function 5
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][5] == 1) || (blkdfks[MTx][15] == 1) || (blkdfks[MTx][25] == 1)) return;
    if (fc5btnstate == false) {
      fc5btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 5;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 15;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 25;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 5
}
//-----------------------------------------------------------------
void kpButton06() {
#ifdef LOG
  Serial.println("kpButton06()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(6);
    }
  }
  // function 6
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][6] == 1) || (blkdfks[MTx][16] == 1) || (blkdfks[MTx][26] == 1)) return;
    if (fc6btnstate == false) {
      fc6btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 6;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 16;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 26;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 6
}
//-----------------------------------------------------------------
void kpButton07() {
#ifdef LOG
  Serial.println("kpButton07()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(7);
    }
  }
  // function 7
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][7] == 1) || (blkdfks[MTx][17] == 1) || (blkdfks[MTx][27] == 1)) return;
    if (fc7btnstate == false) {
      fc7btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 7;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 17;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 27;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 7
}
//-----------------------------------------------------------------
void kpButton08() {
#ifdef LOG
  Serial.println("kpButton08()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(8);
    }
  }
  // function 8
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    kpbtnstate = true;
    if (fctswtmap[MTx][8] != 8) {  // sound not this button
      if ((blkdfks[MTx][8] == 1) || (blkdfks[MTx][18] == 1) || (blkdfks[MTx][28] == 1)) return;
      if (fc8btnstate == false) {
        fc8btnstate = true;
        fctbtnst = 1;
        fctrlsst = 1;  // for release: 1=fct1,2=fade-fct
        if (fcgstate[MTx] == 0) {
          fnum = 8;
          sendfct(fnum);
        }
        if (fcgstate[MTx] == 1) {
          fnum = 18;
          sendfct(fnum);
        }
        if (fcgstate[MTx] == 2) {
          fnum = 28;
          sendfct(fnum);
        }
      }
    }  // sound = F1
    //-----------------------------------------------
    if (fctswtmap[MTx][8] == 8) {  // sound = F8 (this button)
      if (fc8btnstate == false) {
        fc8btnstate = true;
        if (vspeed[MTx] == 0) {
          if (bitRead(fade_Avail, MTx) == 1) fadebtn = false;  // normal use of button
          fctbtnst = 1;                                        // button pressed > send F1xx
          if (fcgstate[MTx] == 0) {
            if (bitRead(faded, MTx) == 1) {
              fctrlsst = 2;  // for release: 1=fct1,2=fade-fct
              sendfct(sfnum[MTx]);
              getfadefbk();
              if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(sfnum[MTx]);
            } else {
              fctrlsst = 1;
              fnum = 8;
              sendfct(fnum);
            }
          }
          if (fcgstate[MTx] == 1) {
            fnum = 18;
            sendfct(fnum);
          }
          if (fcgstate[MTx] == 2) {
            fnum = 28;
            sendfct(fnum);
          }
        }
        if ((bitRead(fade_Avail, MTx) == 1) && (vspeed[MTx] > 0)) {
          fadebtn = true;  // button used for fade
          fctbtnst = 1;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //button pressed > send F1xx for fade function
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(sfnum[MTx]);
        }
        if ((fadebtn == true) && (vspeed[MTx] == 0)) {
          fadebtn = false;
          fctrlsst = 2;         // for release: 1=fct1,2=fade-fct
          sendfct(sfnum[MTx]);  //send 'fade btn on' (F1xx)
          getfadefbk();
          if ((bitRead(setsdhadr, MTx) == 1) && (bitRead(t_fade_Avail, MTx) == 1)) sendsdhfct(sfnum[MTx]);
        }
        //-----------------------------------------------------
      }
    }  //sound = F8
  }    // end function 8
}
//-----------------------------------------------------------------
void kpButton09() {
#ifdef LOG
  Serial.println("kpButton09()");
#endif
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    // set loco or assessory decoder address:
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(9);
    }
  }
  // function 9
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][9] == 1) || (blkdfks[MTx][19] == 1)) return;
    if (fc9btnstate == false) {
      fc9btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 9;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 19;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 9
}
//-----------------------------------------------------------------
void kpButton10() {
#ifdef LOG
  Serial.println("kpButton10()");
#endif
  // send "close" to accessory decoder 12/13>------------------------
  if ((kpbtnstate == false) && (accbtnst[MTx] == 2) && (bitRead(setaccadr, MTx) == 1)) {
    kpbtnstate = true;
    setacc[MTx] = "C";
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 16);
    u8g2.setDrawColor(1);
    u8g2.setCursor(0, bl3);
    dsptext = tusrname + " -/cls";
    u8g2.print(dsptext);
    u8g2.sendBuffer();
    sendaccadr();
  }
  // toggle function group: -------------------------------------------
  if ((kpbtnstate == false) && (fctbtnstate == false) && (bitRead(setaccadr, MTx) == 0)) {
    fctbtnstate = true;
    kpbtnstate = true;
  }
}
//-----------------------------------------------------------------
void kpButton11() {
#ifdef LOG
  Serial.println("kpButton11()");
#endif
  if ((kpbtnstate == false) && (accbtnst[MTx] == 2) && (bitRead(setaccadr, MTx) == 1)) {
    kpbtnstate = true;
    setacc[MTx] = "2";
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 16);
    u8g2.setDrawColor(1);
    u8g2.setCursor(0, bl3);
    dsptext = tusrname + " tgl";
    u8g2.print(dsptext);
    u8g2.sendBuffer();
    sendaccadr();
  }
  // enter digit for dccadr: ----------------------------------
  if ((bitRead(setdccadr, MTx) == 1) || (accbtnst[MTx] == 1)) {
    if ((btncnt < 5) && (kpbtnstate == false)) {
      kpbtnstate = true;
      crtdccadr(0);
    }
  }
  // function 0 button ------------------------------------------
  if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 0) && (kpbtnstate == false)) {
    if ((blkdfks[MTx][0] == 1) || (blkdfks[MTx][10] == 1) || (blkdfks[MTx][20] == 1)) return;
    if (fc0btnstate == false) {
      fc0btnstate = true;
      fctbtnst = 1;
      if (fcgstate[MTx] == 0) {
        fnum = 0;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 1) {
        fnum = 10;
        sendfct(fnum);
      }
      if (fcgstate[MTx] == 2) {
        fnum = 20;
        sendfct(fnum);
      }
    }
    kpbtnstate = true;
  }  // end of function 0 button
}
//-----------------------------------------------------------------
void kpButton12() {
#ifdef LOG
  Serial.println("kpButton12()");
#endif
  if ((kpbtnstate == false) && (accbtnst[MTx] == 2) && (bitRead(setaccadr, MTx) == 1)) {
    kpbtnstate = true;
    setacc[MTx] = "T";
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 16);
    u8g2.setDrawColor(1);
    u8g2.setCursor(0, bl3);
    dsptext = tusrname + " +/thw";
    u8g2.print(dsptext);
    u8g2.sendBuffer();
    sendaccadr();
  }
  // mapped function:
  if ((kpbtnstate == false) && (bitRead(setsdhadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 0)) {
    kpbtnstate = true;
    fnum = fctswtmap[MTx][5];  // swtmap element 6 points to function "Shunting"
    fctbtnst = 1;
#ifdef LOG
    Serial.println("Button 12 pushed for mapped function.");
#endif
    sendfct(fnum);
    delay(mdelay);
    fctbtnst = 0;
#ifdef LOG
    Serial.println("Button 12 released for mapped function.");
#endif
    sendfct(fnum);
  }
  // change direction of trailer:
  if ((kpbtnstate == false) && (bitRead(setsdhadr, MTx) == 1) && (bitRead(setaccadr, MTx) == 0)) {
    kpbtnstate = true;
    sdhdct[MTx] = !sdhdct[MTx];
#ifdef LOG
    if (sdhdct[MTx] == 1) Serial.println("trailer direction turned forward");
    if (sdhdct[MTx] == 0) Serial.println("trailer direction turned reverse");
#endif
    chgsdhdct();
  }
}
//-----------------------------------------------------------------
void kpButton13() {
#ifdef LOG
  Serial.println("kpButton13()");
#endif
  if (kpbtnstate == false) {
    kpbtnstate = true;
    //cancel selections>>
    if ((sltroute == true) || (bitRead(setaccadr, MTx) == 1) || (bitRead(setfctbn, MTx) == 1)) {
#ifdef LOG
      Serial.println("Btn 13 - Cancel other selections.");
#endif
      bitWrite(setfctbn, MTx, 0);
      sltroute = false;
      bitWrite(setroute, MTx, 0);
      bitWrite(setaccadr, MTx, 0);
      bitWrite(setsdhadr, MTx, 0);
      accbtnst[MTx] = 0;
      clrrosnam();
      dsprosnam();
      dsprosadr();
      u8g2.setDrawColor(0);
      u8g2.drawBox(45, tl2, 20, 11);  //clear cntr.
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
    }
    if (vspeed[MTx] == 0) adrbtnstate++;
    if (adrbtnstate == 3) adrbtnstate = 0;
#ifdef LOG
    Serial.println("Btn 13 adrbtnstate = " + String(adrbtnstate));
#endif
    if (adrbtnstate == 1) {  //first button press
      stkx = 0;              //always start stack at 0
      btncnt = 0;
      bitWrite(setdccadr, MTx, 1);
#ifdef LOG
      Serial.print("dccadr ");
      Serial.println(dccadr[MTx]);
#endif
      if (bitRead(setsdhadr, MTx) == 0) {
#ifdef LOG
        Serial.print("Btn 13/1. calling releaseadr(");
        Serial.print(dccadr[MTx]);
        Serial.println(")");
#endif
        releaseadr(dccadr[MTx]);
      }
      u8g2.setDrawColor(0);
      if (bitRead(setsdhadr, MTx) == 1) u8g2.drawBox(85, tl2x, 43, 16);  //"dccadr"
      else u8g2.drawBox(73, tl2x, 55, 16);                               //"+ dccadr"
      u8g2.setDrawColor(1);
      u8g2.setFont(lfont);
      u8g2.setCursor(85, bl2);
      u8g2.print(dspadr);

      if (rlsfdbk == true) u8g2.drawStr(120, bl2, "?");
      else u8g2.drawStr(120, bl2, "::");  //no feedback, try again
      u8g2.sendBuffer();
    }
    if (adrbtnstate == 2) {  //2nd button press
      pshadr = true;
#ifdef LOG
      Serial.println("Btn 13/2. calling actdccadr(), dccadr: " + String(dccadr[MTx]));
#endif
      adrbtnstate = 0;
      actdccadr();
    }
  }
}
//-----------------------------------------------------------------
void kpButton14() {
#ifdef LOG
  Serial.println("kpButton14()");
#endif
  if ((bitRead(setdccadr, MTx) == 0) && (kpbtnstate == false)) {
    kpbtnstate = true;
    // accessory decoder
    if (bitRead(setdccadr, MTx) == 0) {
      accbtnst[MTx]++;  // 1 = address mode, 2 = action, 0 = off
      if (accbtnst[MTx] == 4) accbtnst[MTx] = 1;
#ifdef LOG
      Serial.println("accbtnst[MTx]: " + String(accbtnst[MTx]));
#endif
      if (accbtnst[MTx] == 1) {  // set accessory address mode
        btncnt = 0;
        accadr[MTx] = 0;
        lastvcnt = vcnt[MTx];
        bitWrite(setaccadr, MTx, 1);
        u8g2.setFont(lfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(0, tl3, lw, 16);  //clear locoadr and loconame
        u8g2.setDrawColor(1);
        u8g2.drawStr(0, bl3, "T");
        sprintf(dspaccadr, "%04d", accadr[MTx]);
        u8g2.setCursor(85, bl3);
        u8g2.print(dspaccadr);
        u8g2.drawStr(120, bl3, "?");
        u8g2.sendBuffer();
#ifdef LOG
        Serial.println("button state " + String(accbtnst[MTx]) + ": Set accessory address via keypad");
        Serial.println("or turn knob to select turnout name.");
        Serial.println("then press turnout button.");
#endif
      }
      if (accbtnst[MTx] == 2) {
        if (accadr[MTx] != 0) {  // ready to enter "C","2","T" via kp-buttons 10,11,12.
          u8g2.setFont(lfont);
          u8g2.setDrawColor(0);
          u8g2.drawBox(85, tl3, 43, 16);
          u8g2.setDrawColor(1);
          sprintf(dspaccadr, "%04d", accadr[MTx]);
          u8g2.setCursor(85, bl3);
          u8g2.print(dspaccadr);
          u8g2.sendBuffer();
#ifdef LOG
          Serial.println("button state " + String(accbtnst[MTx]));
          Serial.print("accadr: ");
          Serial.println(accadr[MTx]);
          Serial.print("dspaccadr: ");
          Serial.println(dspaccadr);
          Serial.println("Use buttons 10,11,12 for: close,toggle,throw.");
#endif
        }
        // if rts_Avail == true >
        if (accadr[MTx] == 0) {  // button pressed but nothing entered
          sltroute = true;
          bitWrite(setaccadr, MTx, 0);
          u8g2.setFont(lfont);
          u8g2.setDrawColor(0);
          u8g2.drawBox(45, tl2, 20, 11);  //clear btn cnt
          u8g2.drawBox(0, tl3, lw, 16);
          u8g2.setDrawColor(1);
          if (rts_Avail == true) u8g2.drawStr(0, bl3, "Select route?");
          else u8g2.drawStr(0, bl3, "Exit?");
          u8g2.sendBuffer();
#ifdef LOG
          if (rts_Avail == true) Serial.println("Nothing entered. Select route or exit");
          else Serial.println("No turnouts received from server. Exit by pressing the accessory btn again.");
#endif
        }
      }
      if (accbtnst[MTx] == 3) {
        clrrosnam();
        dsprosnam();
        bitWrite(setaccadr, MTx, 0);
        sltroute = false;
        vcnt[MTx] = lastvcnt;
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 11);  //clear tcnt.
        u8g2.setDrawColor(1);
        u8g2.sendBuffer();
        dspfcts();
#ifdef LOG
        Serial.println("button state 3: Set accessory address mode OFF");
#endif
      }
    }
    // set route
    if ((bitRead(setroute, MTx) == 1) && (bitRead(setaccadr, MTx) == 0)) {
      accbtnst[MTx] = 0;
#ifdef LOG
      Serial.print("Setting route: ");
      Serial.println(rsysname);
#endif
      sendroute();
      bitWrite(setroute, MTx, 0);
      bitWrite(setaccadr, MTx, 0);
      vcnt[MTx] = lastvcnt;
      u8g2.setDrawColor(0);
      u8g2.drawBox(45, tl2, 20, 11);  //clear rtcnt.
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
    }
  }
}
//-----------------------------------------------------------------
void kpButton15() {  //for throttle supported double header
#ifdef LOG
  Serial.println("kpButton15()");
#endif
  // rls trailer address: ----------------------------------------------
  if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 0) && (bitRead(setroute, MTx) == 0) && (bitRead(setsdhadr, MTx) == 1) && (kpbtnstate == false)) {
    kpbtnstate = true;
    if (vspeed[MTx] == 0) { //##10.23
      releaseadr(sdhadr[MTx]);
      sdhadr[MTx] = 0;
      u8g2.setDrawColor(0);
      u8g2.drawBox(73, tl2x, 10, 16);  //clear +
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
      bitWrite(setsdhadr, MTx, 0);
      bitWrite(t_fade_Avail, MTx, 0);
    } //##10.23
  }
  // set trailer address: -----------------------------------------------
  if ((bitRead(setdccadr, MTx) == 0) && (bitRead(setaccadr, MTx) == 0) && (bitRead(setroute, MTx) == 0) && (bitRead(setsdhadr, MTx) == 0) && (kpbtnstate == false)) {
    kpbtnstate = true;
    //##10.23 if (dccadr[MTx] != 0) {
    if ((dccadr[MTx] != 0) && (vspeed[MTx] == 0)) { //##10.23
      bitWrite(setsdhadr, MTx, 1);
      sdhadr[MTx] = dccadr[MTx];             //dccadr becomes trailer address
      sdhdct[MTx] = bitRead(dctstate, MTx);  //copy direction to trailer
      // copy fctswtmap to sdhswtmap:
      for (int i = 0; i < numswfcs; i++) {
        sdhswtmap[MTx][i] = fctswtmap[MTx][i];
      }
      // copy fctfdbkarr to t_fctfdbkarr (trailer):
      for (int i = 0; i < numfcts; i++) {
        t_fctfdbkbuf[MTx][i] = fctfdbkbuf[MTx][i];
      }
      t_sfnum[MTx] = sfnum[MTx];
#ifdef LOG
      Serial.print("loconame " + loconame[MTx]);
      Serial.print(" address " + String(sdhadr[MTx]));
      Serial.println(" set as trailer.");
      Serial.println("Fade function is " + String(sfnum[MTx]));
#endif
      compsdhadr();
      if (bitRead(fade_Avail, MTx) == 1) bitWrite(t_fade_Avail, MTx, 1);
      u8g2.setFont(lfont);
      u8g2.drawStr(73, bl2x, "+");
      u8g2.sendBuffer();
    }
  }  //end double header = false
  // retrieve dcc address from stack array-------------------------
  if ((bitRead(setdccadr, MTx) == 1) && (kpbtnstate == false)) {
    kpbtnstate = true;
    if (stkx > 5) stkx = 0;
    dspcnt(stkx);  // display counter
    dccadr[MTx] = dccstck[stkx];
    stkx++;
    if (dccadr[MTx] == 0) stkx = 0;
#ifdef LOG
    Serial.print("stack array@ ");
    Serial.print(stkx);
    Serial.print(" reads: ");
    Serial.println(dccadr[MTx]);
#endif
    rtvrosnam();
    if (ros_eAvail == true) {  //display with name
      clrrosnam();
      dsprosnam();
      dsprosadr();
    } else {  // display w/o name
      clrchgadr();
      dspchgadr();
    }
    if (MThr == true) vfyadr(vadr);  // int vadr submitted by dspchgadr() or dsprosadr
    if (dccadr[MTx] > 0) {
      pshadr = true;
    }
  }
}
//-----------------------------------------------------------------
void kpButton16() {
#ifdef LOG
  Serial.println("kpButton16()");
#endif
  if ((kpbtnstate == false) && (throff == false) && (noop == false)) {
    kpbtnstate = true;
    dspdccadr();
    // Start the 'button press timer'
    startTime = millis();
    dsptr(1);
    releaseall();
    client.print("Q\r\n");
    dsptr(0);
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(90, tl3, lw, 16);
    u8g2.setDrawColor(1);
    u8g2.drawStr(95, bl3, "OFF");
    u8g2.drawStr(120, bl2, "?");
    u8g2.sendBuffer();
    svr = false;
    throff = true;
    actthrottles = 0;
#ifdef LOG
    Serial.println("Throttle offline.");
#endif
    client.stop();
    delay(ldelay);
    WiFi.disconnect();
#ifdef LOG
    Serial.println("Throttle disconnected.");
#endif
  }
  if ((kpbtnstate == false) && (throff == true) && (noop == false)) {
    kpbtnstate = true;
    throff = false;
    startTime = millis();  //restart button-press timer
    u8g2.clearDisplay();
    u8g2.setFont(sfont);
    u8g2.setDrawColor(1);
    u8g2.drawStr(35, 9, "Reconnecting WiFi");
    u8g2.setCursor(0, 24);
    u8g2.print(ssid);
    u8g2.sendBuffer();
    cntt = 0;
    svr = true;
#ifdef LOG
    Serial.print("Reconnect: Starting WiFi");
#endif
    WiFi.begin(ssid, pass);  //reconnectWiFi
    while (WiFi.status() != WL_CONNECTED) {
#ifdef LOG
      Serial.print('.');
#endif
      delay(1000);
      cntt++;
      swtSstate = digitalRead(switchSpin);
      if ((cntt > 10) || (swtSstate == LOW)) {
        swtSstate = HIGH;
#ifdef LOG
        Serial.println();
        if (cntt > 10) Serial.println("Reconnecting WiFi failed");
        else Serial.println("Reconnect: WiFi connection cancelled");
#endif
        u8g2.setDrawColor(0);
        u8g2.drawBox(30, 0, 98, 12);  //clear line 9
        u8g2.setDrawColor(1);
        u8g2.setCursor(0, 9);
        u8g2.print(dsptname);
        u8g2.drawStr(45, 9, "offline");
        u8g2.sendBuffer();
        WiFi.disconnect();
        svr = false;
#ifdef LOG
        Serial.println("Reconnect: " + String(ssid) + " disconnected");
#endif
      }
      cntd = cd;
    }
#ifdef LOG
    Serial.println();
    Serial.println("WiFi connected.");
#endif
    if (svr == true) reconnect();
  }
  // restart with press and hold button
  if (kpbtnstate == true) {
    if ((millis() - startTime) >= 3000) {
#ifdef LOG
      Serial.println("restarting");
#endif
      u8g2.clearDisplay();
      u8g2.setFont(sfont);
      u8g2.drawStr(40, 9, "Restarting");
      u8g2.sendBuffer();
      ESP.restart();
    }
  }
}
//*****************************************************************
void kpRelease() {
  // All buttons released - no button pushed:
  if (fc0btnstate == true) {
    fc0btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 0;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 10;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 20;
    }
    sendfct(fnum);
  }
  if (fc1btnstate == true) {
    fc1btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 1;
      if (fctrlsst == 2) {
        sendfct(sfnum[MTx]);  // send 'fade btn off'
        fctrlsst = 0;
        if (bitRead(setsdhadr, MTx) == 1) sendsdhfct(sfnum[MTx]);  // send 'fade btn off' for trailer
      }
      if (fctrlsst == 1) {
        sendfct(fnum);
        fctrlsst = 0;
      }
    }
    if (fcgstate[MTx] == 1) fnum = 11;
    if (fcgstate[MTx] == 2) fnum = 21;
  }
  if (fc2btnstate == true) {
    fc2btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 2;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 12;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 22;
    }
    sendfct(fnum);
  }
  if (fc3btnstate == true) {
    fc3btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 3;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 13;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 23;
    }
    sendfct(fnum);
  }
  if (fc4btnstate == true) {
    fc4btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 4;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 14;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 24;
    }
    sendfct(fnum);
  }
  if (fc5btnstate == true) {
    fc5btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 5;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 15;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 25;
    }
    sendfct(fnum);
  }
  if (fc6btnstate == true) {
    fc6btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 6;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 16;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 26;
    }
    sendfct(fnum);
  }
  if (fc7btnstate == true) {
    fc7btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 7;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 17;
    }
    if (fcgstate[MTx] == 2) {
      fnum = 27;
    }
    sendfct(fnum);
  }
  if (fc8btnstate == true) {
    fc8btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 8;
      if (fctrlsst == 2) {
        sendfct(sfnum[MTx]);  // send 'fade btn off'
        fctrlsst = 0;
        if (bitRead(setsdhadr, MTx) == 1) sendsdhfct(sfnum[MTx]);  // send 'fade btn off' for trailer
      }
      if (fctrlsst == 1) {
        sendfct(fnum);
        fctrlsst = 0;
      }
    }
    if (fcgstate[MTx] == 1) fnum = 18;
    if (fcgstate[MTx] == 2) fnum = 28;
  }
  if (fc9btnstate == true) {
    fc9btnstate = false;
    fctbtnst = 0;
    if (fcgstate[MTx] == 0) {
      fnum = 9;
    }
    if (fcgstate[MTx] == 1) {
      fnum = 19;
    }
    sendfct(fnum);
  }
  if (fctbtnstate == true) {
    fcgstate[MTx]++;
    if (fcgstate[MTx] > 3) fcgstate[MTx] = 0;
    if (fcgstate[MTx] == 0) {
      if (bitRead(setfctbn, MTx) == 1) {
        bitWrite(setfctbn, MTx, 0);
        dsprosnam();
        vcnt[MTx] = lastvcnt;
        rcnt[MTx] = savrcnt;
        rtcnt[MTx] = savrtcnt;
        u8g2.setFont(sfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 11);  //clear fcnt
        u8g2.setDrawColor(1);
        u8g2.setCursor(46, bl2);
        u8g2.print(String(numspst[MTx]));
        dspfcts();
      }
    }
    if ((fcgstate[MTx] == 1) || (fcgstate[MTx] == 2)) dspfcts();
    // select function:
    if (fcgstate[MTx] == 3) {
      fcnt[MTx] = 0;
      dspcnt(fcnt[MTx]);
      u8g2.setFont(sfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl3, lw, 27);
      u8g2.drawBox(0, tl4, lw, 12);
      u8g2.setDrawColor(1);
      u8g2.drawStr(0, bl4, "F select");
      getfctbn(fcnt[MTx]);
      u8g2.setFont(lfont);
      u8g2.setCursor(0, bl3);
      u8g2.print(dspfctname);
      u8g2.sendBuffer();
      vcnt[MTx] = lastvcnt;
      savrcnt = rcnt[MTx];
      savrtcnt = rtcnt[MTx];
      bitWrite(setfctbn, MTx, 1);
      dspfctsns();  // display fct short names
    }
    fctbtnstate = false;
  }
}  // end of kpRelease
//***********************************************************
void characterwheel() {
  if (encoder_movedCW == true) {
    thcntv++;
    if (thcntv > 75) thcntv = 0;
    newchar = "";
    newchar = characters[thcntv];
    u8g2.setDrawColor(0);
    u8g2.drawBox(99, tl2x, 22, 18);  //clear large character
    u8g2.setDrawColor(1);
    u8g2.setFont(sfont);
    u8g2.sendBuffer();
    u8g2.setFont(lfont);
    u8g2.setCursor(100, 24);
    u8g2.print(newchar);
    u8g2.sendBuffer();
  } else {
    thcntv--;
    if (thcntv < 0) thcntv = 75;
    newchar = "";
    newchar = characters[thcntv];
    u8g2.setDrawColor(0);
    u8g2.drawBox(99, tl2x, 22, 18);  //clear large character
    u8g2.setDrawColor(1);
    u8g2.setFont(lfont);
    u8g2.setCursor(100, 24);
    u8g2.print(newchar);
    u8g2.sendBuffer();
  }
}
//-------------------------------------------------------------
void crtdccadr(byte d) {
#ifdef LOG
  Serial.println("crtdccadr( " + String(d) + ")");
#endif
  kpbtnstate = true;
  btncnt++;
  btnval = d;
  if (bitRead(setdccadr, MTx) == 1) putdccdgt();
  if (bitRead(setaccadr, MTx) == 1) putaccdgt();
}
//-----------------------------------------------------
void dspcnt(byte x) {
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(45, tl2, 20, 11);  //clear cnt
  u8g2.setDrawColor(1);
  u8g2.setCursor(50, bl2);
  u8g2.print(String(x));
  u8g2.sendBuffer();
}
//-------------------------------------------------
void putdccdgt() {
#ifdef LOG
  Serial.println("putdccdgt()");
#endif
  pshadr = true;
  clrrosnam();
  ros_eAvail = false;
  if (btncnt == 1) {
    dccadr[MTx] = btnval;
    dspchgadr();
    if (MThr == true) vfyadr(vadr);  // int vadr submitted by dspchgadr()
  }
  if ((btncnt > 1) && (btncnt < 5)) {
    clrchgadr();
    dccadrtmp = btnval;
    dccadr[MTx] = dccadr[MTx] * 10 + dccadrtmp;
    dspchgadr();
    if (MThr == true) vfyadr(vadr);  // int vadr submitted by dspchgadr()
  }
  if (btncnt == 5) {
    btncnt = 1;
    dccadr[MTx] = btnval;
    clrchgadr();
    dspchgadr();
    if (MThr == true) vfyadr(vadr);  // int vadr submitted by dspchgadr()
  }
}
//-----------------------------------------------------------
void putaccdgt() {
#ifdef LOG
  Serial.println("putaccdgt()");
#endif
  if (btncnt == 1) {
    accadr[MTx] = btnval;
    dspadcadr();
  }
  if ((btncnt > 1) && (btncnt < 5)) {
    dccadrtmp = btnval;
    accadr[MTx] = accadr[MTx] * 10 + dccadrtmp;
    dspadcadr();
  }
  if (btncnt == 5) {
    btncnt = 1;
    accadr[MTx] = btnval;
    dspadcadr();
  }
}
//-------------------------------------------------
void putportdgt() {
  //byte zthze[5] array saves digits
#ifdef LOG
  Serial.print("putportdgt() called with btnval " + String(btnval));
  Serial.println(" and btncnt " + String(btncnt));
#endif
  pshnbr = true;
  byte dgt = btncnt - 1;
  if (btncnt == 1) {
    port = btnval;
    zthze[dgt] = btnval;
    dspchgport();
  }
  if ((btncnt > 1) && (btncnt < 6)) {
    tmpport = btnval;
    port = port * 10 + tmpport;
    zthze[dgt] = btnval;
    dspchgport();
  }
  if (btncnt >= 6) {
    btncnt = 1;
    port = btnval;
    dspchgport();
  }
#ifdef LOG
  byte j = 4;
  Serial.print("zthze contains ");
  for (byte i = 5; i > 0; i--) {
    Serial.print(zthze[j]);
    j--;
  }
#endif
}
//-------------------------------------------------
void rmvportdgt() {
  if (btncnt > 0) btncnt--;
#ifdef LOG
  Serial.println("rmvportdgt called with btncnt " + String(btncnt));
  Serial.println("port contains " + String(port));
#endif
  //byte zthze[5] array contains digits entered
  pshnbr = true;
  port = port - zthze[btncnt];
  port = port / 10;
#ifdef LOG
  Serial.println("port now contains " + String(port));
#endif
}
//-------------------------------------------------
void puthostdot() {
#ifdef LOG
  Serial.println("puthostdot() called with btncnt " + String(btncnt));
#endif
  pshnbr = true;
  newchar = String('.');
  prvhoststr = newhoststr;
  newhoststr = newhoststr + newchar;
  dspchghost();
}
//-------------------------------------------------
void puthostdgt() {
#ifdef LOG
  Serial.println("puthostdgt() called with btncnt " + String(btncnt));
#endif
  pshnbr = true;
  newchar = String(btnval);
  prvhoststr = newhoststr;
  newhoststr = newhoststr + newchar;
  if (btncnt == 15) btncnt = 1;
  dspchghost();
}
//------------------------------------------------------
void dspchgport() {
#ifdef LOG
  Serial.println("dspchgport()");
#endif
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl3, lw, 12);  //clear line 38
  u8g2.setDrawColor(1);
  u8g2.drawStr(0, 38, "New port: ");
  u8g2.setCursor(60, 38);
  u8g2.print(String(port));
  u8g2.sendBuffer();
}
//------------------------------------------------------
void dspchghost() {
#ifdef LOG
  Serial.println("dspchghost()");
#endif
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl3, lw, 12);  //clear line 38
  u8g2.setDrawColor(1);
  u8g2.drawStr(0, 38, "New @: ");
  u8g2.setCursor(45, 38);
  u8g2.print(newhoststr);
  u8g2.sendBuffer();
}
//------------------------------------------------------
void display_on() {
  cntd = cd;
  u8g2.setPowerSave(0);
  dsplon = true;
}
//------------------------------------------------------
void dspsndfct() {  // display sound function
  ssndfct = ("F" + String(sndfct[MTx]));
  u8g2.setFont(sfont);
  u8g2.drawBitmap(97, tl3x, 2, 10, speaker);
  u8g2.setCursor(115, bl3);
  u8g2.print(ssndfct);
  u8g2.sendBuffer();
}
//------------------------------------------------------
void dspfcts() {
#ifdef LOG
  Serial.println("dspfcts()");
#endif
  String fcttext;
  u8g2.setFont(sfont);
  if (fcgstate[MTx] != 3) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl4, lw, 12);  //clear function numbers
    u8g2.setDrawColor(1);
  }
  if (fcgstate[MTx] == 0) {
    u8g2.drawStr(0, bl4, "Fg");
    u8g2.drawStr(15, bl4, "0");
    for (int i = 0; i <= 9; i++) {  // 0-9 in fct grp 0
      if (fctfdbkbuf[MTx][i] == 1) {
        u8g2.setCursor(dspfos[i], bl4);
        fcttext = dspfnum[i];
        u8g2.print(fcttext);
      }
    }
    if ((sndfct[MTx] == 1) && (fctfdbkbuf[MTx][1] == 1)) bitWrite(sndfctst, MTx, 1);
    if ((sndfct[MTx] == 1) && (fctfdbkbuf[MTx][1] == 0)) bitWrite(sndfctst, MTx, 0);
    if ((sndfct[MTx] == 8) && (fctfdbkbuf[MTx][8] == 1)) bitWrite(sndfctst, MTx, 1);
    if ((sndfct[MTx] == 8) && (fctfdbkbuf[MTx][8] == 0)) bitWrite(sndfctst, MTx, 0);
  }
  if (fcgstate[MTx] == 1) {
    u8g2.drawStr(0, bl4, "Fg");
    u8g2.drawStr(15, bl4, "1");
    fn = 0;
    for (int i = 10; i <= 19; i++) {  // 0-9 in fct grp 1
      if (fctfdbkbuf[MTx][i] == 1) {
        u8g2.setCursor(dspfos[fn], bl4);
        fcttext = dspfnum[fn];
        u8g2.print(fcttext);
      }
      fn++;
    }
  }
  if (fcgstate[MTx] == 2) {
    u8g2.drawStr(0, bl4, "Fg");
    u8g2.drawStr(15, bl4, "2");
    fn = 0;
    for (int i = 20; i <= 28; i++) {  // 0-8 in fct grp 2
      if (fctfdbkbuf[MTx][i] == 1) {
        u8g2.setCursor(dspfos[fn], bl4);
        fcttext = dspfnum[fn];
        u8g2.print(fcttext);
      }
      fn++;
    }
  }
  if (fcgstate[MTx] == 3) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 27);
    u8g2.drawBox(0, tl4, lw, 12);
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, bl4, "F select");
    getfctbn(fcnt[MTx]);
    u8g2.setFont(lfont);
    u8g2.setCursor(0, bl3);
    u8g2.print(dspfctname);
    u8g2.sendBuffer();
    dspfctsns();
  }
  if (adrmatch == false) dspsndfct();  //# dsp speaker
  if (bitRead(fctsavail, MTx) == 0) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 16);
    u8g2.drawBox(20, 54, 108, 10);
    u8g2.setDrawColor(1);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, bl3, "Default mapping");
  }
  u8g2.sendBuffer();
  dspswtns();
}
//------------------------------------------------------
#ifndef SIDEBTNS
void dspswtns() {  //display switch names
#ifdef LOG
  Serial.println("dspswtns()");
#endif
  String fcttext;
  u8g2.setFont(sfont);
  if (fcgstate[MTx] != 3) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl5, lw, 11);  //clear switch names
    u8g2.setDrawColor(1);
  }
  if (fcgstate[MTx] == 0) {
    if (numthrottles == 1) {  // single throttle
      for (byte i = 0; i < 4; i++) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfname0S[i];
        u8g2.print(fcttext);
      }
    }
    if (MThr == true) {  //multi throttle
      for (byte i = 0; i < 4; i++) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
    }
  }
  if (fcgstate[MTx] == 1) {
    byte j = shrtnidx;  // put index at 9 for 1st swt name in Fg 1
    for (byte i = 0; i < 4; i++) {
      if (fctswtmap[MTx][j] != 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfnames[j];
        u8g2.print(fcttext);
      }
      if (fctswtmap[MTx][j] == 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
      j++;
    }
  }
  if (fcgstate[MTx] == 2) {
    byte j = shrtnidx + 4;  // put index at 13 for 1st swt name in Fg 2
    for (byte i = 0; i < 4; i++) {
      if (fctswtmap[MTx][j] != 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfnames[j];
        u8g2.print(fcttext);
      }
      if (fctswtmap[MTx][j] == 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
      j++;
    }
  }
  u8g2.sendBuffer();
}
//--------------------------------------------------------------
void dspfctsns() {  //display function short names for Fg3-select
#ifdef LOG
  Serial.println("dspfctsns()");
#endif
  String fcttext;
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl5, lw, 11);  //clear switch names
  u8g2.setDrawColor(1);
  if (numthrottles == 1) {  // single throttle
    for (byte i = 0; i < 4; i++) {
      u8g2.setCursor(dspsos[i], bl5);
      fcttext = dspfname0S[i];
      u8g2.print(fcttext);
    }
  }
  if (MThr == true) {  //multi throttle
    for (byte i = 0; i < 4; i++) {
      u8g2.setCursor(dspsos[i], bl5);
      fcttext = dspfname0[i];
      u8g2.print(fcttext);
    }
  }
  u8g2.sendBuffer();
}
#endif  //ifndef SIDEBTNS
//------------------------------------------------------
#ifdef SIDEBTNS
void dspswtns() {  //display switch names
#ifdef LOG
  Serial.println("dspswtns()");
#endif
  if ((bitRead(fade_Avail, MTx) == 1) && (vspeed[MTx] > 0)) fadeDsp = true;
  else fadeDsp = false;
  String fcttext;
  u8g2.setFont(sfont);
  if (fcgstate[MTx] != 3) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl5, lw, 11);  //clear switch names
    u8g2.setDrawColor(1);
  }
  if (fcgstate[MTx] == 0) {
    if (numthrottles == 1) {  // single throttle
      for (byte i = 0; i < 4; i++) {
        u8g2.setCursor(dspsos[i], bl5);
        if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0Sf[i];
        else fcttext = dspfname0S[i];
        u8g2.print(fcttext);
      }
    }
    if (MThr == true) {  //multi throttle
      for (byte i = 0; i < 4; i++) {
        u8g2.setCursor(dspsos[i], bl5);
        if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0f[i];
        else fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
    }
  }
  if (fcgstate[MTx] == 1) {
    byte j = shrtnidx;  // put index at 9 for 1st swt name in Fg 1
    for (byte i = 0; i < 4; i++) {
      if (fctswtmap[MTx][j] != 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfnames[j];
        u8g2.print(fcttext);
      }
      if (fctswtmap[MTx][j] == 255) {
        u8g2.setCursor(dspsos[i], bl5);
        if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0f[i];
        else fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
      j++;
    }
  }
  if (fcgstate[MTx] == 2) {
    byte j = shrtnidx + 4;  // put index at 13 for 1st swt name in Fg 2
    for (byte i = 0; i < 4; i++) {
      if (fctswtmap[MTx][j] != 255) {
        u8g2.setCursor(dspsos[i], bl5);
        fcttext = dspfnames[j];
        u8g2.print(fcttext);
      }
      if (fctswtmap[MTx][j] == 255) {
        u8g2.setCursor(dspsos[i], bl5);
        if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0f[i];
        else fcttext = dspfname0[i];
        u8g2.print(fcttext);
      }
      j++;
    }
  }
  u8g2.sendBuffer();
}
//-------------------------------------------------------
void dspfctsns() {  //display function short names for Fg3-select
#ifdef LOG
  Serial.println("dspfctsns()");
#endif
  String fcttext;
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl5, lw, 11);  //clear switch names
  u8g2.setDrawColor(1);
  if (numthrottles == 1) {  // single throttle
    for (byte i = 0; i < 4; i++) {
      u8g2.setCursor(dspsos[i], bl5);
      if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0Sf[i];  //##09.11
      else fcttext = dspfname0S[i];
      //##09.11 fcttext = dspfname0S[i];
      u8g2.print(fcttext);
    }
  }
  if (MThr == true) {  //multi throttle
    for (byte i = 0; i < 4; i++) {
      u8g2.setCursor(dspsos[i], bl5);
      if ((fadeDsp == true) && (bitRead(sndfctst, MTx) == 1)) fcttext = dspfname0f[i];  //##09.11
      else fcttext = dspfname0[i];
      //##09.11 fcttext = dspfname0[i];
      u8g2.print(fcttext);
    }
  }
  u8g2.sendBuffer();
}
#endif  //ifdef SIDEBTNS
//-------------------------------------------------------
void dspferr() {
#ifdef LOG
  Serial.println("dspferr()");
#endif
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl4, lw, 12);
  u8g2.setDrawColor(1);
  u8g2.drawStr(0, bl4, "No fdbk, re-select loco");
  u8g2.sendBuffer();
  delay(1000);
}
//------------------------------------------------------
void dspadcadr() {
#ifdef LOG
  Serial.println("dspadcadr()");
#endif
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(80, tl3, 40, 16);
  u8g2.setDrawColor(1);
  sprintf(dspaccadr, "%04d", accadr[MTx]);
  u8g2.setCursor(85, bl3);
  u8g2.print(dspaccadr);
  u8g2.drawStr(120, bl3, "?");
  u8g2.sendBuffer();
}
//------------------------------------------------------
void clrchgadr() {
#ifdef LOG
  Serial.println("clrchgadr()");
#endif
  sprintf(dspadr, "%04d", 0);
  u8g2.setDrawColor(0);
  u8g2.drawBox(73, tl2x, 55, 16);  //"+ dccadr"
  u8g2.setDrawColor(1);
  u8g2.sendBuffer();
#ifdef LOG
  Serial.println("clrchgadr: " + String(dspadr));
#endif
}
//------------------------------------------------------
void clrrosnam() {
#ifdef LOG
  Serial.println("clrrosnam()");
#endif
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl3, lw, 16);
  u8g2.setDrawColor(1);
  u8g2.sendBuffer();
}
//------------------------------------------------------
void dspchgadr() {
#ifdef LOG
  Serial.println("dspchgadr()" + String(dccadr[MTx]));
#endif
  u8g2.setFont(lfont);
  sprintf(dspadr, "%04d", dccadr[MTx]);
  u8g2.setDrawColor(0);
  u8g2.drawBox(85, tl2x, 34, 16);  //"dccadr"
  u8g2.setDrawColor(1);
  u8g2.setCursor(85, bl2);
  u8g2.print(dspadr);
  u8g2.drawStr(120, bl2, "?");
  u8g2.sendBuffer();
  vadr = dccadr[MTx];
}
//------------------------------------------------------
void vfyadr(int vadr) {
  adrmatch = false;
  byte Tnum;
#ifdef LOG
  Serial.print("vfyadr() - ");
  Serial.println(vadr);
#endif
  for (byte x = 0; x < numthrottles; x++) {
    if (x == MTx) x++;                                             // skip current throttle
    if ((bitRead(actthrottles, x) == 1) && (dccadr[x] == vadr)) {  //address is in another throttle
      adrmatch = true;
      Tnum = x + 1;
      break;
    }
  }
  if (adrmatch == true) {
#ifdef LOG
    Serial.print("DccAdr ");
    Serial.print(vadr);
    Serial.print(" already used by throttle ");
    Serial.println(Tnum);
#endif
    u8g2.setFont(sfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(75, tl3, 53, 16);  //clear locoadr
    u8g2.setDrawColor(1);
    u8g2.drawStr(75, bl3, "used by T");
    u8g2.setCursor(120, bl3);
    u8g2.print(Tnum);
    u8g2.sendBuffer();
  }
}
//-----------------------------------------------------------
void dsprosnam() {
#ifdef LOG
  Serial.println("dsprosnam()");
  Serial.println("loconame: " + loconame[MTx]);
#endif
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl3, lw, 16);
  u8g2.setDrawColor(1);
  u8g2.setCursor(0, bl3);
  u8g2.print(loconame[MTx]);
  u8g2.sendBuffer();
}
//------------------------------------------------------
void dsprosadr() {
#ifdef LOG
  Serial.print("dsprosadr() - ");
  Serial.println("locoadr: " + locoadr[MTx]);
#endif
  String text = locoadr[MTx];
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(80, tl3, 48, 16);
  u8g2.setDrawColor(1);
  u8g2.setCursor(92, bl3);
  u8g2.print(text);
  u8g2.sendBuffer();
  vadr = locoadr[MTx].toInt();
}
//------------------------------------------------------
void getrosnam(int ptr) {
#ifdef LOG
  Serial.println("getrosnam(" + String(ptr) + ")");
#endif
  int rs = rosnamoffsets[ptr];       // start of loco name
  int re = roster.indexOf('}', rs);  // end of loco name
  loconame[MTx] = roster.substring(rs, re);
  ros_eAvail = true;
}
//--------------------------------------------------------------------------
void getrosadr(int ptr) {
#ifdef LOG
  Serial.println("getrosadr(" + String(ptr) + ")");
#endif
  int rs = rosadroffsets[ptr];       // begin of loco address
  int re = roster.indexOf('}', rs);  // end of loco address
  locoadr[MTx] = roster.substring(rs, re);
}
//--------------------------------------------------------------------------
void getrosnamen() {
#ifdef LOG
  Serial.println("getrosnamen()");
#endif
  for (int i = 0; i <= numos; i++) {
    rxn = roster.indexOf('[', rxn);  // first/next start of name
    rxn++;
    rxnn = rxn;
    rxnn = roster.indexOf('}', rxnn);  // first/next end of name
    if (roster.substring(rxn, rxnn) == loconame[MTx]) {
      break;
    }
  }
}
//-------------------------------------------------------------------------
void rtvrosnam() {
  ros_eAvail = false;
#ifdef LOG
  Serial.println("rtvrosnam()");
  Serial.println("loco name for " + String(dccadr[MTx]));
#endif
  if ((dccadr[MTx] > 0) && (dccadr[MTx] <= 9999)) {
#ifdef LOG
    Serial.println("searching...");
#endif
    for (byte i = 0; i < numre; i++) {
      getrosadr(i);
      int dccadrf = locoadr[MTx].toInt();
      if (dccadrf == dccadr[MTx]) {
        getrosnam(i);
        break;
      } else {
        clrrosnam();
        loconame[MTx] = "";
      }
    }
  }
}
//------------------------------------------------------
void getfadefbk() {
#ifdef LOG
  Serial.println("getfadefbk()");
#endif
  byte ffnum = sfnum[MTx];
  fdfctst = fctfdbkbuf[MTx][ffnum];  // get fade function state feedback
  if (fdfctst == 1) {
    bitWrite(faded, MTx, 1);  // sound is faded
    u8g2.setFont(sfont);
    u8g2.drawStr(65, bl2x, "F");
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Sound is faded");
#endif
  } else {
    bitWrite(faded, MTx, 0);
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(65, tl2, 10, 16);  //clear F(aded) ##09.15 > 11 = 16
    u8g2.setDrawColor(1);
    if (bitRead(setsdhadr, MTx) == 1) u8g2.drawStr(73, bl2x, "+");
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("Sound is not faded");
#endif
  }
}
//-----------------------------------------------------
void getroute(int ptr) {
#ifdef LOG
  Serial.println("getroute(" + String(ptr) + ")");
#endif
  int rss = rsosa[ptr];
  int rse = routes.indexOf('}', rss);
  rsysname = routes.substring(rss, rse);
#ifdef LOG
  Serial.println(rsysname);
#endif
  int rus = ruosa[ptr];
  int rue = routes.indexOf('}', rus);
  rusrname = routes.substring(rus, rue);
#ifdef LOG
  Serial.println(rusrname);
#endif
}
//-----turnouts---------------------------------------
void gettoname(int ptr) {
#ifdef LOG
  Serial.println("gettoname(" + String(ptr) + ")");
#endif
  int rss = tsosa[ptr];
  int rse = turnouts.indexOf('}', rss);
  tsysname = turnouts.substring(rss, rse);
#ifdef LOG
  Serial.println(tsysname);
#endif
  accadr[MTx] = tsysname.toInt();
  int rus = tuosa[ptr];
  int rue = turnouts.indexOf('}', rus);
  tusrname = turnouts.substring(rus, rue);
#ifdef LOG
  Serial.println(tusrname);
#endif
}
//------------------------------------------------------
void getfctbn(byte ptr) {  // get function by name, ptr is fcnt
//find function name in array "fctsbuffer" and display
#ifdef LOG
  Serial.println("getfctbn()");
#endif
  byte fs = fctnos[MTx][ptr];
  byte fe = fctnoe[MTx][ptr];
  fnum = fctnox[MTx][ptr];
  dspfctname = fctsbuffer[MTx].substring(fs, fe);
  dspsfnum(fnum);
#ifdef LOG
  Serial.print(dspfctname);
  Serial.print(" fct nbr: ");
  Serial.println(fnum);
#endif
}
//------------------------------------------------------
void dspsfnum(byte x) {
#ifdef LOG
  Serial.println("dspsfnum(" + String(x) + ")");
#endif
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(60, tl4, 68, 12);
  u8g2.setDrawColor(1);
  u8g2.setCursor(60, bl4);
  u8g2.print(String(x));
  if (fctfdbkbuf[MTx][x] == 1) u8g2.drawStr(90, bl4, "ON");
  if (fctfdbkbuf[MTx][x] == 0) u8g2.drawStr(90, bl4, "OFF");
  u8g2.sendBuffer();
}
//--------------------------------------------------------
void set_speed() {
#ifdef LOG
  Serial.println("set_speed()");
#endif
  inhmsglog = true;  // inhibit inbound message logging
  lastvcnt = vcnt[MTx];
  dspeed = vcnt[MTx];
  if ((numspst[MTx] == 28) && (numspst[MTx] != 14)) {
    vtemp = vcnt[MTx] * 4.5;
  } else {
    vtemp = vcnt[MTx];
  }
  if (prvspeed[MTx] != vtemp) {
    if ((vtemp == 0) || (prvspeed[MTx] == 0)) chgfn = true;
    prvspeed[MTx] = vtemp;
    vspeed[MTx] = vtemp;
    xmits = locoacts[MTx] + "V" + String(vspeed[MTx]);
    if (svr == true) {
      hben = false;
      client.print(xmits + "\r\n");
      delay(fdelay);
      if ((bitRead(setsdhadr, MTx) == 1) && (dccadr[MTx] != sdhadr[MTx])) {
        xmits = sdhacts[MTx] + "V" + String(vspeed[MTx]);
        client.print(xmits + "\r\n");
      }
      cnth = ch;
      hben = true;
    }
  }
  dsp_speed();
}
//-------------------------------------------------------
void dsp_speed() {
#ifdef LOG
  Serial.println("dsp_speed()");
#endif
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(15, tl2, 27, 14);  //clear speed
  u8g2.setDrawColor(1);
  u8g2.setCursor(15, bl2);
  u8g2.print(dspeed);
  u8g2.setFont(sfont);
  u8g2.sendBuffer();
  if (chgfn == true) {
    dspswtns();
    chgfn = false;
  }
  inhmsglog = false;
}
//------------------------------------------------------
void dsp_dctst() {
#ifdef LOG
  Serial.println("dsp_dctst()");
#endif
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl2, 10, 11);
  u8g2.setDrawColor(1);
  //if (dctstate == true) u8g2.drawStr(0, 25, "F");
  if (bitRead(dctstate, MTx) == 1) u8g2.drawBitmap(0, tl2, 1, 11, forward);
  //if (dctstate == false) u8g2.drawStr(0, 25, "R");
  if (bitRead(dctstate, MTx) == 0) u8g2.drawBitmap(0, tl2, 1, 11, reverse);
  u8g2.sendBuffer();
}
//---------------------------------------------------------
void dspdccadr() {
#ifdef LOG
  Serial.print("dspdccadr() - ");
  Serial.println("dccadr: " + String(dccadr[MTx]));
#endif
  sprintf(dspadr, "%04d", dccadr[MTx]);
  u8g2.setFont(lfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(73, tl2x, 55, 16);  //"+dccadr?"
  u8g2.setDrawColor(1);
  u8g2.setCursor(85, bl2);
  u8g2.print(dspadr);
  if (bitRead(setsdhadr, MTx) == 1) u8g2.drawStr(73, bl2x, "+");
  if (bitRead(faded, MTx) == 1) {
    u8g2.setFont(sfont);
    u8g2.drawStr(65, bl2x, "F");
  }
  u8g2.sendBuffer();
}
//----------------------------------------------------------
void swtthrottle() {
#ifdef LOG
  Serial.println("swtthrottle()");
#endif
  ctname = tname + String(MTn);
#ifdef LOG
  dsptname = ctname + "d";
#endif
#ifndef LOG
  dsptname = ctname;
#endif
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, 0, 45, 12);
  u8g2.setDrawColor(1);
  u8g2.setCursor(0, 9);
  u8g2.print(dsptname);
  u8g2.sendBuffer();
#ifdef LOG
  Serial.println("Throttle changed to: " + String(MTn));
  Serial.println("dccadr in this throttle: " + String(dccadr[MTx]));
  Serial.println("Fct Grp state: " + String(fcgstate[MTx]));
#endif
  if (bitRead(actthrottles, MTx) == 1) {  //if this throttle is active
    dspdccadr();
    dsprosnam();
    vadr = dccadr[MTx];
    vfyadr(vadr);
    if (dccadrrlsd[MTx] == dccadr[MTx]) {
      //display "?"....
      u8g2.drawStr(120, bl2, "?");
      u8g2.sendBuffer();
#ifdef LOG
      Serial.println("dccadr " + String(dccadr[MTx]) + " is released.");
#endif
    }
    dspeed = vcnt[MTx];
    vcntv = vcnt[MTx];
    fcntv = fcnt[MTx];
    rcntv = rcnt[MTx];
    rtcntv = rtcnt[MTx];
    tcntv = tcnt[MTx];
    dsp_speed();
    dsp_dctst();
    dspfcts();
  } else {
    if (dccadr[MTx] <= 3) dccadr[MTx] = dccstck[MTx];  // get it from stack
    simlokbtn();
    vadr = dccadr[MTx];
    vfyadr(vadr);
  }
}
//-------------------------------------------------------------
void rtvnetcreds() {
#ifdef LOG
  Serial.println("rtvnetcreds()");
#endif
  ssidstr = "";
  len = EEPROM.read(108);
  if ((len > 0) && (len < 26)) {  //making sure length is valid
    len++;                        //include null terminator
    byte j = 109;
    for (byte i = 0; i < len; i++) {
      ssidstr = ssidstr + char(EEPROM.read(j));
      j++;
    }
    ssidstr.toCharArray(ssid, len);
#ifdef LOG
    Serial.print("SSID retrieved - length: " + String(len));
    Serial.println(", SSID: " + String(ssid));
#endif
  }
  passstr = "";
  len = EEPROM.read(135);
  if ((len > 0) && (len < 26)) {
    len++;
    byte j = 136;
    for (byte i = 0; i < len; i++) {
      passstr = passstr + char(EEPROM.read(j));
      j++;
    }
    passstr.toCharArray(pass, len);
#ifdef LOG
#ifdef LOGNETKEY
    Serial.print("pass key retrieved - length: " + String(len));
    Serial.println(", pass key: " + String(pass));
#endif
#endif
  }
  hoststr = "";
  len = EEPROM.read(162);
  if ((len > 0) && (len < 17)) {
    len++;
    byte j = 163;
    for (byte i = 0; i < len; i++) {
      hoststr = hoststr + char(EEPROM.read(j));
      j++;
    }
    hoststr.toCharArray(host, len);
#ifdef LOG
    Serial.print("Host IP-address retrieved - length: " + String(len));
    Serial.println(", Host: " + String(host));
#endif
  }
  //
  port = EEPROM.read(180);
  port = (port << 8) + EEPROM.read(181);
  if ((port < 1023) && (port > 65535)) {
    port = dftport;
    EEPROM.write(180, (port >> 8) & 0xff);
    EEPROM.write(181, port & 0xff);
    EEPROM.commit();
  }
#ifdef LOG
  Serial.println("Using Port: " + String(port));
#endif
}
//---------------------------------------------------------
void rtvdftnetcreds() {
#ifdef LOG
  Serial.println("rtvdftnetcreds()");
#endif
  newssidstr = dftssid;
  len = newssidstr.length();
  len++;
  newssidstr.toCharArray(ssid, len);
#ifdef LOG
  Serial.print("Using default SSID  - length: " + String(len));
  Serial.println(", SSID: " + String(ssid));
#endif
  newpassstr = dftpass;
  len = newpassstr.length();
  len++;
  newpassstr.toCharArray(pass, len);
#ifdef LOG
#ifdef LOGNETKEY
  Serial.print("Using default pass key  - length: " + String(len));
  Serial.println(", pass key: " + String(pass));
#endif
#endif
  newhoststr = dfthost;
  len = newhoststr.length();
  len++;
  newhoststr.toCharArray(host, len);
#ifdef LOG
  Serial.print("Using default Host  - length: " + String(len));
  Serial.println(", Host: " + String(host));
#endif
  port = dftport;
#ifdef LOG
  Serial.println("Using default Port: " + String(port));
#endif
}
//------------------------------------------------------
void sendsdhfct(byte t_fnum) {
#ifdef LOG
  Serial.println("sendsdhfct(" + String(t_fnum) + ")");
#endif
  if (t_fnum != 255) {
    if (fctbtnst == 1) {
      xmits = sdhacts[MTx] + "F1" + String(t_fnum);  // function button on
    }
    if (fctbtnst == 0) {
      xmits = sdhacts[MTx] + "F0" + String(t_fnum);  // function button off
    }
#ifdef LOG
    Serial.print("sendsdhfct: ");
    Serial.println(xmits);
#endif
    if (svr == true) {
      client.print(xmits + "\r\n");
      delay(fdelay);
    }
  }
}
//------------------------------------------------------
void sendfct(byte fnum) {
#ifdef LOG
  Serial.println("sendfct()");
  Serial.println("fct key " + String(fnum) + " state " + String(fctbtnst));
#endif
  fctfdbk = false;
  bool xptfdbk = false;
  if (fnum != 255) {
    if (fctbtnst == 1) {
      xmits = locoacts[MTx] + "F1" + String(fnum);
      xptfdbk = true;  //expect feedback from server
    }
    if (fctbtnst == 0) {
      xmits = locoacts[MTx] + "F0" + String(fnum);
    }
#ifdef LOG
    Serial.println("sending in xmits: " + xmits);
#endif
    if (svr == true) {
      dsptr(1);
      client.print(xmits + "\r\n");
      delay(ldelay);
      while (client.available()) {
        jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
        Serial.print("Server reply to sendfct: ");
        Serial.println(jmri_res);
#endif
        if (jmri_res.startsWith(lkf[MTx])) {
          int ix = jmri_res.indexOf('F');
          ix++;
          jmri_sub = jmri_res.substring(ix, ix + 3);
          String fstate = jmri_sub.substring(0, 1);
          fctstate = fstate.toInt();
          String fctnum = jmri_sub.substring(1, 3);
          fctfdbk = true;
          byte fnumtmp = fctnum.toInt();
          if (fnumtmp == fnum) {
            fctfdbkbuf[MTx][fnum] = fctstate;
          }
        }
      }
      dsptr(0);
      cnth--;  //making up for lost time during inbound message
      dspfcts();
#ifdef LOG
      Serial.print("fct feedback arr: ");
      for (byte i = 0; i < numfcts; i++) {
        if (i > 0) Serial.print(",");
        Serial.print(fctfdbkbuf[MTx][i]);
      }
      Serial.println();
#endif
      if ((fctfdbk == false) && (xptfdbk == true)) {
#ifdef LOG
        Serial.println("No feedback, re-select loco");
#endif
        dspferr();
        simlokbtn();
      }
    }
  }
}
//----------------------------------------------------------
void set_forward() {
#ifdef LOG
  Serial.println("set_forward()");
#endif
  bool dctfdbk = false;
  byte dct = 0;
  if (estop == true) {
    estop = false;
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(90, tl3, 38, 16);  //clear stop
    u8g2.setDrawColor(1);
    u8g2.sendBuffer();
  }
  xmits = locoacts[MTx] + "R1";
#ifdef LOG
  if (bitRead(setsdhadr, MTx) == 1) Serial.print("set_forward: leader ");
  else Serial.print("set_forward: ");
  Serial.println(xmits);
#endif  //LOG
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
      Serial.println("Server response to set_forward:");
      Serial.println(jmri_res);
#endif
      if (jmri_res.startsWith(lkr[MTx])) {  // get direction
        int ix = jmri_res.indexOf('R');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        dct = jmri_sub.toInt();
        dctfdbk = true;
      }
    }
    dsptr(2);
    if ((dct == 1) && (dctfdbk == true)) {
      bitWrite(dctstate, MTx, 1);
#ifdef LOG
      Serial.println("dctstate is forward");
#endif
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl2, 10, 11);  //clear direction symbol
      u8g2.setDrawColor(1);
      //u8g2.drawStr(0, 25, "F");
      u8g2.drawBitmap(0, tl2, 1, 11, forward);
      u8g2.sendBuffer();
    }
    if ((dct == 0) && (dctfdbk == true)) {
      bitWrite(dctstate, MTx, 0);
#ifdef LOG
      Serial.println("dctstate is reverse");
#endif
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl2, 10, 11);  //clear direction symbol
      u8g2.setDrawColor(1);
      //u8g2.drawStr(0, 25, "R");
      u8g2.drawBitmap(0, tl2, 1, 11, reverse);
      u8g2.sendBuffer();
    }
    if (dctfdbk == false) {
#ifdef LOG
      Serial.println("No feedback, re-select loco");
#endif
      dspferr();
      simlokbtn();
    }
  }
  xmits = locoacts[MTx] + "V0";
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(fdelay);
    dsptr(0);
  }
#ifdef LOG
  Serial.println(xmits);
#endif
  //-----------------------
  if ((bitRead(setsdhadr, MTx) == 1) && (dccadr[MTx] != sdhadr[MTx])) {
    if (sdhdct[MTx] == 1) xmits = sdhacts[MTx] + "R1";
    if (sdhdct[MTx] == 0) xmits = sdhacts[MTx] + "R0";
    if (svr == true) {
      dsptr(1);
      client.print(xmits + "\r\n");
      delay(fdelay);
    }
#ifdef LOG
    Serial.print("set_forward: trailer ");
    Serial.println(xmits);
#endif
    xmits = sdhacts[MTx] + "V0";
    if (svr == true) {
      client.print(xmits + "\r\n");
      delay(fdelay);
      dsptr(0);
    }
#ifdef LOG
    Serial.println(xmits);
#endif
  }
}
//----------------------------------------------------------------
void set_reverse() {
#ifdef LOG
  Serial.println("set_reverse()");
#endif
  bool dctfdbk = false;
  byte dct = 0;
  if (estop == true) {
    estop = false;
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(90, tl3, 38, 16);  //clear stop
    u8g2.setDrawColor(1);
    u8g2.sendBuffer();
  }
  xmits = locoacts[MTx] + "R0";
#ifdef LOG
  if (bitRead(setsdhadr, MTx) == 1) Serial.print("set_reverse: leader ");
  else Serial.print("set_reverse: ");
  Serial.println(xmits);
#endif  //LOG
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
      Serial.println("Server response to set_reverse:");
      Serial.println(jmri_res);
#endif
      if (jmri_res.startsWith(lkr[MTx])) {  // get direction
        int ix = jmri_res.indexOf('R');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        dct = jmri_sub.toInt();
        dctfdbk = true;
      }
    }
    dsptr(2);
    //cnth--;  //making up for lost time during inbound message
    if ((dct == 1) && (dctfdbk == true)) {
      bitWrite(dctstate, MTx, 1);
#ifdef LOG
      Serial.println("dctstate is forward");
#endif
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl2, 10, 11);
      u8g2.setDrawColor(1);
      //u8g2.drawStr(0, 25, "F");
      u8g2.drawBitmap(0, tl2, 1, 11, forward);
      u8g2.sendBuffer();
    }
    if ((dct == 0) && (dctfdbk == true)) {
      bitWrite(dctstate, MTx, 0);
#ifdef LOG
      Serial.println("dctstate is reverse");
#endif
      u8g2.setFont(lfont);
      u8g2.setDrawColor(0);
      u8g2.drawBox(0, tl2, 10, 11);
      u8g2.setDrawColor(1);
      //u8g2.drawStr(0, 25, "R");
      u8g2.drawBitmap(0, tl2, 1, 11, reverse);
      u8g2.sendBuffer();
    }
    if (dctfdbk == false) {
#ifdef LOG
      Serial.println("No feedback, re-select loco");
#endif
      dspferr();
      simlokbtn();
    }
  }
  xmits = locoacts[MTx] + "V0";
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(fdelay);
    dsptr(0);
  }
#ifdef LOG
  Serial.println(xmits);
#endif
  //-----------------------
  if ((bitRead(setsdhadr, MTx) == 1) && (dccadr[MTx] != sdhadr[MTx])) {
    if (sdhdct[MTx] == 1) xmits = sdhacts[MTx] + "R0";
    if (sdhdct[MTx] == 0) xmits = sdhacts[MTx] + "R1";
    if (svr == true) {
      dsptr(1);
      client.print(xmits + "\r\n");
      delay(fdelay);
    }
#ifdef LOG
    Serial.print("set_reverse: trailer ");
    Serial.println(xmits);
#endif
    delay(fdelay);
    xmits = sdhacts[MTx] + "V0";
    if (svr == true) {
      client.print(xmits + "\r\n");
      delay(fdelay);
      dsptr(0);
    }
#ifdef LOG
    Serial.println(xmits);
#endif
  }
}
//-------------------------------------------------------------
void chgsdhdct() {  //change direction of trailer
#ifdef LOG
  Serial.println("chgsdhdct()");
#endif
  if (sdhdct[MTx] == 1) xmits = sdhacts[MTx] + "R1";  //sdhdct was switched prior
  if (sdhdct[MTx] == 0) xmits = sdhacts[MTx] + "R0";
  if (svr == true) {
    client.print(xmits + "\r\n");
    delay(fdelay);
  }
#ifdef LOG
  Serial.print("chgsdhdct: ");
  Serial.println(xmits);
#endif
  xmits = sdhacts[MTx] + "V0";
  if (svr == true) {
    client.print(xmits + "\r\n");
    delay(fdelay);
    vcnt[MTx] = 0;
    dsp_speed();
  }
#ifdef LOG
  Serial.print("chgsdhdct: ");
  Serial.println(xmits);
#endif
}
/////////////////////////////////////////////////////////////////
void releaseadr(int rlsadr) {
  bool dispatch = true;
  rlsfdbk = false;
#ifdef LOG
  Serial.println("releaseadr(" + String(rlsadr) + ")");
#endif
  bldsladr(rlsadr);
  String MTprf;
  MTprf = "M" + String(MTn);
  String xmitsi;
  xmits = MTprf + "-" + dccadrsnd + "<;>r";
  xmitsi = MTprf + "A" + dccadrsnd + "<;>I";
#ifdef LOG
  Serial.println("Sending Idle " + xmitsi);
#endif
  if (svr == true) {
    dsptr(1);
    client.print(xmitsi + "\r\n");  //send "idle"
    delay(fdelay);
#ifdef LOG
    Serial.println("Releasing address " + xmits);
#endif
    client.print(xmits + "\r\n");  //send "release"
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
      String lk = MTprf + "-" + dccadrsnd;
      if (jmri_res.startsWith(lk)) {
        rlsfdbk = true;
        dispatch = false;
#ifdef DEBUG
        Serial.print("Server-response to release: ");
        Serial.println(jmri_res + " -> ok.");
#endif
      } else {
        dispatch = true;
#ifdef DEBUG
        Serial.print("Server-response to release: ");
        Serial.println(jmri_res);
#endif
      }
    }
    if (dispatch == true) {
      xmits = MTprf + "-" + dccadrsnd + "<;>d";
      client.print(xmits + "\r\n");  //send "dispatch"
      delay(sdelay);
      while (client.available()) {
        jmri_res = client.readStringUntil('\n');
        String lk = MTprf + "-" + dccadrsnd;
        if (jmri_res.startsWith(lk)) {
          rlsfdbk = true;
#ifdef DEBUG
          Serial.print("Server-response to dispatch: ");
          Serial.println(jmri_res + " -> ok.");
#endif
        } else {
#ifdef DEBUG
          Serial.print("Server-response to dispatch: ");
          Serial.println(jmri_res);
#endif
        }
        dispatch = false;
      }
    }
    dsptr(0);  //leave fdbk on for a little while
    cnth--;    //making up for lost time during inbound message
  }
  if (dispatch == false) {
    dccadrrlsd[MTx] = rlsadr;  // if there was no feedback it wasn't active anyway.
#ifdef LOG
    Serial.println("No feedback to releaseadr().");
#endif
  }
}
//-------------------------------------------------------------
void releaseall() {
#ifdef LOG
  Serial.println("releaseall()");
#endif
  if (numthrottles == 1) {
    client.print("M1-*<;>r\r\n");
    delay(fdelay);
#ifdef LOG
    Serial.println("Sent M1-*<;>r");
#endif
  }
  if (MThr == true) {
    byte x = 1;
    for (byte n = 0; n < numthrottles; n++) {
      if (bitRead(actthrottles, n) == 1) {
        xmits = "M" + String(x) + "-*<;>r";
        client.print(xmits + "\r\n");
        delay(fdelay);
        sdhadr[n] = 0;
#ifdef LOG
        Serial.println("Sent: " + xmits);
#endif
      }
      x++;
    }
  }
  if (bitRead(setsdhadr, MTx) == 1) bitWrite(setsdhadr, MTx, 0);
}
//-------------------------------------------------------------
void compsdhadr() {
#ifdef LOG
  Serial.println("compsdhadr()");
#endif
  bldsladr(sdhadr[MTx]);
  String MTprf;
  MTprf = "M" + String(MTn);
  xmits = MTprf + "+" + dccadrsnd + "<;>" + dccadrsnd;
  sdhacts[MTx] = MTprf + "A" + dccadrsnd + "<;>";  // set variable for actions
}
//---------------------------------------------------------------------
void bldsladr(int adr) {  //set address for short or long
#ifdef LOG
  Serial.println("bldsladr(" + String(adr) + ")");
#endif
  if (adr < 128) dccadrsnd = "S" + String(adr);
  if (adr > 127) dccadrsnd = "L" + String(adr);
}
//---------------------------------------------------------------------
void sendadr(int adr) {  // add a locomotive
#ifdef LOG
  Serial.print("sendadr(" + String(adr) + ") ");
  if (steel == true) Serial.print("steel request");
  Serial.println();
#endif
  bldsladr(adr);
  String MTprf;
  MTprf = "M" + String(MTn);
  if (ros_eAvail == false) {
    if (steel == false) xmits = MTprf + "+" + dccadrsnd + "<;>" + dccadrsnd;  // "M#+S126<;>S126 or M#+L126<;>L126"
    if (steel == true) xmits = MTprf + "S" + dccadrsnd + "<;>" + dccadrsnd;   // "M#SS126<;>S126 or M#SL126<;>L126"
  } else {
    if (steel == false) xmits = MTprf + "+" + dccadrsnd + "<;>E" + loconame[MTx];
    if (steel == true) xmits = MTprf + "S" + dccadrsnd + "<;>E" + loconame[MTx];
    ;
  }
  locoacts[MTx] = MTprf + "A" + dccadrsnd + "<;>";  //set variable for actions used by other routines
  lkf[MTx] = locoacts[MTx] + "F";                   // search argument to look for function states
  lkr[MTx] = locoacts[MTx] + "R";                   // search argument to look for direction
  lks[MTx] = locoacts[MTx] + "s";                   // search argument to look for speed step
  //# dccadr[MTx] = adr;
  ros_eAvail = false;
#ifdef LOG
  Serial.println("Sending: " + xmits);
#endif
  bitWrite(fctsavail, MTx, 0);
  fcgstate[MTx] = 0;
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(15, tl4, 113, 12);
  u8g2.setDrawColor(1);
  u8g2.drawStr(30, bl4, "mapping functions");
  u8g2.sendBuffer();
  String steelrsp;
  if (svr == true) {
    steel = false;
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
      Serial.print("Server-response to sendadr: ");
      Serial.println(jmri_res);
#endif
      //look for steal request in server response:
      String lkstrq = MTprf + "S";
      if (jmri_res.startsWith(lkstrq)) {
        steelrsp = jmri_res;
        strq = true;
#ifdef LOG
        Serial.println("Steel response: " + steelrsp);
#endif
      }
      //look for fuctions in server response:
      String lkfcta = MTprf + "L";
      if (jmri_res.startsWith(lkfcta)) {  // get fctsbuffer of loco
        fctsbuffer[MTx] = jmri_res;
        bitWrite(fctsavail, MTx, 1);
#ifdef LOG
        Serial.println("From server - list of functions: ");
        Serial.println(fctsbuffer[MTx]);
#endif
      }
      if (jmri_res.startsWith(lkf[MTx])) {  //get function states
        int ix = jmri_res.indexOf('F');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        fctstate = jmri_sub.toInt();
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 2);
        fnum = jmri_sub.toInt();
        if (fnum < 10) {
          jmri_sub = jmri_res.substring(ix, ix + 1);
          fnum = jmri_sub.toInt();
        }
        if (fnum < numfcts) {  // limit to configured nbr of fctsbuffer
          fctfdbkbuf[MTx][fnum] = fctstate;
        }
      }
      if (jmri_res.startsWith(lkr[MTx])) {  // get direction
        int ix = jmri_res.indexOf('R');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        int dct = jmri_sub.toInt();
        if (dct == 1) {
          bitWrite(dctstate, MTx, 1);
#ifdef LOG
          Serial.println("dctstate is forward");
#endif
          u8g2.setFont(lfont);
          u8g2.setDrawColor(0);
          u8g2.drawBox(0, tl2, 10, 11);
          u8g2.setDrawColor(1);
          //u8g2.drawStr(0, 25, "F");
          u8g2.drawBitmap(0, tl2, 1, 11, forward);
          u8g2.sendBuffer();
        }
        if (dct == 0) {
          bitWrite(dctstate, MTx, 0);
#ifdef LOG
          Serial.println("dctstate is reverse");
#endif
          u8g2.setFont(lfont);
          u8g2.setDrawColor(0);
          u8g2.drawBox(0, tl2, 10, 11);
          u8g2.setDrawColor(1);
          //u8g2.drawStr(0, 25, "R");
          u8g2.drawBitmap(0, tl2, 1, 11, reverse);
          u8g2.sendBuffer();
        }
      }
      if (jmri_res.startsWith(lks[MTx])) {  // look for speed step setting in jmri
        int ix = jmri_res.indexOf('s');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        spdstpm = jmri_sub.toInt();
        if (spdstpm == 1) numspst[MTx] = 126;  // speed step mode 128 (0=stop,1to126+Estop=128)
        if (spdstpm == 2) numspst[MTx] = 28;   // speed step mode 28  (appr. 127/28)
        if (spdstpm == 4) numspst[MTx] = 27;   // ignored (old Lenz only & obsolete)
        if (spdstpm == 8) numspst[MTx] = 14;   // ignored (obsolete)
#ifdef LOG
        Serial.print("current speed step mode: ");
        Serial.println(numspst[MTx]);
#endif
        u8g2.setFont(sfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 14);  //clear speed step mode
        u8g2.setDrawColor(1);
        u8g2.setCursor(46, bl2);
        u8g2.print(String(numspst[MTx]));
        u8g2.sendBuffer();
      }
    }  // close while
    dsptr(0);
    cnth--;  //making up for lost time during inbound message
    //for single throttle only, match direction setting of loco with switch setting:
    if (numthrottles == 1) {
      swtFstate = digitalRead(switchFpin);
      swtRstate = digitalRead(switchRpin);
      if ((swtFstate == LOW) && (swtRstate == HIGH) && (bitRead(dctstate, MTx) == 0)) set_forward();
      if ((swtFstate == HIGH) && (swtRstate == LOW) && (bitRead(dctstate, MTx) == 1)) set_reverse();
    }
    if (strq == true) steel_inquiry();
  }
  // reset fctswtmap:
  for (int i = 0; i < numswfcs; i++) {  //reset all array elements to default
    fctswtmap[MTx][i] = 255;
  }
  for (int i = 0; i < numfcts; i++) {  //reset all array elements to default
    fctnos[MTx][i] = 255;
    fctnoe[MTx][i] = 255;
    fctnox[MTx][i] = 255;
  }
  // build dedicated function switch mapping array based on Roster:
  if (bitRead(fctsavail, MTx) == 1) {
#ifdef LOG
    Serial.println("mapping switches");
#endif
  }
  if (bitRead(fctsavail, MTx) == 0) {
    u8g2.setFont(sfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(0, tl3, lw, 16);
    u8g2.drawBox(20, 54, 108, 10);
    u8g2.setDrawColor(1);
    u8g2.drawStr(0, bl3, "Default mapping");
    u8g2.sendBuffer();
    if (dsndfct == 0) {
      for (int i = 0; i < numswfcs; i++) {
        fctswtmap[MTx][i] = fctswtmapdftEU[i];
      }
    } else {
      for (int i = 0; i < numswfcs; i++) {
        fctswtmap[MTx][i] = fctswtmapdftUS[i];
      }
    }
#ifdef LOG
    Serial.println("Using default mapping for switches");
#endif
  }
  bldswtmaparr();
  bldfctidx();
  if (fctswtmap[MTx][6] == 255) {
    drivehold[MTx] = 0;
#ifdef LOG
    Serial.println("drivehold not available for this loco");
#endif
  } else {
    drivehold[MTx] = 1;
#ifdef LOG
    Serial.println("drivehold available for this loco");
#endif
  }
  sndfct[MTx] = fctswtmap[MTx][8];
  ssndfct = ("F" + String(sndfct[MTx]));
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl5, lw, 11);  //clear switch names
  u8g2.setDrawColor(1);
  if (adrmatch == false) dspsndfct();  //# dsp speaker
#ifdef LOG
  Serial.println("Sound function for this loco is " + ssndfct);
#endif
  sfnum[MTx] = fctswtmap[MTx][7];
  if (sfnum[MTx] != 255) {
    bitWrite(fade_Avail, MTx, 1);
#ifdef LOG
    Serial.println("Fade available for this loco");
    Serial.println("Fade function is " + String(sfnum[MTx]));
#endif
    byte ffnum = sfnum[MTx];
    if (fctfdbkbuf[MTx][ffnum] == 1) {
      bitWrite(faded, MTx, 1);
      fadebtn = true;
      u8g2.setFont(sfont);
      u8g2.drawStr(65, bl2x, "F");
      u8g2.sendBuffer();
#ifdef LOG
      Serial.println("Sound of this loco is faded");
#endif
    } else if (bitRead(setsdhadr, MTx) == 0) {
      u8g2.setDrawColor(0);
      u8g2.drawBox(65, tl2, 10, 14);  //clear F(-aded)
      u8g2.setDrawColor(1);
      u8g2.sendBuffer();
    }
  } else {
    bitWrite(fade_Avail, MTx, 0);
    byte ffnum = sfnum[MTx];
    fctfdbkbuf[MTx][ffnum] = 0;
#ifdef LOG
    Serial.println("Fade not available for this loco");
#endif
  }
  dspfcts();
#ifdef LOG
  Serial.println("--------------------------------------------");
  Serial.println("Loco address " + String(adr));
  if (bitRead(setsdhadr, MTx) == 1) Serial.println("Trailer address: " + String(sdhadr[MTx]));
  Serial.println("--------------------------------------------");
  Serial.println("dccadr: " + String(dccadr[MTx]));
#endif
}
//---------------------------------------------------------------------------
//--build function switch map array: ----------------------------------------
void bldswtmaparr() {
#ifdef LOG
  Serial.println("bldswtmaparr()");
#endif
  String lkn;
  fxi = 0;
  fxm = 0;
  for (byte j = 0; j < numswfcs; j++) {
    fxn = 0;
    fxs = 0;
    fxe = 0;
    while (fxn < numfcts) {  // look up all elements of fctsbuffer for each switched function
      fxs = fctsbuffer[MTx].indexOf("[", fxs);
      fxe = fctsbuffer[MTx].indexOf("]", fxs);
      lkn = fctname[fxi];                                   // copy fct name to search for into search arg
      String lk = fctsbuffer[MTx].substring(fxs + 1, fxe);  // copy JMRI entry to compare
      fxs++;
      if (lk == lkn) {              // if fctname is found in Server response 'fctsbuffer'
        fctswtmap[MTx][fxm] = fxn;  // position of matching fct = fct nbr.
        break;
      }
      fxn++;
    }
    fxi++;
    fxm++;
  }
#ifdef LOG
  Serial.print("fctswtmap: ");
  for (byte x = 0; x < numswfcs; x++) {
    if (x > 0) Serial.print(",");
    Serial.print(fctswtmap[MTx][x]);
  }
  Serial.println();
#endif
}
//--build index of function entries:-------------------------------
void bldfctidx() {
#ifdef LOG
  Serial.println("bldfctidx()");
#endif
  fxs = 0;
  fxe = 0;
  byte j = 0;
  numfcnt[MTx] = 0;
  int fxl = fctsbuffer[MTx].length();
  for (byte i = 0; i < numfcts; i++) {
    fxs = fctsbuffer[MTx].indexOf("[", fxs);
    fxe = fctsbuffer[MTx].indexOf("]", fxs);
    fxs++;
    String lk = fctsbuffer[MTx].substring(fxs, fxe);  // copy JMRI entry
    if (fxe > fxl) fxe = fxl;
    if (fxe - fxs > 0) {  // not nothing between []
      if (numfcnt[MTx] < numfcts) numfcnt[MTx]++;
      fctnos[MTx][j] = fxs;  //start of name
      fctnoe[MTx][j] = fxe;  //end of name
      fctnox[MTx][j] = i;    //fct number
      j++;
#ifdef LOG
      //Serial.println("Finding function name indices");
      //Serial.println("Start of name: " + String(fxs));
      //Serial.println("End of name: " + String(fxe));
      Serial.print("Function found in 'fctsbuffer' string: F" + String(i));
      Serial.println(" = " + String(lk));
#endif
    }
  }
  numfcnt[MTx] = numfcnt[MTx] - 1;
#ifdef LOG
  Serial.println("fctsbuffer counted: " + String(numfcnt[MTx]));
  Serial.print("function name start offsets - fctnos[MTx][]: ");
  for (byte i = 0; i < numfcts; i++) {
    if (i > 0) Serial.print(",");
    Serial.print(fctnos[MTx][i]);
  }
  Serial.println();
  Serial.print("function name end offsets - fctnoe[MTx][]: ");
  for (byte i = 0; i < numfcts; i++) {
    if (i > 0) Serial.print(",");
    Serial.print(fctnoe[MTx][i]);
  }
  Serial.println();
  Serial.print("function numbers - fctnox[MTx][]: ");
  for (byte i = 0; i < numfcts; i++) {
    if (i > 0) Serial.print(",");
    Serial.print(fctnox[MTx][i]);
  }
  Serial.println();
#endif
}
//---------------------------------------------------------------
void sendaccadr() {
#ifdef LOG
  Serial.println("sendaccadr()");
#endif
  xmits = "PTA" + setacc[MTx] + String(accadr[MTx]);
#ifdef LOG
  Serial.println("Sending " + xmits);
#endif
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
      Serial.print("Server reply to sendaccadr: ");
      Serial.println(jmri_res);
#endif
      if (jmri_res.startsWith("PTA")) {
        int ix = jmri_res.indexOf('A');
        ix++;
        jmri_sub = jmri_res.substring(ix);
        String stostate = jmri_sub.substring(0, 1);
        tostate = stostate.toInt();
        if ((tostate >= 0) && (tostate < 9)) dsptostate = tostarray[tostate];
#ifdef LOG
        Serial.print("tostate: ");
        Serial.println(tostate);
        Serial.print("dsptostate: ");
        Serial.println(dsptostate);
        Serial.println("JMRI turnout state: '2'=Closed, '4'=Thrown, '1'=Unknown or '8'=Inconsistent.");
#endif
      }
    }
    dsptr(0);
    cnth--;  //making up for lost time during inbound message
    dspaccstate();
  }
}
//-----------------------------------------------------------------
void dspaccstate() {
#ifdef LOG
  Serial.println("dspaccstate()");
#endif
  u8g2.setDrawColor(0);
  u8g2.drawBox(0, tl4, lw, 12);  //clear function numbers
  u8g2.setDrawColor(1);
  u8g2.setFont(sfont);
  u8g2.setCursor(0, bl4);
  String dsptext = ("T-state fdbk: " + String(dsptostate));
  u8g2.print(dsptext);
  u8g2.sendBuffer();
}
//------------------------------------------------------
void sendroute() {
#ifdef LOG
  Serial.println("sendroute()");
#endif
  xmits = "PRA2" + String(rsysname);
#ifdef LOG
  Serial.println("Sending route: " + xmits);
#endif
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
#ifdef DEBUG
    Serial.println("server response: ");
    while (client.available()) {
      char c = client.read();
      Serial.write(c);
    }
#endif
    dsptr(0);
    cnth--;  //making up for lost time during inbound message
  }
}
/////////////////////////////////////////////////////////////////////////
#ifdef CLOCK
void processSyncMessage() {
  unsigned long pctime;
  const unsigned long DEFAULT_TIME = 1357041600;
  pctime = unixsub.toInt();
  if (pctime >= DEFAULT_TIME) {  // check the integer is a valid time (greater than Jan 1 2013)
    setTime(pctime);             // Sync Arduino clock to the time received on the serial port
  }
}
void getjmritime() {
  unixtime = jmri_res;  // save fastclock time
  int j = unixtime.indexOf("<;>");
  if (j > 0) {                           // some times a "<;>" isn't sent from jmri, ignore timestamp if it isn't.
    unixsub = unixtime.substring(3, j);  // time stamp only
    //# j = j + 3;
    //# ratiosub = unixtime.substring(j, j + 3);
    // process unix time stamp
    processSyncMessage();
    //display fastclock:
    dsphour = hour();
    dspmin = minute();
    u8g2.setFont(sfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(43, 0, 46, 12);
    u8g2.setDrawColor(1);
    u8g2.setCursor(45, 9);
    String dsptime;
    //# if (dspmin < 10) dsptime = (String(dsphour) + ":0" + String(dspmin) + " r:" + ratiosub + "\r\n");
    //# else dsptime = (String(dsphour) + ":" + String(dspmin) + " r:" + ratiosub + "\r\n");
    if (dspmin < 10) dsptime = (String(dsphour) + ":0" + String(dspmin) + "\r\n");
    else dsptime = (String(dsphour) + ":" + String(dspmin) + "\r\n");
    u8g2.print(dsptime);
    u8g2.sendBuffer();
#ifdef LOGTIME
    Serial.println("Server-Time: " + dsptime);
#endif
  }
}
#endif
//--------------------------------------
void retrievestack() {
#ifdef LOG
  Serial.println("retrievestack()");
#endif
  byte j = 2;  // stack array was saved to eeprom starting at element 2
  for (byte i = 0; i <= 5; i++) {
    dccadrtmp = EEPROM.read(j);
    j++;
    dccadrtmp = (dccadrtmp << 8) + EEPROM.read(j);
    j++;
    if ((dccadrtmp >= 0) && (dccadrtmp < 9999)) dccstck[i] = dccadrtmp;
  }
#ifdef LOG
  Serial.print("stack retrieved: ");
  for (byte i = 0; i <= 5; i++) {
    if (i > 0) Serial.print(",");
    Serial.print(dccstck[i]);
  }
  Serial.println();
#endif
}
//--------------------------------------
void writestack() {
#ifdef LOG
  Serial.println("writestack()");
#endif

  for (byte i = 4; i >= 0; i--) {  // all entries shift right
    dccadrtmp = dccstck[i];
    byte j = i + 1;
    dccstck[j] = dccadrtmp;
    if (i == 0) {
      dccstck[0] = dccadr[MTx];  // add new entry as first
      break;
    }
  }
#ifdef LOG
  Serial.print("stack array new: ");
  for (byte i = 0; i <= 5; i++) {
    if (i > 0) Serial.print(",");
    Serial.print(dccstck[i]);
  }
  Serial.println();
#endif
}
//---------------------------------------------------------
void savestack() {
#ifdef LOG
  Serial.print("savestack(): ");
  for (byte i = 0; i < 6; i++) {
    Serial.print(dccstck[i]);
    if (i < 5) Serial.print(",");
  }
  Serial.println();
#endif
  byte j = 2;  // saving stack array to eeprom starting at element 2
  for (byte i = 0; i <= 5; i++) {
    dccadrtmp = dccstck[i];
    if ((dccadr[MTx] > 0) && (dccadr[MTx] <= 9999)) {
      EEPROM.write(j, (dccadrtmp >> 8) & 0xff);
      j++;
      EEPROM.write(j, (dccadrtmp & 0xff));
      j++;
    }
  }
  EEPROM.commit();
}
//--------------------------------------
#ifdef BATLEVEL
void getbatlvl() {  // check battery level:
  float highvolt = maxvolt - offvolt;
  float vwarn = offvolt + 0.1;
  digitalWrite(2, HIGH);
  delay(50);
  int batin = analogRead(voltagepin);
  digitalWrite(2, LOW);
  float battmp = batin / 2047.5;
  float batvolt = battmp * 3.63;  // 3.3 refV * 1.1 ADC refV = 3.63
  float lowvolt = batvolt - offvolt;
  float pcvolt = lowvolt / highvolt * 100;
  if (pcvolt > 100) pcvolt = 100;  // limit 100%
  char dspbat[4];
  dtostrf(pcvolt, 4, 0, dspbat);
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
#ifndef CLOCK
  u8g2.drawBox(43, 0, 47, 12);  // replace time with percent
#endif
  u8g2.drawBox(110, 0, 18, 12);
  u8g2.setDrawColor(1);
  //------------------------
  if ((pcvolt > 90) && (pcvolt <= 100)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl10);
  }
  //------------------------
  if ((pcvolt > 80) && (pcvolt <= 90)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl9);
  }
  //------------------------
  if ((pcvolt > 70) && (pcvolt <= 80)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl8);
  }
  //------------------------
  if ((pcvolt > 60) && (pcvolt <= 70)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl7);
  }
  //------------------------
  if ((pcvolt > 50) && (pcvolt <= 60)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl6);
  }
  //------------------------
  if ((pcvolt > 40) && (pcvolt <= 50)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl5);
  }
  //------------------------
  if ((pcvolt > 30) && (pcvolt <= 40)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl4);
  }
  //------------------------
  if ((pcvolt > 20) && (pcvolt <= 30)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl3);
  }
  //------------------------
  if ((pcvolt > 10) && (pcvolt <= 20)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl2);
  }
  //------------------------
  if ((pcvolt > 0) && (pcvolt <= 10)) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl1);
  }
  //------------------------
  if (pcvolt == 0) {
    u8g2.drawBitmap(110, 1, 2, 8, batlvl0);
  }
  if (batvolt <= vwarn) {
    u8g2.setDrawColor(0);
    u8g2.drawBox(43, 0, 85, 12);
    u8g2.setDrawColor(1);
    u8g2.drawStr(45, 9, "Battery LOW!!");
    if (dsplon == false) display_on();
  }
#ifndef CLOCK
  if (batvolt > vwarn) {
    u8g2.setCursor(43, 9);
    u8g2.print(dspbat);
    u8g2.drawStr(65, 9, "%");
  }
#endif
  u8g2.sendBuffer();
}
#endif  //ifdef BATLEVEL
//--------------------------------------
void getsiglvl() {
  signalx = WiFi.RSSI();
  //#ifdef LOG
  //  Serial.print("getsiglvl() - WiFi-Signal (RSSI): ");
  //  Serial.print(signalx);
  //  Serial.println(" dBm");
  //#endif
  u8g2.setDrawColor(0);
  u8g2.drawBox(90, 0, 20, 12);  //clear field
  u8g2.setDrawColor(1);
  if ((signalx > (-50)) && (signalx <= (-1))) {  //lvl4 excellent
    u8g2.drawBitmap(91, 2, 2, 7, siglvl4);
  }
  if ((signalx > (-60)) && (signalx <= (-50))) {  //lvl3 very good
    u8g2.drawBitmap(91, 2, 2, 7, siglvl3);
  }
  if ((signalx > (-75)) && (signalx <= (-60))) {  //lvl2 good
    u8g2.drawBitmap(91, 2, 2, 7, siglvl2);
  }
  if ((signalx > (-99)) && (signalx <= (-75))) {  //lvl1 low
    u8g2.drawBitmap(91, 2, 2, 7, siglvl1);
  }
  if (signalx == 0) {  // bad
    u8g2.drawBitmap(91, 2, 2, 7, siglvl0);
  }
  u8g2.sendBuffer();
}
//--------------------------------------
void set_spstm() {
#ifdef LOG
  Serial.print("set_spdtm(): current speed step mode: ");
  Serial.println(spdstpm);
#endif
  if (spdstpm == 1) chgspstm = 2;  //126 > 28
  if (spdstpm == 2) chgspstm = 1;  //28 > 126
  xmits = locoacts[MTx] + "s" + String(chgspstm);
#ifdef LOG
  Serial.print("set_spstm: ");
  Serial.println(xmits);
#endif
  if (svr == true) {
    dsptr(1);
    client.print(xmits + "\r\n");
    delay(sdelay);
    while (client.available()) {
      jmri_res = client.readStringUntil('\n');
#ifdef DEBUG
      Serial.print("Server reply to set_spstm: ");
      Serial.println(jmri_res);
#endif
      if (jmri_res.startsWith(lks[MTx])) {  // look for speed step setting in jmri
        int ix = jmri_res.indexOf('s');
        ix++;
        jmri_sub = jmri_res.substring(ix, ix + 1);
        spdstpm = jmri_sub.toInt();
        if (spdstpm == 1) numspst[MTx] = 126;  // speed step mode 128 (0 = stop, 1 to 126 + Estop = 128)
        if (spdstpm == 2) numspst[MTx] = 28;   // speed step mode 28  (appr. 127/28)
        if (spdstpm == 4) numspst[MTx] = 27;   // ignored (old Lenz only & obsolete)
        if (spdstpm == 8) numspst[MTx] = 14;   // ignored (obsolete)
#ifdef LOG
        Serial.print("new speed step mode: ");
        Serial.println(spdstpm);
#endif
        u8g2.setFont(sfont);
        u8g2.setDrawColor(0);
        u8g2.drawBox(45, tl2, 20, 14);
        u8g2.setDrawColor(1);
        u8g2.setCursor(46, bl2);
        u8g2.print(String(numspst[MTx]));
        u8g2.sendBuffer();
      }
    }
    dsptr(0);
    cnth--;  // making up for lost time during inbound message
  }
}
//------------------------------------------------------------------
void simlokbtn() {
#ifdef LOG
  Serial.println("simlokbtn()");
  Serial.println("dccadr: " + String(dccadr[MTx]));
#endif
  clrchgadr();
  clrrosnam();
  btncnt = 0;
  bitWrite(setdccadr, MTx, 1);
  adrbtnstate = 1;
  pshadr = true;
  vspeed[MTx] = 0;
  vtemp = 0;
  vcnt[MTx] = 0;
  dspeed = vcnt[MTx];
  lastvcnt = 0;
  dsp_speed();
  u8g2.setDrawColor(0);
  u8g2.drawBox(73, tl2x, 10, 16);  //clear +
  u8g2.setDrawColor(1);
  dspchgadr();
  rtvrosnam();
  if (ros_eAvail == true) dsprosnam();
}
//------------------------------------------------------------------
void actdccadr() {
#ifdef LOG
  Serial.println("actdccadr()");
#endif
  bitWrite(setdccadr, MTx, 0);
  if ((pshadr == true) || (ros_eAvail == true)) {  // address entered, or got a roster entry.
    vcnt[MTx] = 0;
    vtemp = 0;
    vspeed[MTx] = 0;
    if (ros_eAvail == true) {
      dccadr[MTx] = locoadr[MTx].toInt();
#ifdef LOG
      Serial.println("address taken from roster: " + String(dccadr[MTx]));
#endif
    }
    sprintf(dspadr, "%04d", dccadr[MTx]);  // display with leading zeros
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(45, tl2, 20, 13);                                     //clear stack array #
    u8g2.drawBox(120, tl2x, 8, 16);                                    //clear ?
    if (bitRead(setsdhadr, MTx) == 1) u8g2.drawBox(85, tl2x, 43, 16);  //"dccadr"
    else u8g2.drawBox(73, tl2x, 55, 16);                               //"+ dccadr"
    u8g2.drawBox(80, tl3, 48, 16);                                     //remove locoadr from loconame
    u8g2.setDrawColor(1);
    u8g2.setCursor(85, bl2);
    u8g2.print(dspadr);
    u8g2.sendBuffer();
#ifdef LOG
    Serial.println("actdccadr #1: " + String(dspadr));
#endif
    // avoid duplicate in stack array: -------------------------
    updstck = true;
    for (byte i = 0; i <= 5; i++) {
      if (dccstck[i] == dccadr[MTx]) {
        updstck = false;
#ifdef LOG
        Serial.println("address already in stack.");
#endif
        break;
      }
    }
    // write to stack array: -----------------------------------
    if (updstck == true) {
      writestack();
      savestack();  // to eeprom
      updstck = false;
    }
    // also save last dcc address to eeprom:
    bool updprom = false;
    if (MTn == 1) {
      dccadrtmp = EEPROM.read(0);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(1);
#ifdef LOG
      Serial.print("dccadr in eeprom T1: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 1: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadrtmp != dccadr[MTx]) {
        EEPROM.write(0, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(1, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T1: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (MTn == 2) {
      dccadrtmp = EEPROM.read(96);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(97);
#ifdef LOG
      Serial.print("dccadr in eeprom T2: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 2: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadr[MTx] != dccadrtmp) {
        EEPROM.write(96, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(97, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T2: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (MTn == 3) {
      dccadrtmp = EEPROM.read(98);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(99);
#ifdef LOG
      Serial.print("dccadr in eeprom T3: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 3: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadr[MTx] != dccadrtmp) {
        EEPROM.write(98, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(99, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T3: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (MTn == 4) {
      dccadrtmp = EEPROM.read(100);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(101);
#ifdef LOG
      Serial.print("dccadr in eeprom T4: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 4: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadr[MTx] != dccadrtmp) {
        EEPROM.write(100, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(101, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T4: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (MTn == 5) {
      dccadrtmp = EEPROM.read(102);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(103);
#ifdef LOG
      Serial.print("dccadr in eeprom T5: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 5: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadr[MTx] != dccadrtmp) {
        EEPROM.write(102, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(103, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T5: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (MTn == 6) {
      dccadrtmp = EEPROM.read(104);
      dccadrtmp = (dccadrtmp << 8) + EEPROM.read(105);
#ifdef LOG
      Serial.print("dccadr in eeprom T6: ");
      Serial.println(dccadrtmp);
      Serial.print("dccadr in throttle 6: ");
      Serial.println(dccadr[MTx]);
#endif
      if (dccadr[MTx] != dccadrtmp) {
        EEPROM.write(104, (dccadr[MTx] >> 8) & 0xff);
        EEPROM.write(105, dccadr[MTx] & 0xff);
        updprom = true;
#ifdef LOG
        Serial.print("last dccadr T6: ");
        Serial.println(dccadr[MTx]);
#endif
      }
    }
    if (updprom == true) {
#ifdef LOG
      Serial.println("writing last dccadr to eeprom.");
#endif
      EEPROM.commit();
    }
    // -----------------
    pshadr = false;
#ifdef LOG
    Serial.print("adding dcc address ");
    Serial.println(dspadr);
#endif
    if (ros_eAvail == false) {
      rtvrosnam();
    }
    clrrosnam();
    if (ros_eAvail == true) dsprosnam();
    sendadr(dccadr[MTx]);
    int j = 1;
    for (int i = 0; i < numthrottles; i++) {  //update bit array with active throttles
      if (MTn == j) bitWrite(actthrottles, i, 1);
      j++;
    }
#ifdef LOG
    byte y;
    Serial.print("Active throttles: ");
    for (byte n = 0; n < numthrottles; n++) {
      y = n + 1;
      if (bitRead(actthrottles, n) == 1) Serial.print(String(y) + ":" + String(dccadr[n]) + "  ");
    }
    Serial.println();
#endif
  } else {
#ifdef LOG
    Serial.println("adr not changed ");
    Serial.println(dccadr[MTx]);
#endif
    if (dccadrrlsd[MTx] == dccadr[MTx]) {
      sendadr(dccadr[MTx]);
      dccadrrlsd[MTx] = 0;
    }
    dsprosnam();
    ssndfct = ("F" + String(sndfct[MTx]));
    sprintf(dspadr, "%04d", dccadr[MTx]);
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(120, tl2x, 8, 16);  //clear ?
    u8g2.drawBox(80, tl3, 48, 16);   // remove locoadr on display
    u8g2.setDrawColor(1);
    u8g2.setCursor(85, bl2);
    u8g2.print(dspadr);
    u8g2.setCursor(0, bl3);
    u8g2.print(loconame[MTx]);
    if (adrmatch == false) dspsndfct();  //# dsp speaker
    vcnt[MTx] = lastvcnt;
#ifdef LOG
    Serial.println("actdccadr #2: " + String(dspadr));
#endif
  }
}
//------------------------------------------------------------------------
//>>(not tested)------------------------------------------------------
void steel_inquiry() {
#ifdef LOG
  Serial.println("steel_inquiry()");
#endif
  bool bqm = false;
  prvsMillis = 0;
  crntMillis = millis();
  while (strq == true) {  //steel request - blink question mark
    if (crntMillis - prvsMillis >= 1000) {
      prvsMillis = crntMillis;
      if (bqm == true) {  //blink question mark on
        u8g2.setDrawColor(1);
        u8g2.drawStr(120, bl2, "?");
        u8g2.sendBuffer();
        bqm = false;
      } else {
        u8g2.setDrawColor(0);
        u8g2.drawBox(120, tl2x, 8, 16);  //blink question mark off
        u8g2.sendBuffer();
        bqm = true;
      }
      if (hbuse == true) {
        client.print("*\r\n");  // send heart beat
        cnth = ch;
      }
    }
    kpread = analogRead(keypadin);
    if (kpread > kpnone) {
      delay(dbcdly);
      //press button 13 to confirm steel:
      if ((kpread >= keypadarray[24]) && (kpread <= keypadarray[25])) {
        u8g2.drawBox(120, tl2x, 8, 16);  //clear ?
        u8g2.sendBuffer();
        strq = false;  // exit while loop
        steel = true;
        sendadr(dccadr[MTx]);            //submit address
      } else {                           // pressed any other key - select other loco
        u8g2.drawBox(120, tl2x, 8, 16);  //clear ?
        u8g2.sendBuffer();
        simlokbtn();
        strq = false;  // exit while loop
      }
      if (encoder_moved == true) {
        u8g2.drawBox(120, tl2x, 8, 16);  //clear ?
        u8g2.sendBuffer();
        encoder_moved = false;
        simlokbtn();
        strq = false;  // exit while loop
      }
    }
  }
}
//---------------------------------------------------------------------
void keypad_check() {
  u8g2.setPowerSave(1);  // screen saver on
  if (svr == true) {     // send "Quit" to server
    client.print("Q\r\n");
    delay(fdelay);
  }
  Serial.println("Keypad-Config: reading input from keypad 10 times");
  for (byte i = 0; i < 10; i++) {
    kpread = analogRead(keypadin);
    Serial.print("Keypad reading with no active button: ");
    Serial.println(kpread);
    if (kpread < btnprvl) {
      btnmin = kpread;
      btnprvl = kpread;
    }
    if (kpread > btnprvh) {
      btnmax = kpread;
      btnprvh = kpread;
    }
    delay(500);
  }
  btnprvl = 5000;  // reset
  Serial.println("--------------------------------------------------------------------------------------------");
  Serial.println("In case not all values are zero decrease resistor connecting keypad buttons to ground.");
  Serial.println("For measuring button values: push a button until reading stops. Then release button.");
  Serial.println("After each measured button, in Serial Monitor enter the number of the pushed button.");
  Serial.println("After all buttons have been measured, enter any number above 16 to save all values and exit .");
  Serial.println("--------------------------------------------------------------------------------------------");
  Serial.println("Current EEPROM content: ");
  byte j = 20;
  for (byte i = 0; i < 33; i++) {
    if (i > 0) Serial.print(",");
    int v = EEPROM.read(j);
    j++;
    v = (v << 8) + EEPROM.read(j);
    j++;
    Serial.print(v);
  }
  Serial.println();
}
void keypad_config() {
  int btnmin = 0;      // for finding min value
  int btnmax = 0;      // for finding max value
  int btnprvl = 5000;  // previous low
  int btnprvh = 0;     // previous high
  int btnnum = 0;      // button number
  int btnsav = 0;
  int rdcnt = 0;
  bool kpreadON = false;
  byte offset[16];
  bool eoj = false;
  byte j = 20;
  for (byte i = 0; i < 16; i++) {
    offset[i] = j;
    j = j + 4;
  }
  Serial.println("Push a button until reading stops. Then release button.");
  Serial.println("To end and save all values enter any number above 16.");
  while (eoj == false) {
    kpread = analogRead(keypadin);
    if (kpread > kpnone) {  // minimum value indicating a button is pressed
      delay(dbcdly);
      if (kpreadON == false) {
        for (int i = 0; i < 18; i++) {
          kpread = analogRead(keypadin);
          rdcnt++;
          if ((rdcnt > 1) && (rdcnt < 17)) {  //ignore first and last read. Debounce cap's if installed may cause false reading
            Serial.print("Button reads: ");
            Serial.println(kpread);
            if (kpread < btnprvl) {
              btnmin = kpread;
              btnprvl = kpread;
            }
            if (kpread > btnprvh) {
              btnmax = kpread;
              btnprvh = kpread;
            }
            delay(100);
          }
        }
        kpreadON = true;
      }
    } else if (kpread == 0) {
      if (kpreadON == true) {
        btnnum++;
        rdcnt = 0;
        Serial.print("Button ");
        Serial.print(btnnum);
        Serial.print(" min keypad reading ");
        Serial.println(btnmin);
        Serial.print("Button ");
        Serial.print(btnnum);
        Serial.print(" max keypad reading ");
        Serial.println(btnmax);
        btnprvl = 5000;
        btnprvh = 0;
        kpreadON = false;
        Serial.println("For saving values: in SM enter the button number you pressed");
      }
    }
    if (Serial.available() > 0) {
      int btnin = Serial.parseInt();      // receive byte as an integer
      if ((btnin > 0) && (btnin < 17)) {  // is a button in keypad
        btnin--;
        btnsav = offset[btnin];
        if (btnmin > 5) btnmin = btnmin - 5;
        if (btnmax < 4090) btnmax = btnmax + 5;
        Serial.println("------------------------------------------");
        Serial.print("Saving values from ");
        Serial.print(btnnum);
        Serial.println(". reading.");
        Serial.print("Saving minimum value ");
        Serial.print(btnmin);
        Serial.print(" in elements ");
        Serial.print(btnsav);
        Serial.print(" & ");
        EEPROM.write(btnsav, (btnmin >> 8) & 0xff);
        btnsav++;
        Serial.println(btnsav);
        EEPROM.write(btnsav, (btnmin)&0xff);
        btnsav++;
        Serial.print("Saving maximum value ");
        Serial.print(btnmax);
        Serial.print(" in elements ");
        Serial.print(btnsav);
        Serial.print(" & ");
        EEPROM.write(btnsav, (btnmax >> 8) & 0xff);
        btnsav++;
        Serial.println(btnsav);
        EEPROM.write(btnsav, (btnmax)&0xff);
        EEPROM.commit();
        Serial.println("Current EEPROM content: ");
        byte j = 20;
        for (byte i = 0; i < 33; i++) {
          if (i > 0) Serial.print(",");
          int val = EEPROM.read(j);
          j++;
          val = (val << 8) + EEPROM.read(j);
          j++;
          Serial.print(val);
          if (i < 32) Serial.print(",");
        }
        Serial.println();
      }
      if (btnin > 16) {
        byte j = 20;
        btnprvl = 5000;
        Serial.println("Read back summary of button readings:");
        Serial.println("Btn#   Low    High");
        for (byte i = 1; i < 17; i++) {
          int valL = EEPROM.read(j);
          j++;
          valL = (valL << 8) + EEPROM.read(j);
          j++;
          if (valL < btnprvl) btnprvl = valL;  //find lowest value
          int valH = EEPROM.read(j);
          j++;
          valH = (valH << 8) + EEPROM.read(j);
          j++;
          if (valH < btnprvl) btnprvl = valH;  //find lowest value
          Serial.print(i);
          if (i < 10) Serial.print("      ");
          else Serial.print("     ");
          Serial.print(valL);
          Serial.print("   ");
          Serial.println(valH);
        }
        Serial.println("New EEPROM content: ");
        j = 20;
        for (byte i = 0; i < 33; i++) {
          if (i > 0) Serial.print(",");
          int val = EEPROM.read(j);
          j++;
          val = (val << 8) + EEPROM.read(j);
          j++;
          Serial.print(val);
        }
        Serial.println();
        Serial.println("To go back to normal work press Stop/Brake");
      }
    }
    swtSstate = digitalRead(switchSpin);
    if (swtSstate != lastswtSstate) {
      if (swtSstate == LOW) eoj = true;
      lastswtSstate = swtSstate;
      Serial.println("keypad-config ended");
      Serial.println("-------------------------------------------------");
      u8g2.setPowerSave(0);
      reconnect();
    }
  }
}
//-----------------------------------------------------
void reconnect() {
#ifdef LOG
  Serial.println("reconnect() - Host:Port " + String(host) + ":" + String(port));
#endif
  u8g2.clearDisplay();
  u8g2.setFont(sfont);
  u8g2.setDrawColor(1);
  u8g2.setCursor(0, 9);
  u8g2.print(dsptname);
  u8g2.drawStr(45, 9, "reconnect");
  u8g2.sendBuffer();
  cntc = 6;
  cntt = 0;
  client.connect(host, port);
  while (!client.connected()) {
    delay(1000);
#ifdef LOG
    Serial.print('.');
#endif
    cntc--;
    cntt++;
    if (cntc <= 0) {
      cntc = 6;
      client.connect(host, port);
    }
    swtSstate = digitalRead(switchSpin);
    if ((cntt > 60) || (swtSstate == LOW)) {
      swtSstate = HIGH;
#ifdef LOG
      Serial.println();
      Serial.println("reconnect(): server reconnect failed");
#endif
      client.stop();
      u8g2.setDrawColor(0);
      u8g2.drawBox(43, 0, 85, 12);
      u8g2.setDrawColor(1);
      u8g2.drawStr(45, 9, "reconnect failed");
      u8g2.sendBuffer();
      WiFi.disconnect();
#ifdef LOG
      Serial.println("Throttle offline");
      Serial.println("WiFi disconnected");
#endif
      cntd = cd;
      svr = false;
      break;
    }
  }
  if (svr == true) {
//---Throttle ON: sends NAME,MAC to server and starts heart beat
#ifdef LOG
    Serial.println("Sending HU" + MacString);
#endif
    dsptr(1);
    client.print("N" + tname + "\r\n");  // set Name of Throttle
    delay(fdelay);
    client.print("HU" + MacString + "\r\n");  // set identifier
    delay(fdelay);
    if (hbuse == true) {
      client.print("*+\r\n");  // starting heartbeat
      delay(fdelay);
    }
    dsptr(0);
    bitWrite(setdccadr, MTx, 1);
    pshadr = true;
    // restore last dcc addresses from array for reconnect():
    for (byte i = 0; i < 6; i++) {
      dccadr[i] = dccstck[i];
    }
    rtvrosnam();
    dsprosnam();
    dsprosadr();
    dspdccadr();
    u8g2.setDrawColor(0);
    u8g2.drawBox(43, 0, 85, 12);
    u8g2.setDrawColor(1);
    u8g2.setFont(sfont);
    if (ready == true) u8g2.drawStr(45, 9, "svr ready");  //##09.08
    else u8g2.drawStr(45, 9, "svr online");
    for (byte x = 0; x < numthrottles; x++) {  //reset after reconnect
      vspeed[x] = 0;
    }
    dspeed = 0;
    if (bitRead(dctstate, MTx) == 1) {
      //u8g2.drawStr(0, 25, "F");
      u8g2.drawBitmap(0, tl2, 1, 11, forward);
    } else {
      //u8g2.drawStr(0, 25, "R");
      u8g2.drawBitmap(0, tl2, 1, 11, reverse);
    }
    u8g2.setFont(lfont);
    u8g2.setCursor(15, bl2);
    u8g2.print(dspeed);
    u8g2.setFont(sfont);
    u8g2.drawStr(0, bl4, "Fg");
    u8g2.setCursor(15, bl4);
    u8g2.print(String(fcgstate[MTx]));
    u8g2.setFont(lfont);
    u8g2.setDrawColor(0);
    u8g2.drawBox(120, tl2x, 8, 16);
    u8g2.setDrawColor(1);
    u8g2.drawStr(120, bl2, "?");
    u8g2.sendBuffer();
    adrbtnstate = 1;
  }
}
//------------------------------------------------------------
void scanNetworks() {
  // scan for nearby networks:
#ifdef LOG
  Serial.println("scanNetworks()");
#endif
  byte numSsid = WiFi.scanNetworks();
#ifdef LOG
  // print the list of networks seen:
  Serial.print("SSID List: ");
  Serial.println(numSsid);
  // print the network number and name for each network found:
  for (int numNet = 0; numNet < numSsid; numNet++) {
    Serial.print(numNet);
    Serial.print("Local Network: ");
    Serial.println(WiFi.SSID(numNet));
  }
#endif
}
//-----------------------------------------------------------------
void dsptr(byte s) {  // display ransmit/receive indicator
  u8g2.setFont(sfont);
  u8g2.setDrawColor(0);
  u8g2.drawBox(110, 0, 18, 12);
  u8g2.setDrawColor(1);
  if (s == 1) {
    hben = false;
    //u8g2.drawStr(105, 9, "<-->");
    u8g2.drawBitmap(110, 0, 2, 10, transmit);
    cntb = 10;  // leave indicator on until timeout expires
  }
  if (s == 0) {
    cntb = 1;   // turn off - display bat
    cnth = ch;  //reset hb timer
    hben = true;
  }
  if (s == 2) {  //inbound
    cntb = 1;
    hben = true;
  }
  u8g2.sendBuffer();
}
