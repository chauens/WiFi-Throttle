// I2C Address Scanner
// Start Serial Monitor at a baud rate of 115200

#include <Wire.h>
 
void setup() {
  Serial.begin (115200);
  delay(2000); //give time to start the serial monitor
  Serial.println ();
  Serial.println ("Scanning I2C addresses...");
  byte count = 0;
  
  Wire.begin();
  for (byte i = 8; i < 120; i++) {
    Wire.beginTransmission (i);
    if (Wire.endTransmission () == 0) {
      Serial.print ("Found address: ");
      Serial.print (i, DEC);
      Serial.print (" (0x");
      Serial.print (i, HEX);
      Serial.println (")");
      count++;
    }
  }
  Serial.println ("Done.");
}
 
void loop() {}
