/* Store values for keypad buttons. 
Must be run before Sketch_WiFi_Multi_Throttle_v2_.... is uploded for the first time.
Copyright info see above sketch.
    Christoph Hauenstein. July/02/2024.
    Start Serial Monitor at a baud rate of 115200 + No Line Ending.
*/
#include <EEPROM.h>
#include <Wire.h>
/***************************************************************************************/
#define keypadin 34 // A2 analog pin connecting keypad 
/****************************************************************************************/
int btnread = 0;    // holding keypad button values
int btnmin = 0;     // for finding min value
int btnmax = 0;     // for finding max value
int btnprvl = 5000; // previous low
int btnprvh = 0;    // previous high
int btnnum = 0;     // button number
int btnsav = 0;
int rdcnt = 0;
bool kpreadON = false;
byte dbcdly = 50;      // debounce delay
#define EEPROM_SIZE 192
// 0+1=dccadr, 2-13=stack, 19=numthrottles, 20-83=keypad, 95=location(0=home/1=club),
byte offset[16];
/***************************************************************************************/
void setup() {
  Serial.begin(115200);
  delay(200);
  EEPROM.begin(EEPROM_SIZE);
  byte j = 20;
  for (byte i = 0; i < 16; i++) {
    offset[i] = j;
    j = j + 4;
  }
  delay(3000);
  Serial.println("V4.6.16**************************************************************");
  Serial.println("reading input from keypad 10 times");
  for (byte i = 0; i < 10; i++) {
    btnread = analogRead(keypadin);
    Serial.print("Keypad reading with no active button: ");
    Serial.println(btnread);
    if (btnread < btnprvl) {
      btnmin = btnread;
      btnprvl = btnread;
    }
    if (btnread > btnprvh) {
      btnmax = btnread;
      btnprvh = btnread;
    }
    delay(500);
  }
  btnprvl = 5000;   // reset
  Serial.println("--------------------------------------------------------------------------------------------");
  Serial.println("If not all values are zero decrease resistor connecting keypad buttons to ground.");
  Serial.println("For measuring button values: push a button until reading stops. Then release button.");
  Serial.println("After each measured button, in Serial Monitor enter the number of the pushed button.");
  Serial.println("After all buttons have been measured, enter any number above 16 to save all values and exit .");
  Serial.println("--------------------------------------------------------------------------------------------");
  Serial.println("Current EEPROM keypad content: ");
  j = 20;
  for (byte i = 0; i < 33; i++) {
    int val = EEPROM.read(j);
    j++;
    val = (val << 8) + EEPROM.read(j);
    j++;
    Serial.print(val);
    if (i < 32) Serial.print(",");
  }
  Serial.println();
}
/***************************************************************************************/
void loop() {
  btnread = analogRead(keypadin);
  if (btnread > 100) {   // minimum value indicating a button is pressed
    delay(dbcdly);
    if (kpreadON == false) {
      for (int i = 0; i < 18; i++) {
        btnread = analogRead(keypadin);
        rdcnt++;
        if ((rdcnt > 1) && (rdcnt < 17)) { // toss first read and last. Debounce cap's if installed may cause weird first and last values
          Serial.print("Button reads: ");
          Serial.println(btnread);
          if (btnread < btnprvl) {
            btnmin = btnread;
            btnprvl = btnread;
          }
          if (btnread > btnprvh) {
            btnmax = btnread;
            btnprvh = btnread;
          }
          delay(100);
        }
      }
      kpreadON = true;
    }
  }
  else if (btnread == 0) {
    if (kpreadON == true) {
      btnnum++;
      rdcnt = 0;
      Serial.print("Button ");
      Serial.print(btnnum);
      Serial.print(" min keypad reading ");
      Serial.println(btnmin);
      Serial.print("Button ");
      Serial.print(btnnum);
      Serial.print(" max keypad reading ");
      Serial.println(btnmax);
      btnprvl = 5000;
      btnprvh = 0;
      kpreadON = false;
      Serial.println("For saving values: in SM enter the button number you pressed.");
    }
  }
  if (Serial.available() > 0) {
    int btnin = Serial.parseInt(); // receive byte as an integer
    if ((btnin > 0) && (btnin < 17)) { // is a button in keypad
      btnin--;
      btnsav = offset[btnin];
      if (btnmin > 5) btnmin = btnmin - 5;
      if (btnmax < 4090) btnmax = btnmax + 5;
      Serial.println("------------------------------------------");
      Serial.print("Saving values for button ");
      Serial.println(btnnum);
      Serial.print("Saving minimum value ");
      Serial.print(btnmin);
      Serial.print(" in elements ");
      Serial.print(btnsav);
      Serial.print(" & ");
      EEPROM.write(btnsav, (btnmin >> 8) & 0xff);
      btnsav++;
      Serial.println(btnsav);
      EEPROM.write(btnsav, (btnmin) & 0xff);
      btnsav++;
      Serial.print("Saving maximum value ");
      Serial.print(btnmax);
      Serial.print(" in elements ");
      Serial.print(btnsav);
      Serial.print(" & ");
      EEPROM.write(btnsav, (btnmax >> 8) & 0xff);
      btnsav++;
      Serial.println(btnsav);
      EEPROM.write(btnsav, (btnmax) & 0xff);
      EEPROM.commit();
      Serial.println("Current eeprom content: ");
      byte j = 20;
      for (byte i = 0; i < 33; i++) {
        int val = EEPROM.read(j);
        j++;
        val = (val << 8) + EEPROM.read(j);
        j++;
        Serial.print(val);
        if (i < 32) Serial.print(",");
      }
      Serial.println();
    }
    if (btnin > 16) {
      byte j = 20;
      btnprvl = 5000;
      Serial.println("Read back summary of button readings:");
      Serial.println("Btn#   Low    High");
      for (byte i = 1; i < 17; i++) {
        int valL = EEPROM.read(j);
        j++;
        valL = (valL << 8) + EEPROM.read(j);
        j++;
        if (valL < btnprvl) btnprvl = valL;  //find lowest value
        int valH = EEPROM.read(j);
        j++;
        valH = (valH << 8) + EEPROM.read(j);
        j++;
        if (valH < btnprvl) btnprvl = valH;  //find lowest value
        Serial.print(i);
        if (i < 10) Serial.print("      ");
        else Serial.print("     ");
        Serial.print(valL);
        Serial.print("   ");
        Serial.println(valH);
      }
    }
  }
}
